<?php
include('includes/header.php');

if (isset($_SESSION['empno'])){
	$name=$_SESSION['name'];
	$empno=$_SESSION['empno'];
	$role=$_SESSION['role'];
}else{
	echo "<div class='txtResult'>You are not logged in</div>";
	exit;
}

if ($role=='STAFF' or $role=='REPORT'){
	echo "<div class='txtResult'>You are not authorized to use this menu</div>";
	exit;
}



$phpself=$_SERVER['PHP_SELF'];
$readonly='';
$txtResult='';
$remarks='';


function convertTime($t){
	list($h, $m, $s)=split(':',$t);
	return $h*60*60 + $m*60 + $s;
}
		$sql="select * from timetrack";
			$query = $db_object->query($sql);
			if (DB::isError($query)) {
				echo "Error -<i>".$query ->getMessage()."</i>";
			}elseif ($query->numRows()>0){
				$prev_employeeno="";
				$prev_timelogged="";
				$prev_identtype="";

				while ($info=$query->fetchRow()){
						$date=$info['date'];
						$calctimein=$info['calctimein'];
						$calctimeout=$info['calctimeout'];
						$timein=$info['timein'];
						$timeout=$info['timeout'];
											
						
						$nightstart=$date." 20:00:00";
						$datetime1 = new DateTime($calctimeout);
						$datetime2 = new DateTime($nightstart);
						$interval = $datetime1->diff($datetime2);
						echo "$calctimeout : $calctimein ".$interval->format('H:i:s');
				}
			}
			
	?>		
						