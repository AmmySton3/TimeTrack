<?php
include('includes/header.php');

if (isset($_SESSION['empno'])){
	$name=$_SESSION['name'];
	$empno=$_SESSION['empno'];
	$role=$_SESSION['role'];
}else{
	echo "<div class='txtResult'>You are not logged in</div>";
	exit;
}

if ($role!='ADMIN'){
	echo "<div class='txtResult'>You are not authorized to use this menu</div>";
	exit;
}

$phpself=$_SERVER['PHP_SELF'];
$readonly='';

if (!isset($_POST['submit']) or $_POST['submit']=='Cancel'){
	$postbutton='Add';
	$date='';
	$description='';
	$txtResult='';
}
elseif (isset($_POST['submit']) and $_POST['submit']=='Edit'){
	$date=$_POST['listofvalues'];
	$sql="SELECT * FROM holidays where date='$date' LIMIT 1";
	$query = $db_object->query($sql);
	if (DB::isError($query)) {
		$txtResult="The action was not successfull due to error -  <br><i> ".$query ->getMessage()."</i>";
	}
	if ($query->numRows()==0){
		$postbutton = 'Add';
		$date='';
		$description='';
		$txtResult='Please select an item from the list!';
	} else {
		$readonly='readonly';
		$info = $query->fetchRow();
		$postbutton='Save';
		$description=$info['holiday'];
		$date=formatdate($info['date']);
		$txtResult='Please make the necessary changes!';
	}
}
elseif (isset($_POST['submit']) and $_POST['submit']=='Delete') {
	$date=$_POST['listofvalues'];
	if ($date=='') {
		$txtResult='Please select an item from the list';
	} else {
		$txtResult='The item has been deleted successfully!';
		$sql="DELETE FROM holidays where date='$date'";
		$query = $db_object->query($sql);
		if (DB::isError($query)) {
			$txtResult="The item could not be deleted due to error - <br><i> ". $query ->getMessage()."</i>";
		}

	}
	$postbutton='Add';
	$date='';
	$description='';

}
elseif (isset($_POST['submit']) and $_POST['submit']=='Save') {
	if ($_POST['date']=='' or $_POST['date']==''){
		$txtResult='The date or description cannot be empty!';
	}else{
		$date=formatdate($_POST['date']);
		$description=$_POST['description'];
		$sql="UPDATE holidays set holiday='$description' where date='$date'";
		$query = $db_object->query($sql);
		$txtResult='Changes have been saved successfully!';
		if (DB::isError($query)) {
			$txtResult="Changes could not be saved due to error - <br><i> ". $query ->getMessage()."</i>";
		}
	}
	$postbutton='Add';
	$date='';
	$description='';

}
elseif (isset($_POST['submit']) and $_POST['submit']=='Add') {
	if ($_POST['date']=='' or $_POST['description']==''){
		$txtResult='The date or description cannot be empty!';
	}else{
		$date=unformatdate($_POST['date']);
		if (!get_magic_quotes_gpc()) {
			$description=addslashes($_POST['description']);
		}else{
			$description=$_POST['description'];

		}
		$txtResult='The item has been added successfully!';
		$sql="INSERT into holidays values ('$date','$description')";
		$query = $db_object->query($sql);
		if (DB::isError($query)) {
			$txtResult="The item could not be added due to error - <br><i> ". $query ->getMessage()."</i>";
		}
	}
	$postbutton='Add';
	$date='';
	$description='';
}

//retrieve List of Values
$year=date('Y');
$sql="SELECT * FROM holidays  where date_format(date, '%Y')='$year' order by date asc";

$query = $db_object->query($sql);
if (DB::isError($query)) {
	$listofvalues="The items could note be retrieved due error - <br><i>".$query ->getMessage()."</i>";
}
if ($query->numRows()==0){
	$listofvalues = "There are no items defined as yet!";
}else {
	$listofvalues =  "<select size='10' name='listofvalues'>";
	while ($info = $query->fetchRow()){
		$listofvalues = $listofvalues."<option value='".$info['date']."'>".$info['date']." - ".$info['holiday']."</option>";
	}
	$listofvalues= $listofvalues."</select>";
}

print <<<EOF

<div>
<h2>Setup Holidays</h2>
<table>
<tr>
<td style="vertical-align:top;">
<table style="border: dotted 1px #d9d9d9;">
<form name='main' action="$phpself" method='POST'>
<tr>
	<td class='rightcol'>Date: </td>
	<td class='leftcol'>
	<input type='text' name='date' value='$date' size='10' readonly onclick='showCalendarControl(this)' label='Click to select date'>
	</td>
</tr>
<tr>
	<td class='rightcol'>Description:</td>
	<td class='leftcol'><input type='text' name='description' value='$description' size='40'></td>
</tr>
<tr>
	<td colspan='2' class='rightcol'>
		<input type='submit' name='submit' value="Cancel">&nbsp;
		<input type='submit' name='submit' value="$postbutton">
		</td>
</tr>
</form>
</table>
<br/>
<div class="txtResult">
	$txtResult
</div>
</td>
<td style="vertical-align:top;">
<table style="border: dotted 1px #d9d9d9;">
<form name='listmain' action="$phpself" method='POST'>
<tr>
	<td class='rightcol' >
			$listofvalues
	</td>
</tr>
<tr>
	<td class='rightcol'>
		<input type='submit' name='submit' value='Edit'>&nbsp;
		<input type='submit' name='submit' value='Delete'>
	</td>
</tr>
</form>
</table>


</div>
EOF;
include('includes/footer.php');
?>

