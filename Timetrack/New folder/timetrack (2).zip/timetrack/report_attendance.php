<?php
include('includes/db_connect.php');
include('function.inc');

$phpself=$_SERVER['PHP_SELF'];
$readonly='';
$startdate='';
$enddate='';
$deptid='';

if (isset($_SESSION['empno'])){
	$name=$_SESSION['name'];
	$empno=$_SESSION['empno'];
	$role=$_SESSION['role'];
}else{
	echo "<div class='txtResult'>You are not logged in</div>";
	exit;
}

if ($role=='STAFF' or $role=='LOGS'){
	echo "<div class='txtResult'>You are not authorized to use this menu</div>";
	exit;
}

if ($role=='REPORT'){
	 $sql="select deptid from departments where superid='$empno'";
	 $query = $db_object->query($sql);
	 if (DB::isError($query)) {
		 $dept='0';
	 }elseif ($query->numRows()==0){
		$dept='0';
		
	}else {
		$start='';
		while ($info=$query->fetchRow()){
			$dept.=$start." ".$info['deptid'];
			$start=',';
		}
	} 
}else{
	 $sql="select deptid from departments";
	 $query = $db_object->query($sql);
	 if (DB::isError($query)) {
		 $dept='';
	 }elseif ($query->numRows()==0){
		$dept='';
		
	}else {
		$start='';
		while ($info=$query->fetchRow()){
			$dept.=$start." ".$info['deptid'];
			$start=',';
		}
	} 
}
if (!isset($_POST['submit']) or $_POST['submit']=='Cancel'){
	$txtResult='';

	$starter=true;
}
elseif (isset($_POST['submit']) and ($_POST['submit']=='Print')) {

		$startdate=$_POST['startdate'];
		if (($startdate=='')){
			$starter=true;
			$txtResult="The Date cannot be empty";
		}else{
			list ($d, $m, $y) = split ("/", $startdate);
			$startdate=date ("Y-m-d", mktime (0,0,0,$m,$d,$y));
			
		    	$sql="SELECT a.timelogged, b.employeeno, b.name, c.department, d.shiftgroup FROM accesslogs a, employees b, departments c, shiftgroups d where date(a.timelogged)='$startdate' and a.employeeno=b.employeeno and b.deptid=c.deptid and b.shiftgroupid=d.shiftgroupid and b.deptid in ($dept) order by b.deptid,  b.employeeno, a.timelogged, b.shiftgroupid";
			$starter=false;
			//echo $sql;


		}


}
if ($starter==true){


include('includes/header.php');

print <<<EOF

<div>
<h2>Attendance by Date</h2>
<div class="txtResult">
	$txtResult
</div>
<br/>
<table style="border: dotted 1px #d9d9d9;">
<form name='main' action="$phpself" method='POST' target='_blank'>

<tr>
	<td class='rightcol'>Date:</td>
	<td class='leftcol'><input type='text' name='startdate' value='$startdate' size='10' onclick="showCalendarControl(this)" label='Click to select date' $readonly></td>
	

</tr>


<tr>
	<td colspan='4' class='rightcol'>
		<input type='submit' name='submit' value='Cancel'>&nbsp;
		<input type='submit' name='submit' value='Print'>
		</td>
</tr>
</form>
</table>



</div>
EOF;
}elseif ($starter==false){
		list ($y, $m, $d) = split ("-", $startdate);
		$startdate=date ("d/m/Y", mktime (0,0,0,$m,$d,$y));
		
print <<<EOF
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml" xml:lang="en" lang="en">
<head>
<title>TimeTrack - Biometric Time & Attendance system</title>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<meta name="author" content="Burhani Infosys Ltd" />
<meta name="keywords" content="" />
<meta name="description" content="" />
<link href="favicon.ico" rel="shortcut icon" type="image/x-icon" />


<link href="css/site/print.css" media="screen" rel="stylesheet" type="text/css" />
<link href="css/site/CalendarControl.css" rel="stylesheet" type="text/css" />

<script src="js/sorttable.js"></script>

</head>
<body>

<div>
<h2>Attendance Report for $startdate</h2>
</div>
<br/>

EOF;
	//echo $sql;
	$query = $db_object->query($sql);


	if (DB::isError($query)) {
		 echo "<table class='sortable' style='border: dotted 1px #d9d9d9;' width='95%'>";
		 echo "<thead>";
		 echo "<tr>";
		 echo "<td>";
		 echo "Error - <i>".$query ->getMessage()."</i><br>";
		 echo "</td>";
		 echo "</tr>";
		 echo "</thead>";
		 echo "</table>";
	}elseif ($query->numRows()==0){
		echo "<table class='sortable' style='border: dotted 1px #d9d9d9;' width='95%'>";
		echo "<thead>";
		echo "<tr>";
		echo "<td>";
		echo "There are no data in the system in the range provided";
		echo "</td>";
		echo "</tr>";
		echo "</thead>";
		echo "</table>";
	}else {
		$prevdept='';
		$prevemp='';
		

		while ($info=$query->fetchRow()){


			$department=$info['department'];
			if ($prevdept!=$department){
				if($prevdept!=''){
					echo "</tbody>";
					echo "<tfoot>";
					echo "</tfoot>";
					echo "</table>";
				}
					echo "<table style='border: dotted 1px #d9d9d9;' width='95%'>";
					echo "<tr><td class='leftcol'><strong>Department: $department</strong> </td>";
					echo "<td class='rightcol'></td>";
					echo "</tr></table>";
					echo "<table class='sortable' style='border: dotted 1px #d9d9d9;' width='95%'>";
					echo "<thead>";
					echo "<tr>";
					echo "<td class='innerTDL' width='9%'>";
					echo "<u>Employee No</u>";
					echo "</td>";
					echo "<td class='innerTDL' width='25%'>";
					echo "<u>Name</u>";
					echo "</td>";
					echo "<td class='innerTDL' width='15%'>";
					echo "<u>Department</u>";
					echo "</td>";
					echo "<td class='innerTDL' width='15%'>";
					echo "<u>Shift Group</u>";
					echo "</td>";
					echo "<td class='innerTDL' width='28%'>";
					echo "<u>Time Logged In</u>";
					echo "</td>";
					echo "</tr>";
					echo "</thead>";

					echo "<tbody>";
			}
			
			if ($prevemp<>$info['employeeno']){
					echo "<tr>";
					echo "<td class='innerTDL'>";
					echo $info['employeeno'];
					$employeeno=$info['employeeno'];
					echo "</td>";
					echo "<td class='innerTDL'>";
					echo $info['name'];
					echo "</td>";
					echo "<td class='innerTDL'>";
					echo $info['department'];
					echo "</td>";
					echo "<td class='innerTDL'>";
					echo $info['shiftgroup'];
					echo "</td>";
					echo "<td class='innerTDL'>";
					$timein=$info['timelogged'];
					list ($di, $ti) = split (" ", $timein);
					echo $ti;
					echo "</td>";
					echo "</tr>";
			}


			$prevdept=$department;
			$prevemp=$info['employeeno'];

		}
		echo "</tbody>";
		echo "<tfoot>";
		echo "</tfoot>";
		echo "</table>";
	}


}
include('includes/footer.php');
?>

