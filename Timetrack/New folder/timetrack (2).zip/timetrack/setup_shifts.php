<?php
include('includes/header.php');

if (isset($_SESSION['empno'])){
	$name=$_SESSION['name'];
	$empno=$_SESSION['empno'];
	$role=$_SESSION['role'];
}else{
	echo "<div class='txtResult'>You are not logged in</div>";
	exit;
}

if ($role!='ADMIN'){
	echo "<div class='txtResult'>You are not authorized to use this menu</div>";
	exit;
}

$phpself=$_SERVER['PHP_SELF'];
$readonly='';
$starter=true;
$shiftgroupid='';
$txtResult='';
$dayofweekname=array('Monday','Tuesday','Wednesday','Thursday','Friday','Saturday','Sunday');
$dayofweek=array('1','2','3','4','5','6','7');
$starttime=array('08:00','08:00','08:00','08:00','08:00','00:00','00:00');
$endtime=array('17:00','17:00','17:00','17:00','17:00','00:00','00:00');
$workhours=array('9','9','9','9','9','0','0');
$breakhours=array('1','1','1','1','1','0', '0');
$normalday=array('Y','Y','Y','Y','Y','N','N');
$daychange=array('N','N','N','N','N','N','N');


if (!isset($_POST['submit']) or $_POST['submit']=='Cancel'){
	$postbutton='Add';
	$code='';
	$description='';
	$txtResult='';
	$starter=true;
}
elseif (isset($_POST['submit']) and $_POST['submit']=='Edit'){
	$code=$_POST['listofvalues'];
	$sql="SELECT * FROM shifts where shiftid='$code' LIMIT 1";
	$query = $db_object->query($sql);
	if (DB::isError($query)) {
		$txtResult="The action was not successfull due to error -  <br><i> ".$query ->getMessage()."</i>";
	}
	if ($query->numRows()==0){
		$postbutton = 'Add';
		$code='';
		$description='';
		$txtResult='Please select an item from the list!';
	} else {
		$readonly='readonly';
		$info = $query->fetchRow();
		$postbutton='Save';
		$description=$info['shiftname'];
		$code=$info['shiftid'];
		$shiftgroupid=$info['shiftgroupid'];
		$txtResult='Please make the necessary changes!';

		$sql2="SELECT * FROM shiftdetail where shiftid='$code' order by dayofweek";
		$query2 = $db_object->query($sql2);
		if (DB::isError($query2)) {
			$txtResult="The action was not successfull due to error -  <br><i> ".$query ->getMessage()."</i>";
		}
		if ($query2->numRows()==0){
			$txtResult='No Shift details founsds';
		} else {
			$i=0;
			while ($info2 = $query2->fetchRow()){
				$dayofweek[$i]=$info2['dayofweek'];
				$normalday[$i]=$info2['normalday'];
				$starttime[$i]=$info2['starttime'];
				$endtime[$i]=$info2['endtime'];
				$workhours[$i]=$info2['workhours'];
				$breakhours[$i]=$info2['breakhours'];
				$daychange[$i]=$info2['daychange'];
				$i++;
			}
		}

	}
	$starter=false;
}
elseif (isset($_POST['submit']) and $_POST['submit']=='Delete') {
	$code=$_POST['listofvalues'];
	if ($code=='') {
		$txtResult='Please select an item from the list';
	} else {
		$txtResult='The item has been deleted successfully!';
		$sql="DELETE FROM shifts where shiftid='$code'";
		$query = $db_object->query($sql);
		$sql="DELETE FROM shiftdetail where shiftid='$code'";
		$query = $db_object->query($sql);

		if (DB::isError($query)) {
			$txtResult="The item could not be deleted due to error - <br><i> ". $query ->getMessage()."</i>";
		}

	}
	$postbutton='Add';
	$code='';
	$description='';
	$starter=true;

}
elseif (isset($_POST['submit']) and $_POST['submit']=='Save') {
	if ($_POST['code']=='' or $_POST['description']==''){
		$txtResult='The code or description cannot be empty!';
	}else{
		$code=$_POST['code'];
		$shiftgroupid=$_POST['shiftgroupid'];
		$description=$_POST['description'];
		$sql="UPDATE shifts set shiftname='$description', shiftgroupid='$shiftgroupid' where shiftid='$code'";
		$query = $db_object->query($sql);
		$txtResult='Changes have been saved successfully!';
		if (DB::isError($query)) {
			$txtResult="Changes could not be saved due to error - <br><i> ". $query ->getMessage()."</i>";
		}
		for ($i=0; $i<7; $i++){
			$dayofweek[$i]=$_POST['dayofweek'][$i];
			$starttime[$i]=$_POST['starttime'][$i];
			$endtime[$i]=$_POST['endtime'][$i];
			$workhours[$i]=$_POST['workhours'][$i];
			$breakhours[$i]=$_POST['breakhours'][$i];

			if (isset($_POST['daychange'][$i])){
				$daychange[$i]=$_POST['daychange'][$i];
			}else{
				$daychange[$i]='N';
			}
			if (isset($_POST['normalday'][$i])){
				$normalday[$i]=$_POST['normalday'][$i];
			}else{
				$normalday[$i]='N';
			}
		}
		for ($i=0; $i<7; $i++){
			$sql2="UPDATE shiftdetail set dayofweek='$dayofweek[$i]',
										starttime='$starttime[$i]',
										endtime='$endtime[$i]',
										daychange='$daychange[$i]',
										normalday='$normalday[$i]',
										workhours='$workhours[$i]',
										breakhours='$breakhours[$i]'
						where shiftid='$code' and dayofweek='$dayofweek[$i]'";
			$query2 = $db_object->query($sql2);
			$txtResult='Changes have been saved successfully!';
			if (DB::isError($query2)) {
				$txtResult="Changes could not be saved due to error - <br><i> ". $query2 ->getMessage()."</i>";
			}

		}
	}
	$postbutton='Add';
	$code='';
	$description='';
	$starter=true;

}
elseif (isset($_POST['submit']) and $_POST['submit']=='Setup') {
	if ($_POST['shiftgroupid']==''){
		$txtResult='The Shift group cannot be empty!';
	}else{
		$shiftgroupid=$_POST['shiftgroupid'];
	}
	$postbutton='Add';
	$code='';
	$description='';
	$starter=false;
	$txtResult='';

}
elseif (isset($_POST['submit']) and $_POST['submit']=='Add') {
	if ($_POST['description']==''){
		$txtResult='The description cannot be empty!';
	}else{
		$shiftgroupid=$_POST['shiftgroupid'];
		if (!get_magic_quotes_gpc()) {
			$description=addslashes($_POST['description']);
		}else{
			$description=$_POST['description'];

		}
		$txtResult='The item has been added successfully!';
		$sql="INSERT into shifts (shiftname, shiftgroupid) values ('$description','$shiftgroupid')";
		$query = $db_object->query($sql);
		if (DB::isError($query)) {
			$txtResult="The item could not be added due to error - <br><i> ". $query ->getMessage()."</i>";
		}

		for ($i=0; $i<7; $i++){
			$dayofweek[$i]=$_POST['dayofweek'][$i];
			$starttime[$i]=$_POST['starttime'][$i];
			$endtime[$i]=$_POST['endtime'][$i];
			$workhours[$i]=$_POST['workhours'][$i];
			$breakhours[$i]=$_POST['breakhours'][$i];


			if (isset($_POST['daychange'][$i])){
				$daychange[$i]=$_POST['daychange'][$i];
			}else{
				$daychange[$i]='N';
			}
			if (isset($_POST['normalday'][$i])){
				$normalday[$i]=$_POST['normalday'][$i];
			}else{
				$normalday[$i]='N';
			}
		}
		$code=mysql_insert_id();
		for ($i=0; $i<7; $i++){
			$sql2="insert into shiftdetail (shiftid, dayofweek,starttime,endtime,daychange,normalday,workhours,breakhours)
					values ('$code',
							'$dayofweek[$i]',
							'$starttime[$i]',
							'$endtime[$i]',
							'$daychange[$i]',
							'$normalday[$i]',
							'$workhours[$i]',
							'$breakhours[$i]'
						)";
			$query2 = $db_object->query($sql2);
			$txtResult='Changes have been saved successfully!';
			if (DB::isError($query2)) {
				$txtResult="Changes could not be saved due to error - <br><i> ". $query2 ->getMessage()."</i>";
			}

		}
	}
	$postbutton='Add';
	$code='';
	$description='';
	$starter=true;
}

//retrieve Shiftgroups
if ($starter==true){
	$sql="SELECT * FROM shiftgroups order by shiftgroup asc";

	$query = $db_object->query($sql);
	if (DB::isError($query)) {
		$txtResult="The items could note be retrieved due error - <br><i>".$query ->getMessage()."</i>";
	}
	if ($query->numRows()==0){
		$shiftgroup = "There are no items defined as yet!";
	}else {
		$shiftgroup =  "<select name='shiftgroupid'>";
		while ($info = $query->fetchRow()){
			$shiftgroup = $shiftgroup."<option value='".$info['shiftgroupid']."' ";
			$shiftgroup= $shiftgroup." >".$info['shiftgroup']."</option>";
		}
		$shiftgroup = $shiftgroup ."</select>";
	}
}else{
	$sql="SELECT * FROM shiftgroups where shiftgroupid='$shiftgroupid'";

	$query = $db_object->query($sql);
	if (DB::isError($query)) {
		$txtResult="The items could note be retrieved due error - <br><i>".$query ->getMessage()."</i>";
	}else{
		$info = $query->fetchRow();
		$shiftgroup="<input type='hidden' name='shiftgroupid' value='".$info['shiftgroupid']."'>";
		$shiftgroup= $shiftgroup."<input type='text' name='shiftgroup' size='40' readonly value='".$info['shiftgroup']."'>";
	}

}


//retrieve List of Values
$sql="SELECT * FROM shifts where shiftgroupid='$shiftgroupid' order by shiftname asc";

$query = $db_object->query($sql);
if (DB::isError($query)) {
	$listofvalues="The items could note be retrieved due error - <br><i>".$query ->getMessage()."</i>";
}
if ($query->numRows()==0){
	$listofvalues = "There are no items defined as yet!";
}else {
	$listofvalues =  "<select size='10' name='listofvalues'>";
	while ($info = $query->fetchRow()){
		$listofvalues = $listofvalues."<option value='".$info['shiftid']."'>".$info['shiftname']."</option>";
	}
	$listofvalues= $listofvalues."</select>";
}
print <<<EOF

<div>
<h2>Setup Shifts</h2>
EOF;
if ($starter==true){
print <<<EOF
<table>
<tr>
<td style="vertical-align:top;" colspan="2">
<table style="border: dotted 1px #d9d9d9;">
<form name='main' action="$phpself" method='POST'>
<tr>
	<td class='rightcol'>Select Shift Group:</td>
	<td class='leftcol'>$shiftgroup</td>
</tr>
<tr>
	<td colspan='2' class='rightcol'>
			<input type='submit' name='submit' value="Setup">
		</td>
</tr>
</form>
</table>
<br/>
<div class="txtResult">
	$txtResult
</div>
</td>
</tr>
</table>
EOF;
}else{
print <<<EOF
<table>
<tr>
<td style="vertical-align:top;">
<table style="border: dotted 1px #d9d9d9;">
<form name='main' action="$phpself" method='POST'>
<tr>
	<td class='rightcol'>Shift Name:</td>
	<td class='leftcol'><input type='hidden' name='code' value='$code' size='6' $readonly>
	<input type='text' name='description' value='$description' size='40'></td>
</tr>
<tr>
	<td class='rightcol'>Shift Group:</td>
	<td class='leftcol'>$shiftgroup</td>
</tr>

<tr>
	<td colspan='2' class='leftcol' style="vertical-align:top;"><br/><br/>Shift Details:</td>
</tr>
<tr>
	<td colspan='2' class='leftcol' style="vertical-align:top;">

	<table >
	 <tr style="text-align:center; font-weight:bold;">

		<td ></td>
		<td>Nd </td>
		<td>In </td>
		<td>Dc </td>
		<td>Out </td>
		<td>Wrk Hr</td>
		<td>Brk Hr</td>


	 </tr>
EOF;
	for ($i=0; $i<7; $i++){

print <<<EOF
	  <tr>
		<td><input type='hidden' name='dayofweek[$i]' value='$dayofweek[$i]'><strong>$dayofweekname[$i]</strong>
		<td><input type='checkbox' name='normalday[$i]' value='Y'
EOF;
	if($normalday[$i]=='Y') echo 'checked';
print <<<EOF
		></td>
		<td><input type='text' name='starttime[$i]' value='$starttime[$i]' size='5'></td>
		<td><input type='checkbox' name='daychange[$i]' value='Y'
EOF;
	if($daychange[$i]=='Y') echo 'checked';
print <<<EOF
		></td>
		<td><input type='text' name='endtime[$i]' value='$endtime[$i]' size='5'></td>
		<td><input type='text' name='workhours[$i]' value='$workhours[$i]' size='2'></td>
		<td><input type='text' name='breakhours[$i]' value='$breakhours[$i]' size=2'></td>


	 </tr>
EOF;
	}
print <<<EOF
	</table>

	</td>
</tr>
<tr>
	<td colspan='2' class='rightcol'>
		<input type='submit' name='submit' value="Cancel">&nbsp;
		<input type='submit' name='submit' value="$postbutton">
		</td>
</tr>
</form>
</table>
<br/>
<div class="txtResult">
	$txtResult
</div>

</td>
<td style="vertical-align:top;">
<table style="border: dotted 1px #d9d9d9;">
<form name='listmain' action="$phpself" method='POST'>
<tr>
	<td class='rightcol' >
			$listofvalues
	</td>
</tr>
<tr>
	<td class='rightcol'>
		<input type='submit' name='submit' value='Edit'>&nbsp;
		<input type='submit' name='submit' value='Delete'>
	</td>
</tr>
</form>
</table>

</td>
</tr>
</table>

</div>
EOF;
}
include('includes/footer.php');
?>

