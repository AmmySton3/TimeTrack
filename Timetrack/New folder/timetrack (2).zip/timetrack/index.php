<?php

include('includes/db_connect.php');

$phpself=$_SERVER['PHP_SELF'];
$readonly='';
$starter=true;
$postbutton='Login';
$username='';
$password='';

if (isset($_SESSION['empno'])){
	$starter=false;
}

if (!isset($_POST['submit']) or $_POST['submit']=='Cancel'){
	$postbutton='Login';
	$username='';
	$password='';
	$txtResult='';
}
elseif (isset($_POST['submit']) and $_POST['submit']=='Login') {
	if ($_POST['username']=='' or $_POST['password']==''){
		$txtResult='The username or password cannot be empty!';
	}else{
		$username=$_POST['username'];
		$password=md5($_POST['password']);
		$sql="select employeeno, name,role, active, canlogin, last_login from employees where username='$username' and password='$password' LIMIT 1";
		$query = $db_object->query($sql);
		if (DB::isError($query)) {
			$txtResult="The action could not be completed due to error - <br><i> ". $query ->getMessage()."</i>";
		}elseif ($query->numRows()==0){
			$txtResult='The username or password does not match';
			$username='';
			$password='';
		}else{
			$info = $query->fetchRow();
			if ($info['active']!='A'){
				$txtResult='Your account is inactive';
				$username='';
				$password='';
			}elseif ($info['canlogin']!='Y'){
				$txtResult='Your account is not allowed to login';
				$username='';
				$password='';
			}else{
				$_SESSION['empno']=$info['employeeno'];
				$_SESSION['role']=$info['role'];
				$_SESSION['name']=$info['name'];
				$_SESSION['last_login']=$info['last_login'];
				$starter=false;
				$today=date('Y-m-d');
				$sql="update employees set last_login='$today' where employeeno='".$_SESSION['empno']."'";
				$query = $db_object->query($sql);
				header("Location: $phpself");
				exit;
			}
		}


	}

}
include('includes/header.php');

if ($starter==true){
print <<<EOF

<div style="align:centre; vertical-align:middle;">
<h2>Login</h2>
<div class="txtResult">
	$txtResult
</div>
<table style="border: dotted 1px #d9d9d9;align:centre; vertical-align:middle;">
<form name='main' action="$phpself" method='POST'>
<tr>
	<td class='rightcol'>Username: </td>
	<td class='leftcol'><input type='text' name='username' value='$username' size='15'></td>
</tr>
<tr>
	<td class='rightcol'>Password:</td>
	<td class='leftcol'><input type='password' name='password' value='$password' size='15'></td>
</tr>
<tr>
	<td colspan='2' class='rightcol'>
		<input type='submit' name='submit' value="$postbutton">
		</td>
</tr>
</form>
</table>
<br/>

</div>
EOF;
}else{
include('dashboard.php');
}
include('includes/footer.php');
?>

