<?php
include('includes/header.php');

error_reporting(E_ERROR);
date_default_timezone_set('Africa/Dar_es_Salaam');

mysql_connect("localhost", "root", "burhani53") or die (mysql_error());
mysql_select_db("timetrack") or die (mysql_error());





$phpself=$_SERVER['PHP_SELF'];
$readonly='';
$txtResult='';
$remarks='';


function convertTime($t){
	list($h, $m, $s)=split(':',$t);
	return $h*60*60 + $m*60 + $s;
}

	$destination="C:\\sagem\\transactions.csv";

		$row = 0;
		$v=0;
		$i=0;
		$today=date('Y-m-d H:i:s');
		if (($handle = fopen("$destination", "r")) !== FALSE) {
			while (($data = fgetcsv($handle, 1000, ",")) !== FALSE) {
				$num = count($data);
				$row++;
				$v++;
				if ($data[2]<>''){
					$empnumber=(int)$data[5];
					$empnumber=ltrim($data[2], '0');
					$sql="insert into accesslogs (timelogged, identtype, employeeno, processed, device, uploadedby, uploadedon)
							values ((select date_format(str_to_date('$data[0]','%Y%m%d%H%i%s'), '%Y-%m-%d %H:%i:%s')),'$data[5]','$empnumber', 'N', '$data[1]', '$empno', '$today')";
							//echo $sql."<br/>";
					$result = mysql_query($sql);
					if (!$result) {

					}else{
						$i++;
					}
				}
				
			}
			fclose($handle);
		}
		$txtResult="$row in total; $i inserted into the logs";
		$yesterday=date('Y-m-d', strtotime("-1 day"));
	
	if ($i>=0){
			$lastweek=date('Y-m-d', strtotime("-1 week +1 day"));
			$sql="update accesslogs set processed='Y' where date(timelogged)='$lastweek' and processed='N' order by employeeno, timelogged";
			$result = mysql_query($sql);
			$sql="select * from accesslogs where processed='N' order by employeeno, timelogged";
			$result = mysql_query($sql);
			if (!$result) {
				echo "Error -<i>".mysql_error()."</i>";
			}elseif (mysql_num_rows($result) > 0){
				$prev_employeeno="";
				$prev_timelogged="";
				$prev_identtype="";
				$lastcomplete=false;

while ($info=mysql_fetch_assoc($result)){
					$curr_employeeno=$info['employeeno'];
					$curr_timelogged=$info['timelogged'];
					$curr_identtype=$info['identtype'];
					
					if ($curr_employeeno==$prev_employeeno){
						if ($curr_identtype=='IN' and $prev_identtype=='OUT'){

						}elseif ($curr_identtype=='OUT' and $prev_identtype=='IN'){
							$employeeno=$curr_employeeno;
							$timein=$prev_timelogged;
							$timeout=$curr_timelogged;
							$datelogged=$timein;
							
							$sql="insert into timetrack (date, employeeno, status, timein, timeout, processed) values ('$datelogged', '$employeeno', 'A', '$timein','$timeout','N')";
							$result2 = mysql_query($sql);
							if (!$result2) {
								echo "Error -<i>".mysql_error()."</i>";
							}
							$sql="update accesslogs set processed='Y' where timelogged='$prev_timelogged' and  employeeno='$prev_employeeno' and identtype='$prev_identtype'";
							$result2 = mysql_query($sql);
							if (!$result2) {
								echo "Error -<i>".mysql_error()."</i>";
							}
							$sql="update accesslogs set processed='Y' where timelogged='$curr_timelogged' and  employeeno='$curr_employeeno' and identtype='$curr_identtype'";
							$result2 = mysql_query($sql);
							if (!$result2) {
								echo "Error -<i>".mysql_error()."</i>";
							}
						}elseif ($curr_identtype=='IN' and $prev_identtype=='OUT'){
							$employeeno=$curr_employeeno;
							$timein=$prev_timelogged;
							$timeout='';
							$datelogged=$timein;
							$sql="insert into timetrack (date, employeeno, status, timein, timeout, processed) values ('$datelogged', '$employeeno','E', '$timein','$timeout','N')";
							$result2 = mysql_query($sql);
							if (!$result2) {
								echo "Error -<i>".mysql_error()."</i>";
							}
							$sql="update accesslogs set processed='Y' where timelogged='$prev_timelogged' and  employeeno='$prev_employeeno' and identtype='$prev_identtype'";
							$result2 = mysql_query($sql);
							if (!$result2) {
								echo "Error -<i>".mysql_error()."</i>";
							}
						}elseif ($curr_identtype=='OUT' and  $prev_identtype=='OUT'){
							$employeeno=$curr_employeeno;
							$timein='';
							$timeout=$curr_timelogged;
							$datelogged=$timeout;
							$sql="insert into timetrack (date, employeeno, status, timein, timeout, processed) values ('$datelogged', '$employeeno', 'E', '$timein','$timeout','N')";
							$result2 = mysql_query($sql);
							if (!$result2) {
								echo "Error -<i>".mysql_error()."</i>";
							}
							$sql="update accesslogs set processed='Y' where timelogged='$curr_timelogged' and  employeeno='$curr_employeeno' and identtype='$curr_identtype'";
							$result2 = mysql_query($sql);
							if (!$result2) {
								echo "Error -<i>".mysql_error()."</i>";
							}
						}
					}
					$prev_employeeno=$curr_employeeno;
					$prev_timelogged=$curr_timelogged;
					$prev_identtype=$curr_identtype;
					


				}
			}



		}
/**
		$sql7="update accesslogs set processed='D' where date(timelogged)<'$yesterday' and processed='N'";
		$query7 = $db_object->query($sql7);
		if (DB::isError($query7)) {
			echo "Error here -<i>".$query7 ->getMessage()."</i>";

		}
**/

		$sql3="select * from timetrack a, employees b where processed='N' and a.employeeno=b.employeeno";
		$result3 = mysql_query($sql3);
		if (!$result3) {
			echo "Error -<i>".$mysql_error()."</i>";
		}elseif (mysql_num_rows($result3) >0){
			while ($info3=mysql_fetch_assoc($result3)){
				$date=$info3['date'];
				$employeeno=$info3['employeeno'];
				$timein=$info3['timein'];
				$timeout=$info3['timeout'];
				$shiftgroupid=$info3['shiftgroupid'];
				$dayofweek=date('N', strtotime($date));
				//echo $date." ".$dayofweek." ".$employeeno."<br/>";
				list ($di, $ti)=split(' ', $timein);
				list ($do, $to)=split(' ', $timeout);
				if ($timein!='0000-00-00 00:00:00' and $timeout!='0000-00-00 00:00:00'){
					$sql2="select a.shiftid,
								b.dayofweek,
								b.starttime,
								b.endtime,
								b.normalday,
								b.daychange,
								b.workhours,
								b.breakhours,
								time_to_sec(timediff('$ti',starttime)) startdiff,
								time_to_sec(timediff('$to',endtime)) enddiff,
								min(abs(time_to_sec(timediff('$ti',starttime)))) startdiffmin,
								min(abs(time_to_sec(timediff('$to',endtime)))) enddiffmin
							from shifts a, shiftdetail b where b.dayofweek='$dayofweek' and a.shiftgroupid='$shiftgroupid' and a.shiftid=b.shiftid
							group by a.shiftid, b.dayofweek, b.starttime, b.endtime, b.normalday, b.daychange, b.workhours, b.breakhours order by startdiffmin limit 1";
					$result2 = mysql_query($sql2);
					if (!$result2) {
						echo "Error -<i>".mysql_error()."</i>";
					}elseif (mysql_num_rows($result2) >0){
						$info2=mysql_fetch_assoc($result2);
						$shiftid=$info2['shiftid'];
						$starttime=$info2['starttime'];
						$endtime=$info2['endtime'];
						$startdiff=$info2['startdiff'];
						$enddiff=$info2['enddiff'];
						$startdiffmin=$info2['startdiffmin'];
						$enddiffmin=$info2['enddiffmin'];
						$hrstowork=$info2['workhours'];
						$dayofweek=$info2['dayofweek'];

						$latein=0;
						$earlyin=0;
						$lateout=0;
						$earlyout=0;

						if ($startdiff>0){
							if ($startdiffmin>15){
								$remark="Late In";
								$latein=1;
								$calctimein=$di." ".$ti;
							}else{
								$remark="Late In";
								$latein=1;
								$calctimein=$di." ".$starttime;
							}
						}else{
							$remark="Early In";
							$earlyin=1;
							$calctimein=$di." ".$starttime;
						}
						
						if ($enddiff>0){
							if ($enddiffmin>15){
								$remark.=", Late Out";
								$lateout=1;
								$calctimeout=$do." ".$to;
							}else{
								$remark.=", Late Out";
								$lateout=1;
								$calctimeout=$do." ".$to;
							}
						}else{
							if ($enddiffmin>15){
								$remark.=", Early Out";
								$earlyout=1;
								$calctimeout=$do." ".$to;
							}else{
								$remark.=", Early Out";
								$earlyout=1;
								$calctimeout=$do." ".$endtime;
							}
						}
						$sql4="update timetrack set shiftid='$shiftid', shifttimein='$starttime', shifttimeout='$endtime', hourstowork='$hrstowork', dayofweek='$dayofweek', earlyin='$earlyin', earlyout='$earlyout', latein='$latein', lateout='$lateout', remarks='$remark', calctimein='$calctimein', calctimeout='$calctimeout'
								where employeeno='$employeeno' and date='$date' and timein='$timein' and timeout='$timeout'";
						$result4 = mysql_query($sql4);
						if (!$result4) {
							echo "Error -<i>".mysql_error()."</i>";
						}
					}
				}
			}
		}

		$sql5="update timetrack set processed='Y', wrkhrs_time=timediff(timeout, timein), wrkhrs=((time_to_sec(timediff(timeout, timein))/60)/60),
			calchrs_time=timediff(calctimeout, calctimein), calchrs=((time_to_sec(timediff(calctimeout, calctimein))/60)/60),holidayhrs_time='00:00:00', holidayhrs='0.00', overtimehours=(((time_to_sec(timediff(calctimeout, calctimein))/60)/60)-hourstowork), doublehours='0'
					where (date not in (select date from holidays) and dayofweek<7) and processed='N'";
		$result5 = mysql_query($sql5);
		if (!$result5) {
			echo "Error -<i>".mysql_error()."</i>";
		}else{
			echo 'dpme';
		}
		$sql6="update timetrack set processed='Y', wrkhrs_time=timediff(timeout, timein), wrkhrs=((time_to_sec(timediff(timeout, timein))/60)/60),
			calchrs_time=timediff(calctimeout, calctimein), calchrs=((time_to_sec(timediff(calctimeout, calctimein))/60)/60),holidayhrs_time='00:00:00', holidayhrs='0.00', earlyin='0', earlyout='0', latein='0', lateout='0', remarks='Worked on a Holiday', doublehours=(((time_to_sec(timediff(calctimeout, calctimein))/60)/60)-hourstowork), overtimehours='0'
					where date in (select date from holidays) and processed='N'";
		$result6 = mysql_query($sql6);
		if (!$result6) {
			echo "Error -<i>".mysql_error()."</i>";
		}
		$sql7="update timetrack set processed='Y', wrkhrs_time=timediff(timeout, timein), wrkhrs=((time_to_sec(timediff(timeout, timein))/60)/60),
			calchrs_time=timediff(calctimeout, calctimein), calchrs=((time_to_sec(timediff(calctimeout, calctimein))/60)/60),holidayhrs_time='00:00:00', holidayhrs='0.00', earlyin='0', earlyout='0', latein='0', lateout='0', remarks='Worked on a Sunday', doublehours=(((time_to_sec(timediff(calctimeout, calctimein))/60)/60)-hourstowork), overtimehours='0'
					where dayofweek=7 and processed='N'";
		$result7 = mysql_query($sql7);
		if (!$result7) {
			echo "Error -<i>".mysql_error()."</i>";
		}
		//calculating nighthours between 8PM and 6AM
		
		//$sql7="update timetrack set nighthours=(calchrs-abs((time_to_sec(timediff(calctimein, concat(date,' 20:00:00')))/60)/60)-abs((time_to_sec(timediff(calctimeout, concat(date(calctimeout),' 06:00:00')))/60)/60)), nightstatus='C' where nightstatus<>'C' and ((time_to_sec(timediff(calctimeout, concat(date,' 20:00:00')))/60)/60)>0";
		//$query7 = $db_object->query($sql7);
		//$sql8="update timetrack set nighthours=0, nightstatus='C' where nightstatus<>'C' and ((time_to_sec(timediff(calctimeout, concat(date,' 20:00:00')))/60)/60)<=0";
		//$query8 = $db_object->query($sql8);
		$sql7="select * from timetrack where nightstatus<>'C' and status<>'E'";
		$result7 = mysql_query($sql7);
		if (!$result7) {
			echo "Error -<i>".mysql_error()."</i>";
		}elseif (mysql_num_rows($result7)>0){
			//echo 'here';
			while ($info7=mysql_fetch_assoc($result7)){
				$nighthrs=0;
				$calctimein=$info7['calctimein'];
				
				$calctimeout=$info7['calctimeout'];
				$ndate=$info7['date'];
				$ndate2=$info7['date'];
				$nemployeeno=$info7['employeeno'];
				$ntimein=$info7['timein'];
				$start=$ndate.' 20:00:00';
				$starttime=new DateTime($start);
				$end=$ndate2.' 06:00:00';
				$endtime=new DateTime($end);
				$endtime->add(new DateInterval('P1D'));
				
				
				$calctimein=new DateTime($info7['calctimein']);
				$calctimeout=new DateTime($info7['calctimeout']);
				
				
				if ($calctimein<=$starttime and $calctimeout>=$starttime){
					//echo "here ";
					if ($calctimeout<=$endtime){
						$nighthrs=$calctimeout->diff($starttime)->format("%H:%i:%s");
					}else{
						$nighthrs=$endtime->diff($starttime)->format("%H:%i:%s");
					}
				}
				if ($calctimein>=$starttime and $calctimeout>=$starttime){
					//echo "there ";
					if ($calctimeout<=$endtime){
						$nighthrs=$calctimeout->diff($calctimein)->format("%H:%i:%s");
					}else{
						$nighthrs=$endtime->diff($calctimein)->format("%H:%i:%s");
					}
				}
				list ($h, $m, $s)=explode(':',$nighthrs);
				$nighthrs=round($h+($m+$s/60)/60,2);
				$sql8="update timetrack set nighthours='$nighthrs', nightstatus='C' where employeeno='$nemployeeno' and  date='$ndate' and  timein='$ntimein'";
				mysql_query($sql8);
		
			}	

		}

	
	


print <<<EOF

<div>
<h2>Upload Log file</h2>
<div class="txtResult">
	$txtResult
</div>
<br/>
<table>
<tr>
<td style="vertical-align:top; padding-right:3em;">
<table style="border: dotted 1px #d9d9d9; vertical-align:top;">
<form name='main' action="$phpself" method='POST' ENCTYPE="multipart/form-data" >
<tr>
	<td class='rightcol'>Log file: </td>
	<td class='leftcol'><input type='file' name='logfile' value='' size='25'></td>
</tr>
<tr>
	<td colspan='2' class='rightcol'>
		<input type='submit' name='submit' value='Upload'>
	</td>
</tr>
</div>
EOF;
include('includes/footer.php');
?>

