<?php
include('includes/header.php');

$phpself=$_SERVER['PHP_SELF'];
$readonly='';
if (isset($_SESSION['userid'])){
	$username=$_SESSION['fname']." ".$_SESSION['lname'];
	$userid=$_SESSION['userid'];
	$role=$_SESSION['role'];
}else{
	echo "<div class='txtResult'>You are not logged in</div>";
	exit;
}
$starter=true;
$txtResult="Please make the necesary changes";

if (isset($_POST['submit']) and ($_POST['submit']=='Save')) {
	if ($_POST['uid']==''){
		$txtResult='The User ID cannot be empty!';
	}else{
		$fname=$_POST['fname'];
		$lname=$_POST['lname'];
		$address1=$_POST['address1'];
		$officetel=$_POST['officetel'];
		$officecell=$_POST['officecell'];
		$hometel=$_POST['hometel'];
		$homecell=$_POST['homecell'];
		$emailadd=$_POST['emailadd'];
		$city=$_POST['city'];

		$sql="UPDATE users set	fname='$fname',
								lname='$lname',
								address1='$address1',
								officetel='$officetel',
								officecell='$officecell',
								city='$city',
								hometel='$hometel',
								homecell='$homecell',
								emailadd='$emailadd'
							where userid='$userid'";

		$query = $db_object->query($sql);
		$txtResult="The changes has been saved successfully!<br>";
		if (DB::isError($query)) {
			$txtResult="The changes could not be added due to error - <br><i> ". $query ->getMessage()."</i>";
			$postbutton='Add';
		}else{
			$postbutton='Add';
			$uid='';
			$fname='';
			$lname='';
			$address1='';
			$officeid='';
			$officetel='';
			$officecell='';
			$hometel='';
			$homecell='';
			$emailadd='';
			$city='';
			$readonly='';

		}
	}

}
$sql="select * from users where userid='$userid' LIMIT 1";
$query = $db_object->query($sql);
if (DB::isError($query)) {
	$txtResult="The User could not be retrieved due to error - <br><i> ". $query ->getMessage()."</i>";
	$postbutton='Add';
}else{
	$info = $query->fetchRow();
	$postbutton='Save';
	$uid=$info['userid'];
	$fname=$info['fname'];
	$lname=$info['lname'];
	$address1=$info['address1'];
	$officeid=$info['officeid'];
	$officetel=$info['officetel'];
	$officecell=$info['officecell'];
	$hometel=$info['hometel'];
	$homecell=$info['homecell'];
	$emailadd=$info['emailadd'];
	$username=$info['username'];
	$role=$info['role'];
	$superid=$info['superid'];
	$repositoryid=$info['repositoryid'];
	$readonly='readonly';
	$city=$info['city'];


}

print <<<EOF
<h2>Edit My Profile</h2>
<div class="txtResult">
	$txtResult
</div><table style="border: dotted 1px #d9d9d9;">
<form name='main' action="$phpself" method='POST' onSubmit="return checkform(this)">
<tr>
	<td class='rightcol'>User ID: </td>
	<td class='leftcol' colspan='3'><input type='text' name='uid' value='$uid' size='15' $readonly></td>
</tr>
<tr>
	<td class='rightcol'>First Name:</td>
	<td class='leftcol' colspan='3'><input type='text' name='fname' value='$fname' size='35'></td>
</tr>
<tr>
	<td class='rightcol'>Last Name:</td>
	<td class='leftcol' colspan='3'><input type='text' name='lname' value='$lname' size='35'></td>

</tr>

<tr>
	<td class='rightcol' style="padding-top:0.5em;">Address (1):</td>
	<td class='leftcol' colspan='3' style="padding-top:0.5em;">
		<input type='text' name='address1' value='$address1' size='35' ></td>

</tr>

<tr>
	<td class='rightcol'>City:</td>
	<td class='leftcol' colspan='3'>
		<input type='text' name='city' value='$city' size='25'></td>
</tr>
<tr>
	<td class='rightcol'  style="padding-top:0.5em;">Office Tel:</td>
	<td class='leftcol'   style="padding-top:0.5em;"><input type='text' name='officetel' value='$officetel' size='13' ></td>
	<td class='rightcol'  style="padding-top:0.5em;">Cell:</td>
	<td class='leftcol'   style="padding-top:0.5em;"><input type='text' name='officecell' value='$officecell' size='13' ></td>
</tr>
<tr>
	<td class='rightcol'>Home Tel:</td>
	<td class='leftcol' ><input type='text' name='hometel' value='$hometel' size='13'></td>
	<td class='rightcol'>Cell:</td>
	<td class='leftcol' ><input type='text' name='homecell' value='$homecell' size='13'></td>
</tr>
<tr>
	<td class='rightcol'>Email:</td>
	<td class='leftcol' colspan='3'><input type='text' name='emailadd' value='$emailadd' size='35' ></td>

</tr>
<tr>
	<td colspan='4' class='rightcol'>
		<input type='submit' name='submit' value='Cancel'>&nbsp;
		<input type='submit' name='submit' value='Save'>
		</td>
</tr>
</form>
</table>
</table>


EOF;

include('includes/footer.php');
?>