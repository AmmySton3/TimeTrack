<?php




include('includes/db_connect.php');
include('function.inc');

$phpself=$_SERVER['PHP_SELF'];
$readonly='';
$startdate='';
$enddate='';
$deptid='';

if (isset($_SESSION['empno'])){
	$name=$_SESSION['name'];
	$empno=$_SESSION['empno'];
	$role=$_SESSION['role'];
}else{
	echo "<div class='txtResult'>You are not logged in</div>";
	exit;
}

if ($role=='STAFF' or $role=='LOGS'){
	echo "<div class='txtResult'>You are not authorized to use this menu</div>";
	exit;
}

if ($role=='REPORT'){
	 $sql="select deptid from departments where superid='$empno'";
	 $query = $db_object->query($sql);
	 if (DB::isError($query)) {
		 $dept='0';
	 }elseif ($query->numRows()==0){
		$dept='0';
		
	}else {
		$start='';
		while ($info=$query->fetchRow()){
			$dept.=$start." ".$info['deptid'];
			$start=',';
		}
	} 
}else{
	 $sql="select deptid from departments";
	 $query = $db_object->query($sql);
	 if (DB::isError($query)) {
		 $dept='';
	 }elseif ($query->numRows()==0){
		$dept='';
		
	}else {
		$start='';
		while ($info=$query->fetchRow()){
			$dept.=$start." ".$info['deptid'];
			$start=',';
		}
	} 
}
if (!isset($_POST['submit']) or $_POST['submit']=='Cancel'){
	$txtResult='';

	$starter=true;
}
elseif (isset($_POST['submit']) and ($_POST['submit']=='Print')) {

		$deptid=$_POST['deptid'];
		$startdate=$_POST['startdate'];
		$enddate=$_POST['enddate'];

		if (($startdate=='' or $enddate=='') or  ($deptid=='')){
			$starter=true;
			$txtResult="The Department/Dates cannot be empty or End Date cannot be less than Start Date";
		}else{
			list ($d, $m, $y) = split ("/", $startdate);
			$startdate=date ("Y-m-d", mktime (0,0,0,$m,$d,$y));
			list ($d, $m, $y) = split ("/", $enddate);
			$enddate=date ("Y-m-d", mktime (0,0,0,$m,$d,$y));

		    $sql="select d.employeeno, a.name, b.department, c.shiftgroup, sum(d.wrkhrs) wrkhrs, sum(d.calchrs) calchrs, sum(d.nighthours) nighthours, sum(d.overtimehours) overtimehours, sum(d.doublehours) doublehours
		    		from departments b, shiftgroups c, employees a, (select e.date, e.employeeno, e.timein, e.timeout, e.wrkhrs, e.calchrs, e.nighthours, e.remarks, e.overtimehours, e.doublehours from timetrack e  where e.status='A' union
						select f.date, f.employeeno, f.timein, f.timeout, f.calchrs wrkhrs, f.calchrs, f.nighthours,  f.reason remarks, f.overtimehours, f.doublehours from mtimetrack f)
					d
		    		where ";
		    if ($deptid!='ALL'){
		    	$sql=$sql." a.deptid='$deptid' and ";
		    }
		    $sql=$sql."	a.deptid=b.deptid and
						a.deptid in ($dept) and 
		    			a.employeeno=d.employeeno and
		    			a.shiftgroupid=c.shiftgroupid and
		    			d.date>='$startdate' and d.date<='$enddate' 
		    		group by b.department, c.shiftgroup, d.employeeno, a.name ";
			$starter=false;
			


		}


}
if ($starter==true){

//retrieve departments and populate selection
$selectdepartment =  "<select name='deptid'>";

if ($role=='REPORT'){
	 $sql="select * from departments where superid='$empno'";
}else{
	$sql="SELECT * FROM departments";
}
$query = $db_object->query($sql);
if (DB::isError($query)) {
	$selectdepartment="Error -<i>".$query ->getMessage()."</i>";
}
if ($query->numRows()==0){
	$selectdepartment = 'Not defined';

}else {
	$selectdepartment=$selectdepartment."<option value='ALL'";
	$selectdepartment=$selectdepartment.">All Departments</option>";
	while ($info = $query->fetchRow()){
		$selectdepartment = $selectdepartment."<option value='".$info['deptid']."'";
		$selectdepartment = $selectdepartment.">".$info['department']." </option>";
	}
}
$selectdepartment=$selectdepartment."</select>";

include('includes/header.php');

print <<<EOF

<div>
<h2>Time Tracker Report by Department</h2>
<div class="txtResult">
	$txtResult
</div>
<br/>
<table style="border: dotted 1px #d9d9d9;">
<form name='main' action="$phpself" method='POST' target='_blank'>
<tr>
<td class='rightcol'>Department:</td>

	<td class='leftcol' colspan="3">$selectdepartment</td>
</tr>
<tr>
	<td class='rightcol'>Start Date:</td>
	<td class='leftcol'><input type='text' name='startdate' value='$startdate' size='10' onclick="showCalendarControl(this)" label='Click to select date' $readonly></td>
	<td class='rightcol'>End Date:</td>
		<td class='leftcol'><input type='text' name='enddate' value='$enddate' size='10' onclick="showCalendarControl(this)" label='Click to select date' $readonly></td>

</tr>


<tr>
	<td colspan='4' class='rightcol'>
		<input type='submit' name='submit' value='Cancel'>&nbsp;
		<input type='submit' name='submit' value='Print'>
		</td>
</tr>
</form>
</table>



</div>
EOF;
}elseif ($starter==false){

print <<<EOF
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml" xml:lang="en" lang="en">
<head>
<title>TimeTrack - Biometric Time & Attendance system</title>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<meta name="author" content="Burhani Infosys Ltd" />
<meta name="keywords" content="" />
<meta name="description" content="" />
<link href="favicon.ico" rel="shortcut icon" type="image/x-icon" />


<link href="css/site/print.css" media="screen" rel="stylesheet" type="text/css" />
<link href="css/site/CalendarControl.css" rel="stylesheet" type="text/css" />

<script src="js/sorttable.js"></script>

</head>
<body>

<div>
<h2>Time Tracker Report by Department</h2>
</div>
<br/>

EOF;
	//echo $sql;
	$query = $db_object->query($sql);


	if (DB::isError($query)) {
		 echo "<table class='sortable' style='border: dotted 1px #d9d9d9;' width='95%'>";
		 echo "<thead>";
		 echo "<tr>";
		 echo "<td>";
		 echo "Error - <i>".$query ->getMessage()."</i><br>";
		 echo "</td>";
		 echo "</tr>";
		 echo "</thead>";
		 echo "</table>";
	}elseif ($query->numRows()==0){
		echo "<table class='sortable' style='border: dotted 1px #d9d9d9;' width='95%'>";
		echo "<thead>";
		echo "<tr>";
		echo "<td>";
		echo "There are no data in the system in the range provided";
		echo "</td>";
		echo "</tr>";
		echo "</thead>";
		echo "</table>";
	}else {
		$prevdept='';
		list ($y, $m, $d) = split ("-", $startdate);
		$startdate=date ("d/m/Y", mktime (0,0,0,$m,$d,$y));
		list ($y, $m, $d) = split ("-", $enddate);
		$enddate=date ("d/m/Y", mktime (0,0,0,$m,$d,$y));


		while ($info=$query->fetchRow()){


			$department=$info['department'];
			if ($prevdept!=$department){
				if($prevdept!=''){
					echo "</tbody>";
					echo "<tfoot>";
					echo "</tfoot>";
					echo "</table>";
				}
					echo "<table style='border: dotted 1px #d9d9d9;' width='95%'>";
					echo "<tr><td class='leftcol'><strong>Department: $department</strong> </td>";
					echo "<td class='rightcol'><strong>Start Date: $startdate - End Date: $enddate </strong> </td>";
					echo "</tr></table>";
					echo "<table class='sortable' style='border: dotted 1px #d9d9d9;' width='95%'>";
					echo "<thead>";
					echo "<tr>";
					echo "<td class='innerTDL' width='9%'>";
					echo "<u>Employee No</u>";
					echo "</td>";
					echo "<td class='innerTDL' width='24%'>";
					echo "<u>Name</u>";
					echo "</td>";
					echo "<td class='innerTDL' width='22%'>";
					echo "<u>Department</u>";
					echo "</td>";
					echo "<td class='innerTDL' width='22%'>";
					echo "<u>Shift Group</u>";
					echo "</td>";
					echo "<td class='innerTDL' width='7%'>";
					echo "<u>Calc. Hours</u>";
					echo "</td>";
					echo "<td class='innerTDL' width='7%'>";
					echo "<u>Work Hours</u>";
					echo "</td>";
					//echo "<td class='innerTDL' width='7%'>";
					//echo "<u>Night Hours (incl)</u>";
					//echo "</td>";
					echo "<td class='innerTDL' width='7%'>";
					echo "<u>Overtime Hours</u>";
					echo "</td>";					
					echo "<td class='innerTDL' width='7%'>";
					echo "<u>Double Hours</u>";
					echo "</td>";
					
					echo "</tr>";
					echo "</thead>";

					echo "<tbody>";
			}
					echo "<tr>";
					echo "<td class='innerTDL'>";
					echo $info['employeeno'];
					$employeeno=$info['employeeno'];
					echo "</td>";
					echo "<td class='innerTDL'>";
					echo $info['name'];
					echo "</td>";
					echo "<td class='innerTDL'>";
					echo $info['department'];
					echo "</td>";
					echo "<td class='innerTDL'>";
					echo $info['shiftgroup'];
					echo "</td>";
					echo "<td class='innerTDR'>";
					echo $info['wrkhrs'];
					echo "</td>";
					echo "<td class='innerTDR'>";
					echo $info['calchrs'];
					echo "</td>";
					//echo "<td class='innerTDR'>";
					//echo $info['nighthours'];
					//echo "</td>";
					echo "<td class='innerTDR'>";
					echo $info['overtimehours'];
					echo "</td>";
					echo "<td class='innerTDR'>";
					echo $info['doublehours'];
					echo "</td>";
					echo "</tr>";


			$prevdept=$department;

		}
		echo "</tbody>";
		echo "<tfoot>";
		echo "</tfoot>";
		echo "</table>";
	}


}
include('includes/footer.php');
?>

