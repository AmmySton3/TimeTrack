<?php




include('includes/db_connect.php');
include('function.inc');

$phpself=$_SERVER['PHP_SELF'];
$readonly='';
$startdate='';
$enddate='';
$employeeno='';
$mylogonly=false;

if (isset($_SESSION['empno'])){
	$name=$_SESSION['name'];
	$empno=$_SESSION['empno'];
	$role=$_SESSION['role'];
}else{
	echo "<div class='txtResult'>You are not logged in</div>";
	exit;
}

if ($role=='STAFF' or $role=='LOGS'){
	$mylogonly=true;
}
if ($role=='REPORT'){
	 $sql="select deptid from departments where superid='$empno'";
	 $query = $db_object->query($sql);
	 if (DB::isError($query)) {
		 $dept='0';
	 }elseif ($query->numRows()==0){
		$dept='0';
		
	}else {
		$start='';
		while ($info=$query->fetchRow()){
			$dept.=$start." ".$info['deptid'];
			$start=',';
		}
	} 
}else{
	 $sql="select deptid from departments";
	 $query = $db_object->query($sql);
	 if (DB::isError($query)) {
		 $dept='';
	 }elseif ($query->numRows()==0){
		$dept='';
		
	}else {
		$start='';
		while ($info=$query->fetchRow()){
			$dept.=$start." ".$info['deptid'];
			$start=',';
		}
	} 
}
if (!isset($_POST['submit']) or $_POST['submit']=='Cancel'){
	$txtResult='';

	$starter=true;
}
elseif (isset($_POST['submit']) and ($_POST['submit']=='Print')) {

		$employeeno=$_POST['employeeno'];
		$startdate=$_POST['startdate'];
		$enddate=$_POST['enddate'];

		if (($startdate=='' or $enddate=='') or  ($employeeno=='')){
			$starter=true;
			$txtResult="The Employee No/Dates cannot be empty or End Date cannot be less than Start Date";
		}else{
			list ($d, $m, $y) = split ("/", $startdate);
			$startdate=date ("Y-m-d", mktime (0,0,0,$m,$d,$y));
			list ($d, $m, $y) = split ("/", $enddate);
			$enddate=date ("Y-m-d", mktime (0,0,0,$m,$d,$y));

		    $sql="select d.employeeno, a.name, b.department, c.shiftgroup,d.date, d.timein, d.timeout, d.wrkhrs, d.calchrs, d.nighthours, d.remarks, d.overtimehours, d.doublehours 
		    		from employees a, departments b, shiftgroups c, (select e.date, e.employeeno, e.timein, e.timeout, e.wrkhrs, e.calchrs, e.nighthours, e.remarks, e.overtimehours, e.doublehours from timetrack e  where e.status='A' union
						select f.date, f.employeeno, f.timein, f.timeout, f.calchrs wrkhrs, f.calchrs, f.nighthours, f.reason, f.overtimehours, f.doublehours  remarks from mtimetrack f)
					d
		    		where  a.employeeno='$employeeno' and
		    				a.deptid=b.deptid and
							a.deptid in ($dept) and 
		    			a.employeeno=d.employeeno and
		    			a.shiftgroupid=c.shiftgroupid and
		    			d.date>='$startdate' and d.date<='$enddate'  order by d.date";
			$sql="select d.employeeno, a.name, b.department, c.shiftgroup,d.date, d.timein, d.timeout, d.wrkhrs, d.calchrs, d.nighthours, d.remarks, d.overtimehours, d.doublehours, d.status
		    		from employees a, departments b, shiftgroups c, (select e.date, e.employeeno, e.timein, e.timeout, e.wrkhrs, e.calchrs, e.nighthours, e.remarks, e.overtimehours, e.doublehours, e.status from timetrack e union
						select f.date, f.employeeno, f.timein, f.timeout, f.calchrs wrkhrs, f.calchrs, f.nighthours, f.reason remarks, f.overtimehours, f.doublehours, 'M' from mtimetrack f)
					d
		    		where  a.employeeno='$employeeno' and
		    				a.deptid=b.deptid and
							a.deptid in ($dept) and 
		    			a.employeeno=d.employeeno and
		    			a.shiftgroupid=c.shiftgroupid and
		    			d.date>='$startdate' and d.date<='$enddate'  order by d.date";
			$starter=false;


		}


}
if ($starter==true){


include('includes/header.php');

print <<<EOF

<div>
<h2>Time Tracker Report by Department</h2>
<div class="txtResult">
	$txtResult
</div>
<br/>
<table style="border: dotted 1px #d9d9d9;">
<form name='main' action="$phpself" method='POST' target='_blank'>
EOF;
if (!$mylogonly){
print <<<EOF
<tr>
<td class='rightcol'>Employee:</td>

<td class='leftcol' colspan="3"><input type='text' id='name' size='35'>
<input type='hidden' name='employeeno' value='' >
</td>
</tr>
EOF;
}else{
print <<<EOF
<input type='hidden' name='employeeno' value='$empno' >
EOF;
}
print <<<EOF
<tr>
	<td class='rightcol'>Start Date:</td>
	<td class='leftcol'><input type='text' name='startdate' value='$startdate' size='10' onclick="showCalendarControl(this)" label='Click to select date' $readonly></td>
	<td class='rightcol'>End Date:</td>
		<td class='leftcol'><input type='text' name='enddate' value='$enddate' size='10' onclick="showCalendarControl(this)" label='Click to select date' $readonly></td>

</tr>


<tr>
	<td colspan='4' class='rightcol'>
		<input type='submit' name='submit' value='Cancel'>&nbsp;
		<input type='submit' name='submit' value='Print'>
		</td>
</tr>
</form>
</table>



</div>
EOF;
}elseif ($starter==false){

print <<<EOF
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml" xml:lang="en" lang="en">
<head>
<title>TimeTrack - Biometric Time & Attendance system</title>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<meta name="author" content="Burhani Infosys Ltd" />
<meta name="keywords" content="" />
<meta name="description" content="" />
<link href="favicon.ico" rel="shortcut icon" type="image/x-icon" />


<link href="css/site/print.css" media="screen" rel="stylesheet" type="text/css" />
<link href="css/site/CalendarControl.css" rel="stylesheet" type="text/css" />

<script src="js/sorttable.js"></script>

</head>
<body>

<div>
<h2>Time Tracker Report by Employee</h2>
</div>
<br/>

EOF;
	//echo $sql;
	$query = $db_object->query($sql);


	if (DB::isError($query)) {
		 echo "<table class='sortable' style='border: dotted 1px #d9d9d9;' width='95%'>";
		 echo "<thead>";
		 echo "<tr>";
		 echo "<td>";
		 echo "Error - <i>".$query ->getMessage()."</i><br>";
		 echo "</td>";
		 echo "</tr>";
		 echo "</thead>";
		 echo "</table>";
	}elseif ($query->numRows()==0){
		echo "<table class='sortable' style='border: dotted 1px #d9d9d9;' width='95%'>";
		echo "<thead>";
		echo "<tr>";
		echo "<td>";
		echo "There are no data in the range provided or the employee is not in your department";
		echo "</td>";
		echo "</tr>";
		echo "</thead>";
		echo "</table>";
	}else {
		$prevdept='';
		list ($y, $m, $d) = split ("-", $startdate);
		$startdate=date ("d/m/Y", mktime (0,0,0,$m,$d,$y));
		list ($y, $m, $d) = split ("-", $enddate);
		$enddate=date ("d/m/Y", mktime (0,0,0,$m,$d,$y));

		$prevemp='';
		$totalwrkhrs=0;
		$totalcalchrs=0;
		$totalnighthrs=0;
		$totalovertimehrs=0;
		$totaldoublehrs=0;
		while ($info=$query->fetchRow()){


			$employeeno=$info['employeeno'];
			$name=$info['name'];
			$department=$info['department'];
			$shiftgroup=$info['shiftgroup'];
			if ($prevemp!=$employeeno){

				echo "<table style='border: dotted 1px #d9d9d9;' width='95%'>";
				echo "<tr><td class='leftcol'><strong>Employee: $name ($employeeno)</strong> </td>";
				echo "<td class='rightcol'><strong>Start Date: $startdate - End Date: $enddate </strong> </td>";
				echo "</tr>";
				echo "<tr><td class='leftcol'>Shift Group: $shiftgroup</td>";
				echo "<td class='rightcol'>Department: $department  </td>";
				echo "</tr></table>";
				echo "<table class='sortable' style='border: dotted 1px #d9d9d9;' width='95%'>";
				echo "<thead>";
				echo "<tr>";
				echo "<td class='innerTDL' width='20%'>";
				echo "<u>Date</u>";
				echo "</td>";
				echo "<td class='innerTDL' width='18%'>";
				echo "<u>Time In</u>";
				echo "</td>";
				echo "<td class='innerTDL' width='18%'>";
				echo "<u>Time Out</u>";
				echo "</td>";
				echo "<td class='innerTDL' width='8%'>";
				echo "<u>Calc. Hours</u>";
				echo "</td>";
				echo "<td class='innerTDL' width='8%'>";
				echo "<u>Work Hours</u>";
				echo "</td>";
				//echo "<td class='innerTDL' width='8%'>";
				//echo "<u>Night Hrs (incl)</u>";
				//echo "</td>";
				echo "<td class='innerTDL' width='8%'>";
				echo "<u>Overtime Hrs</u>";
				echo "</td>";
				echo "<td class='innerTDL' width='8%'>";
				echo "<u>Double Overtime</u>";
				echo "</td>";
				
				echo "<td class='innerTDL' width='20%'>";
				echo "<u>Remarks</u>";
				echo "</td>";
				echo "</tr>";
				echo "</thead>";
				echo "<tbody>";
			}
			
			if ($info['status']=='E'){
				$wrkhrs=0;
				$calchrs=0;
				$overtimehours=0;
				$doublehours=0;
				$color='red';
			}else{
				$wrkhrs=$info['wrkhrs'];
				$calchrs=$info['calchrs'];
				$overtimehours=$info['overtimehours'];
				$doublehours=$info['doublehours'];
				$color='black';
			}
			$totalwrkhrs=$totalwrkhrs+$wrkhrs;
			$totalnighthrs=$totalnighthrs+$nighthours;
			$totalcalchrs=$totalcalchrs+$calchrs;
			$totalovertimehrs+=$overtimehours;
			$totaldoublehrs+=$doublehours;
			
				echo "<tr style='color:$color;'>";
				echo "<td class='innerTDL'>";
				$date=$info['date'];
				list ($y, $m, $d) = split ("-", $date);
				$date=date ("l, d/m/Y", mktime (0,0,0,$m,$d,$y));
				echo $date;
				echo "</td>";
				echo "<td class='innerTDL'>";
				echo $info['timein'];
				echo "</td>";
				echo "<td class='innerTDL'>";
				echo $info['timeout'];
				echo "</td>";
				echo "<td class='innerTDR'>";
				echo $wrkhrs;
				echo "</td>";
				echo "<td class='innerTDR'>";
				echo $calchrs;
				echo "</td>";
				//echo "<td class='innerTDR'>";
				//echo $info['nighthours'];
				//echo "</td>";
				echo "<td class='innerTDR'>";
				echo $overtimehours;
				echo "</td>";
				echo "<td class='innerTDR'>";
				echo $doublehours;
				echo "</td>";
				echo "<td class='innerTDL'>";
				echo $info['remarks'];
				echo "</td>";
				echo "</tr>";
				$prevemp=$employeeno;
		}
			echo "<tr>";
			echo "<td class='innerTDL' width='20%'>";
			echo " ";
			echo "</td>";
			echo "<td class='innerTDL' width='18%'>";
			echo " ";
			echo "</td>";
			echo "<td class='innerTDR' width='18%'>";
			echo " <strong>Total</strong>";
			echo "</td>";
			echo "<td class='innerTDR' width='8%'>";
			echo "<strong>$totalwrkhrs</strong>";
			echo "</td>";
			echo "<td class='innerTDR' width='8%'>";
			echo "<strong>$totalcalchrs</strong>";
			echo "</td>";
			//echo "<td class='innerTDR' width='8%'>";
			//echo "<strong>$totalnighthrs</strong>";
			//echo "</td>";
			echo "<td class='innerTDR' width='8%'>";
			echo "<strong>$totalovertimehrs</strong>";
			echo "</td>";
			echo "<td class='innerTDR' width='8%'>";
			echo "<strong>$totaldoublehrs</strong>";
			echo "</td>";
			echo "<td class='innerTDL' width='20%'>";
			echo " ";
			echo "</td>";
			echo "</tr>";

		echo "</tbody>";
		echo "<tfoot>";
		echo "</tfoot>";
		echo "</table>";
	}


}
include('includes/footer.php');
?>

