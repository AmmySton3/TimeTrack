<?php
include('includes/header.php');

$phpself=$_SERVER['PHP_SELF'];
$readonly='';
$userrole='';

if (isset($_SESSION['empno'])){
	$name=$_SESSION['name'];
	$empno=$_SESSION['empno'];
	$role=$_SESSION['role'];
}else{
	echo "<div class='txtResult'>You are not logged in</div>";
	exit;
}

if ($role!='ADMIN'){
	echo "<div class='txtResult'>You are not authorized to use this menu</div>";
	exit;
}

$postbutton='Add';
$employeeno='';
$name='';
$deptid='';
$shiftgroupid='';
$calctype='';
$active='';
$canlogin='';
$role='';
$username='';
$password='';
$txtResult='';
$canloginflag='';
$activeflag='';
$readonly='';

if (isset($_GET['changeDepartment'])){
	$newdepartment=$_GET['changeDepartment'];
}else{
	$newdepartment='ALL';
}
$action='';
if (isset($_GET['action']) ){
	$action=$_GET['action'];
	if ($action=='edit'){
		$employeeno=$_GET['employeeno'];
		$postbutton='Edit';
		$sql="select * from employees where employeeno='$employeeno' LIMIT 1";
		$query = $db_object->query($sql);
		$txtResult="Please make the necesary changes";
		if (DB::isError($query)) {
			$txtResult="The Employee could not be retrieved due to error - <br><i> ". $query ->getMessage()."</i>";
			$postbutton='Add';
		}else{
			$info = $query->fetchRow();
			$postbutton='Save';
			$employeeno=$info['employeeno'];
			$name=$info['name'];
			$deptid=$info['deptid'];
			$shiftgroupid=$info['shiftgroupid'];
			$calctype=$info['calctype'];
			$active=$info['active'];
			$canlogin=$info['canlogin'];
			$username=$info['username'];
			$role=$info['role'];
			$readonly='readonly';
			if ($active=='A'){
				$activeflag='checked';
			}
			if ($canlogin=='Y'){
				$canloginflag='checked';
			}


		}
	}elseif ($_GET['action']=='reset'){
		$employeeno=$_GET['employeeno'];
		$postbutton='Reset';
		$sql="select * from employees where employeeno='$employeeno' LIMIT 1";
		$query = $db_object->query($sql);
		$txtResult="Please reset the password";
		if (DB::isError($query)) {
			$txtResult="The Employee could not be retrieved due to error - <br><i> ". $query ->getMessage()."</i>";
			$postbutton='Add';
		}else{
			$info = $query->fetchRow();
			$employeeno=$info['employeeno'];
			$name=$info['name'];
			$username=$info['username'];
			$readonly='readonly';


		}
	}

}

if (isset($_POST['submit']) and $_POST['submit']=='Cancel'){
			$postbutton='Add';
			$employeeno='';
			$name='';
			$deptid='';
			$shiftgroupid='';
			$calctype='';
			$active='';
			$canlogin='';
			$role='';
			$username='';
			$password='';
			$txtResult='';
			$readonly='';
}
elseif (isset($_POST['submit']) and ($_POST['submit']=='Add')) {
	if ($_POST['username']==''){
		$txtResult='The Username cannot be empty!';
	}else{
		$employeeno=$_POST['employeeno'];
		$name=$_POST['name'];
		$deptid=$_POST['deptid'];
		$shiftgroupid=$_POST['shiftgroupid'];
		$calctype=$_POST['calctype'];

		if (isset($_POST['active'])){
			$active=$_POST['active'];
		}else{
			$active='I';
		}

		if (isset($_POST['canlogin'])){
			$canlogin=$_POST['canlogin'];
		}else{
			$canlogin='N';
		}
		$username=$_POST['username'];
		$password=md5($_POST['password']);
		$role=$_POST['role'];

		$today=date('Y-m-d');
		$sql="INSERT into employees (
									employeeno,
									name,
									deptid,
									shiftgroupid,
									calctype,
									active,
									username,
									password,
									canlogin,
									role
									)
							values (
									'$employeeno',
									'$name',
									'$deptid',
									'$shiftgroupid',
									'$calctype',
									'$active',
									'$username',
									'$password',
									'$canlogin',
									'$role'
									)";

		$query = $db_object->query($sql);
		$txtResult="The Employee has been added successfully!<br> You can add another Employee";
		if (DB::isError($query)) {
			$txtResult="The employee could not be added due to error - <br><i> ". $query ->getMessage()."</i>";
			$postbutton='Add';
		}else{
			$postbutton='Add';
			$employeeno='';
			$name='';
			$deptid='';
			$shiftgroupid='';
			$calctype='';
			$active='';
			$canlogin='';
			$role='';
			$username='';
			$password='';
			$txtResult='';
			$readonly='';

		}
	}

}
elseif (isset($_POST['submit']) and ($_POST['submit']=='Save')) {
	if ($_POST['employeeno']==''){
		$txtResult='The Employee No cannot be empty!';
	}else{
		$employeeno=$_POST['employeeno'];
		$name=$_POST['name'];
		$deptid=$_POST['deptid'];
		$shiftgroupid=$_POST['shiftgroupid'];
		$calctype=$_POST['calctype'];
		if (isset($_POST['active'])){
			$active=$_POST['active'];
		}else{
			$active='I';
		}

		if (isset($_POST['canlogin'])){
			$canlogin=$_POST['canlogin'];
		}else{
			$canlogin='N';
		}
		$role=$_POST['role'];

		$sql="UPDATE employees set	name='$name',
								deptid='$deptid',
								shiftgroupid='$shiftgroupid',
								calctype='$calctype',
								active='$active',
								canlogin='$canlogin',
								role='$role'
							where employeeno='$employeeno'";

		$query = $db_object->query($sql);
		$txtResult="The changes has been saved successfully!<br> You can add another User";
		if (DB::isError($query)) {
			$txtResult="The changes could not be added due to error - <br><i> ". $query ->getMessage()."</i>";
			$postbutton='Add';
		}else{
			$postbutton='Add';
			$employeeno='';
			$name='';
			$deptid='';
			$shiftgroupid='';
			$calctype='';
			$active='';
			$canlogin='';
			$role='';
			$username='';
			$password='';
			$readonly='';

		}
	}

}elseif (isset($_POST['submit']) and ($_POST['submit']=='Reset')) {
	if ($_POST['username']==''){
		$txtResult='The Username cannot be empty!';
	}else{
		$employeeno=$_POST['employeeno'];
		$password=md5($_POST['password']);
		$sql="UPDATE employees set	password='$password'
						where employeeno='$employeeno'";

		$query = $db_object->query($sql);
		$txtResult="The changes has been saved successfully!<br> You can add another User";
		if (DB::isError($query)) {
			$txtResult="The changes could not be added due to error - <br><i> ". $query ->getMessage()."</i>";
			$postbutton='Add';
		}else{
			$postbutton='Add';
			$employeeno='';
			$username='';
			$password='';
			$readonly='';

		}
	}

}





//retrieve department and populate lists
 	$department =  "<select name='deptid' onChange='populateSelectLists(this.value)'>";
	$sql="SELECT * FROM departments";

	$query = $db_object->query($sql);
	if (DB::isError($query)) {
		$department="Error -<i>".$query ->getMessage()."</i>";
	}
	if ($query->numRows()==0){
		$department = 'Not defined';

	}else {
		while ($info = $query->fetchRow()){
			if ($action=='edit' and $deptid==$info['deptid']){
				$department = $department."<option value='".$info['deptid']."'"." selected>".$info['department']." </option>";
			}else{
				$department = $department."<option value='".$info['deptid']."'>".$info['department']." </option>";
			}
		}

	}

 $department= $department."</select>";

//retrieve shiftgroups and populate lists
	 $shiftgroup =  "<select name='shiftgroupid' onChange='populateSelectLists(this.value)'>";
	$sql="SELECT * FROM shiftgroups";

	$query = $db_object->query($sql);
	if (DB::isError($query)) {
		$shiftgroup="Error -<i>".$query ->getMessage()."</i>";
	}
	if ($query->numRows()==0){
		$shiftgroup = 'Not defined';

	}else {
		while ($info = $query->fetchRow()){
			if ($action=='edit' and $shiftgroupid==$info['shiftgroupid']){
				$shiftgroup = $shiftgroup."<option value='".$info['shiftgroupid']."'"." selected>".$info['shiftgroup']." </option>";
			}else{
				$shiftgroup = $shiftgroup."<option value='".$info['shiftgroupid']."'>".$info['shiftgroup']." </option>";
			}
		}

	}

 $shiftgroup= $shiftgroup."</select>";
 
 //retrieve calctype and populate lists
 	$calctypes =  "<select name='calctype'>";
	$calctypes.="<option value='1' ";
		if ($action=='edit' and $calctype==1){
			$calctypes.="selected";
		}
	$calctypes.=">Adjust Overtime and Absentism </option>";
	$calctypes.="<option value='2' ";
		if ($action=='edit' and $calctype==2){
			$calctypes.="selected";
		}
	$calctypes.=">Ignore Overtime, Compute Absentism </option>";
	$calctypes.="<option value='3' ";
		if ($action=='edit' and $calctype==3){
			$calctypes.="selected";
		}
	$calctypes.=">Compute Overtime, Ignore Absentism</option>";
	$calctypes.="<option value='4' ";
		if ($action=='edit' and $calctype==4){
			$calctypes.="selected";
		}
	$calctypes.=">Ignore Both Overtime and Absentism </option>";
	
	

 $department= $department."</select>";
 

//retrieve departments and populate selection
$selectdepartment =  "<select name='deptid' onChange=\"window.location.replace('$phpself?changeDepartment='+this.value)\">";

$sql="SELECT * FROM departments";

$query = $db_object->query($sql);
if (DB::isError($query)) {
	$selectdepartment="Error -<i>".$query ->getMessage()."</i>";
}
if ($query->numRows()==0){
	$selectdepartment = 'Not defined';

}else {
	$selectdepartment=$selectdepartment."<option value='ALL'";
	if ($newdepartment=='ALL'){
		$selectdepartment=$selectdepartment."selected";
	}
	$selectdepartment=$selectdepartment.">All Departments</option>";
	while ($info = $query->fetchRow()){
		$selectdepartment = $selectdepartment."<option value='".$info['deptid']."'";
		if ($newdepartment!='ALL' and $newdepartment==$info['deptid']){
			$selectdepartment=$selectdepartment."selected";
		}
		$selectdepartment = $selectdepartment.">".$info['department']." </option>";
	}
}
$selectdepartment=$selectdepartment."</select>";


//select roles
$admin='';
$logs='';
$staff='';
$report='';
if ($role=='ADMIN'){
	$admin='selected';
}elseif ($role=='LOGS'){
	$logs='selected';
}elseif ($role=='STAFF'){
	$staff='selected';
}elseif ($role=='REPORT'){
	$report='selected';
}elseif ($role=='DEPT'){
	$dept='selected';
}
$selectrole="<select name='role'>";
$selectrole=$selectrole."<option value='STAFF' $staff>Staff</option>";
$selectrole=$selectrole."<option value='REPORT' $report>Report Viewer</option>";
$selectrole=$selectrole."<option value='LOGS' $logs>Upload Logs</option>";
$selectrole=$selectrole."<option value='ADMIN' $admin>T&A Admin</option>";
$selectrole=$selectrole."</select>";

print <<<EOF
<script language="javascript">

function populateSelectLists(d){

}
function checkform(d) {
if ((d.submit.value='Add') || (d.submit.value='Save')){
	if(d.employeeno.value==''){
		alert("Please enter the Employee no");
		d.uid.focus();
		return false;
	}else if(d.name.value==''){
		alert("Please enter the Employee Name");
		d.name.focus();
		return false;
	}else if(d.deptid.value==''){
		alert("Please select the Department");
		d.deptid.focus();
		return false;
	}else if(d.shiftgroupid.value==''){
		alert("Please select the Shift Group");
		d.shiftgroupid.focus();
		return false;
	}else if(d.username.value==''){
		alert("Please enter username");
		d.username.focus();
		return false;
	}else if(d.password.value==''){
		alert("Please enter password");
		d.password.focus();
		return false;
	}
}

return true;
}
</script>


<table>
<tr>
	<td style='vertical-align:top; padding-right:2em;'>
<div>
EOF;
if ($action=='edit'){
print <<<EOF
<h2>Edit User</h2>
<div class="txtResult">
	$txtResult
</div>
<br/>
EOF;
}elseif ($action=='reset'){
print <<<EOF
<h2>Reset Password</h2>
<div class="txtResult">
	$txtResult
</div>
<br/>
EOF;
}else{
print <<<EOF
<h2>Add User</h2>
<div class="txtResult">
	$txtResult
</div>
<br/>
EOF;
}
print <<<EOF
<table style="border: dotted 1px #d9d9d9;">
<form name='main' action="$phpself" method='POST' onSubmit="return checkform(this)">

EOF;
if ($action!='reset'){
print <<<EOF
<tr>
	<td class='rightcol'>Employee No:</td>
	<td class='leftcol' colspan='3'><input type='text' name='employeeno' value='$employeeno' size='10' $readonly></td>
</tr>
<tr>
	<td class='rightcol'>Employee Name:</td>
	<td class='leftcol' colspan='3'><input type='text' name='name' value='$name' size='35'></td>
</tr>

<tr>
	<td class='rightcol' style="padding-top:0.5em;">Department:</td>
	<td class='leftcol' colspan='3' style="padding-top:0.5em;">
		$department</td>
</tr>
<tr>
	<td class='rightcol' style="padding-top:0.5em;">Calc. Type:</td>
	<td class='leftcol' colspan='3' style="padding-top:0.5em;">
		$calctypes</td>
</tr>
<tr>
	<td class='rightcol' style="padding-top:0.5em;">Shift Group:</td>
	<td class='leftcol' colspan='3' style="padding-top:0.5em;">
		$shiftgroup</td>
</tr>
<tr>
	<td class='rightcol'  style="padding-top:0.5em;">Active:</td>
	<td class='leftcol' colspan='3'  style="padding-top:0.5em;">
		<input type='checkbox' name='active' value='A' $activeflag></td>
</tr>

EOF;
}
if ($action=='reset'){
print <<<EOF

<tr>
	<td class='rightcol'>Employee No:</td>
	<td class='leftcol' colspan='3'>
	<input type='text' name='employeeno' value='$employeeno' size='10' readonly></td>
</tr>
<tr>
	<td class='rightcol'>Employee Name:</td>
	<td class='leftcol' colspan='3'><input type='text' name='name' value='$name' size='35' readonly></td>
</tr>
EOF;
}
if ($action=='' or $action=='reset'){
print <<<EOF

<tr>
	<td class='rightcol' style="padding-top:0.5em;">Username:</td>
	<td class='leftcol' colspan='3' style="padding-top:0.5em;">
		<input type='text' name='username' value='$username' size='25' $readonly ></td>
</tr>
<tr>
	<td class='rightcol'>Password:</td>
	<td class='leftcol' colspan='3'>
		<input type='password' name='password' value='$password' size='25' ></td>
</tr>
EOF;
}

if ($action!='reset'){
print <<<EOF
<tr>
	<td class='rightcol' style="padding-top:0.5em;">Role:</td>
	<td class='leftcol' colspan='3' style="padding-top:0.5em;">
		$selectrole
	</td>

</tr>
<tr>
	<td class='rightcol'  style="padding-top:0.5em;">Can Login:</td>
	<td class='leftcol' colspan='3'  style="padding-top:0.5em;">
		<input type='checkbox' name='canlogin' value='Y' $canloginflag></td>
</tr>
EOF;
}
print <<<EOF

<tr>
	<td colspan='4' class='rightcol'>
		<input type='submit' name='submit' value='Cancel'>&nbsp;
		<input type='submit' name='submit' value='$postbutton'>
	</td>
</tr>
</form>
</table>

</td>

<td style='vertical-align:top;'>
<div>
<h2>List of Employees</h2>
<div class="txtResult">
Select Department: $selectdepartment
</div>
<br/>
<table class="sortable" style="border: dotted 1px #d9d9d9;">

EOF;
	$sql="select a.employeeno, a.name, a.deptid, b.department, a.shiftgroupid, c.shiftgroup, a.active, a.canlogin, a.role
	from
			employees a, departments b, shiftgroups c where  a.deptid=b.deptid and a.shiftgroupid=c.shiftgroupid ";
	if ($newdepartment!='ALL'){
		$sql=$sql." and a.deptid='$newdepartment'";
	}
	$query = $db_object->query($sql);
	if (DB::isError($query)) {
		 echo "<thead>";
		 echo "<tr>";
		 echo "<td>";
		 echo "Error - <i>".$query ->getMessage()."</i><br>";
		 echo "</td>";
		 echo "</tr>";
		 echo "</thead>";
	}elseif ($query->numRows()==0){
		echo "<thead>";
		echo "<tr>";
		echo "<td>";
		echo "There are no Employees in the system";
		echo "</td>";
		echo "</tr>";
		echo "</thead>";
	}else {
		echo "<thead>";
		echo "<tr>";
		echo "<td class='innerTDL'>";
		echo "<u>Employee ID</u>";
		echo "</td>";
		echo "<td class='innerTDL'>";
		echo "<u>Name</u>";
		echo "</td>";
		echo "<td class='innerTDL'>";
		echo "<u>Department</u>";
		echo "</td>";
		echo "<td class='innerTDL'>";
		echo "<u>Shift Group</u>";
		echo "</td>";
		echo "<td class='innerTDL'>";
		echo "<u>Active</u>";
		echo "</td>";
		echo "<td class='innerTDL'>";
		echo "<u>Can Login</u>";
		echo "</td>";
		echo "<td class='innerTDL'>";
		echo "<u>Role</u>";
		echo "</td>";

		echo "<td class='innerTDL'>";
		echo "<u>Action</u>";
		echo "</td>";
		echo "</tr>";
		echo "</thead>";

		echo "<tbody>";

		while ($info = $query->fetchRow()){
			echo "<tr>";
			echo "<td class='innerTDL'>";
			echo $info['employeeno'];
			$employeeno=$info['employeeno'];
			echo "</td>";
			echo "<td class='innerTDL'>";
			echo $info['name'];
			echo "</td>";
			echo "<td class='innerTDL'>";
			echo $info['department'];
			echo "</td>";
			echo "<td class='innerTDL'>";
			echo $info['shiftgroup'];
			echo "</td>";
			echo "<td class='innerTDL'>";
			$active=$info['active'];
			switch ($active) {
				case 'A':
			        echo 'Active';
			        break;
				case 'I':
			        echo 'Inactive';
			        break;
			}
			echo "</td>";
			echo "<td class='innerTDL'>";
			$canlogin=$info['canlogin'];
			switch ($canlogin) {
				case 'Y':
			        echo 'Yes';
			        break;
				case 'N':
			        echo 'No';
			        break;
			}
			echo "</td>";
			echo "<td class='innerTDL'>";
			echo $info['role'];
			echo "</td>";

			echo "<td class='innerTDL'>";

			echo "<a href='$phpself?changeDepartment=$newdepartment&action=edit&employeeno=$employeeno'>Edit</a>&nbsp;|&nbsp;";
			echo "<a href='$phpself?changeDepartment=$newdepartment&action=reset&employeeno=$employeeno'>Reset</a>&nbsp;|&nbsp;";

			echo "</td>";
			echo "</tr>";


		}
		echo "</tbody>";
		echo "<tfoot>";
		echo "</tfoot>";

	}
	echo "</form>";
echo "</table>";

print <<<EOF


</td>
</tr>
</table>

EOF;
include('includes/footer.php');
?>

