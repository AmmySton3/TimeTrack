<?php
include('includes/header.php');

if (isset($_SESSION['empno'])){
	$name=$_SESSION['name'];
	$empno=$_SESSION['empno'];
	$role=$_SESSION['role'];
}else{
	echo "<div class='txtResult'>You are not logged in</div>";
	exit;
}

if ($role=='STAFF'){
	echo "<div class='txtResult'>You are not authorized to use this menu</div>";
	exit;
}

$phpself=$_SERVER['PHP_SELF'];
$readonly='';

if (isset($_POST['submit']) and $_POST['submit']=='Save') {
	$date=$_POST['date'];
	$employeeno=$_POST['employeeno'];
	$calchrs=$_POST['calchrs'];
	$nighthrs=$_POST['nighthours'];
	
	$txtResult='The Tracker has been updated successfully!';
	$sql="update timetrack set calchrs='$calchrs', nightstatus='C', nighthours='$nighthrs', status='A', remarks='Updated by $name' where date='$date' and employeeno='$employeeno'";
	$query = $db_object->query($sql);
	if (DB::isError($query)) {
		$txtResult="The Tracker could not be added due to error - <br><i> ". $query ->getMessage()."</i>";
	}
	
print <<<EOF

<div>
<h2>Update Tracker</h2>
<div class="txtResult">
	$txtResult
</div>
EOF;
	
}else{

//retrieve List of Values
$date=$_GET['date'];
$employeeno=$_GET['employeeno'];
$sql="select d.employeeno, a.name, b.department, c.shiftgroup,d.date, d.timein, d.timeout, d.wrkhrs, d.calchrs, d.nighthours, d.remarks
		    		from employees a, departments b, shiftgroups c, timetrack d
		    		where  a.employeeno='$employeeno' and
		    				a.deptid=b.deptid and
		    			a.employeeno=d.employeeno and
		    			a.shiftgroupid=c.shiftgroupid and
		    			d.date='$date' and d.status='E'";
$query = $db_object->query($sql);
if (DB::isError($query)) {
	$txtResult="The items could note be retrieved due error - <br><i>".$query ->getMessage()."</i>";
}
if ($query->numRows()==0){
	$txtResult= "No exception in the tracker";
}else {
	
	$info = $query->fetchRow();
	$empname=$info['name'];
	$department=$info['department'];
	$shiftgroup=$info['shiftgroup'];
	$timein=$info['timein'];
	list ($di, $ti) = split (" ", $timein);
	$timeout=$info['timeout'];
	list ($do, $to) = split (" ", $timeout);
				
}

print <<<EOF

<div>
<h2>Update Tracker</h2>
<div class="txtResult">
	$txtResult
</div>
<table style="border: dotted 1px #d9d9d9; width:50%;text-align:left;">
<form name='main' action="$phpself" method='POST'>
<tr>
	<td class='rightcol' width='150px'>Employee: </td>
	<td class='leftcol'>
	<input type='text' name='employee' value='$empname' size='50' readonly>
	<input type='hidden' name='employeeno' value='$employeeno' readonly>
	</td>
</tr>
<tr>
	<td class='rightcol'>Department: </td>
	<td class='leftcol'>
	<input type='text' name='department' value='$department' size='50' readonly>
	</td>
</tr>
<tr>
	<td class='rightcol'>Shift group: </td>
	<td class='leftcol'>
	<input type='text' name='shiftgroup' value='$shiftgroup'  size='50' readonly>
	</td>
</tr>
<tr>
	<td class='rightcol'>Date: </td>
	<td class='leftcol'>
	<input type='text' name='date' value='$date' size='10' readonly>
	</td>
</tr>
<tr>
	<td class='rightcol'>Time In:</td>
	<td class='leftcol'><input type='text' name='timein' value='$ti' size='10' readonly></td>
</tr>
<tr>
	<td class='rightcol'>Time Out:</td>
	<td class='leftcol'><input type='text' name='timeout' value='$to' size='10' readonly></td>
</tr>
<tr><td colspan='2'><br/></td>
</tr>
<tr>
	<td class='rightcol'>Work Hours:</td>
	<td class='leftcol'><input type='text' name='calchrs' value='$calchrs' size='5'></td>
</tr>
<tr>
	<td class='rightcol'>Night Hours (incl):</td>
	<td class='leftcol'><input type='text' name='nighthours' value='$nighthours' size='5'></td>
</tr>
<tr>
	<td colspan='2' class='rightcol'>
		<input type='submit' name='submit' value="Save">
		</td>
</tr>
</form>
</table>


</div>
EOF;
}
include('includes/footer.php');
?>

