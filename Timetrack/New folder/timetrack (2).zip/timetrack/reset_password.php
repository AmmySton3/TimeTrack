<?php
include('includes/header.php');

$phpself=$_SERVER['PHP_SELF'];
$readonly='';
if (isset($_SESSION['empno'])){
	$name=$_SESSION['name'];
	$empno=$_SESSION['empno'];
	$role=$_SESSION['role'];
}else{
	echo "<div class='txtResult'>You are not logged in</div>";
	exit;
}


$starter=true;
$txtResult="Please make the necesary changes";

if (isset($_POST['submit']) and ($_POST['submit']=='Save')) {
	if ($_POST['newpassword']!=$_POST['confirmpassword']){
		$txtResult='The New Passwords does not match!';
	}elseif ($_POST['oldpassword']=='' or $_POST['newpassword']=='' or $_POST['confirmpassword']==''){
		$txtResult='The Passwords cannot be empty!';
	}else{
		$oldpassword=$_POST['oldpassword'];
		$newpassword=$_POST['newpassword'];
		$confirmpassword=$_POST['confirmpassword'];
		$oldpassword=md5($oldpassword);
		$newpassword=md5($newpassword);

		$sql="select * from employees where employeeno='$empno' and password='$oldpassword'";
		$query = $db_object->query($sql);
		if (DB::isError($query)) {
			$txtResult="The changes could not be added due to error - <br><i> ". $query ->getMessage()."</i>";

		}
		if ($query->numRows()==0){
			$txtResult="You did not supplied the correct Old Password!<br>";

		}else{
			$sql="UPDATE employees set	password='$newpassword'
							where employeeno='$empno'";

			$query = $db_object->query($sql);
			$txtResult="The changes has been saved successfully!<br>";
			if (DB::isError($query)) {
				$txtResult="The changes could not be added due to error - <br><i> ". $query ->getMessage()."</i>";

			}else{
				$oldpassword='';
				$newpassword='';
				$confirmpassword='';
				$readonly='readonly';

			}
		}
	}


	$oldpassword='';
	$newpassword='';
	$confirmpassword='';
	$readonly='readonly';



}

$sql="select username from employees where employeeno='$empno'";
$query = $db_object->query($sql);
if (DB::isError($query)) {
	$txtResult="The query could not be completed due to error - <br><i> ". $query ->getMessage()."</i>";
}else{
	$info=$query->fetchRow();
	$uname=$info['username'];
}


print <<<EOF
<h2>Reset Password</h2>
<div class="txtResult">
	$txtResult
</div><table style="border: dotted 1px #d9d9d9;">
<form name='main' action="$phpself" method='POST' >
<tr>
	<td class='rightcol' style="padding-top:0.5em;">Username:</td>
	<td class='leftcol' colspan='3' style="padding-top:0.5em;">
		<input type='text' name='uname' value='$uname' size='25' readonly ></td>
</tr>
<tr>
	<td class='rightcol'>Old Password:</td>
	<td class='leftcol' colspan='3'>
		<input type='password' name='oldpassword'  size='25' ></td>
</tr>
<tr>
	<td class='rightcol'>New Password:</td>
	<td class='leftcol' colspan='3'>
		<input type='password' name='newpassword'  size='25' ></td>
</tr>
<tr>
	<td class='rightcol'>Confirm Password:</td>
	<td class='leftcol' colspan='3'>
		<input type='password' name='confirmpassword'  size='25' ></td>
</tr>
<tr>
	<td colspan='4' class='rightcol'>
		<input type='submit' name='submit' value='Cancel'>&nbsp;
		<input type='submit' name='submit' value='Save'>
		</td>
</tr>
</form>
</table>
</table>


EOF;

include('includes/footer.php');
?>