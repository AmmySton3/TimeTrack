<?php
include('includes/db_connect.php');
include('function.inc');

$phpself=$_SERVER['PHP_SELF'];
$readonly='';
$startdate='';
$enddate='';
$employeeno='';
$mylogonly=false;

if (isset($_SESSION['empno'])){
	$name=$_SESSION['name'];
	$empno=$_SESSION['empno'];
	$role=$_SESSION['role'];
}else{
	echo "<div class='txtResult'>You are not logged in</div>";
	exit;
}

if ($role=='STAFF' or $role=='LOGS'){
	$mylogonly=true;
}
$selectdepartment =  "<select name='deptid'>";

if ($role=='REPORT'){
	 $sql="select * from departments where superid='$empno'";
}else{
	$sql="SELECT * FROM departments";
}
$query = $db_object->query($sql);
if (DB::isError($query)) {
	$selectdepartment="Error -<i>".$query ->getMessage()."</i>";
}
if ($query->numRows()==0){
	$selectdepartment = 'Not defined';

}else {
	$selectdepartment=$selectdepartment."<option value='ALL'";
	$selectdepartment=$selectdepartment.">All Departments</option>";
	while ($info = $query->fetchRow()){
		$selectdepartment = $selectdepartment."<option value='".$info['deptid']."'";
		$selectdepartment = $selectdepartment.">".$info['department']." </option>";
	}
}
$selectdepartment=$selectdepartment."</select>";
if ($role=='REPORT'){
	 $sql="select deptid from departments where superid='$empno'";
	 $query = $db_object->query($sql);
	 if (DB::isError($query)) {
		 $dept='0';
	 }elseif ($query->numRows()==0){
		$dept='0';
		
	}else {
		$start='';
		while ($info=$query->fetchRow()){
			$dept.=$start." ".$info['deptid'];
			$start=',';
		}
	} 
}else{
	 $sql="select deptid from departments";
	 $query = $db_object->query($sql);
	 if (DB::isError($query)) {
		 $dept='';
	 }elseif ($query->numRows()==0){
		$dept='';
		
	}else {
		$start='';
		while ($info=$query->fetchRow()){
			$dept.=$start." ".$info['deptid'];
			$start=',';
		}
	} 
}
if (!isset($_POST['submit']) or $_POST['submit']=='Cancel'){
	$txtResult='';

	$starter=true;
}
elseif (isset($_POST['submit']) and ($_POST['submit']=='Print')) {

		$deptid=$_POST['deptid'];
		$startdate=$_POST['startdate'];
		
		if ($startdate==''){
			$starter=true;
			$txtResult="The Date cannot be empty";
		}else{
			list ($d, $m, $y) = split ("/", $startdate);
			$startdate=date ("Y-m-d", mktime (0,0,0,$m,$d,$y));
			
		    $sql="select d.employeeno, a.name, b.department, c.shiftgroup,d.date, d.timein, d.timeout, d.wrkhrs, d.calchrs, d.nighthours, d.remarks
		    		from employees a, departments b, shiftgroups c, (select e.date, e.employeeno, e.timein, e.timeout, e.wrkhrs, e.calchrs, e.nighthours, e.remarks from timetrack e  where e.status='A' union
						select f.date, f.employeeno, f.timein, f.timeout, f.calchrs wrkhrs, f.calchrs, f.nighthours, f.reason remarks from mtimetrack f) d
		    		where ";
		    if ($deptid!='ALL'){
		    	$sql=$sql." a.deptid='$deptid' and ";
		    }
		    $sql=$sql."	a.deptid=b.deptid and
						a.deptid in ($dept) and a.employeeno=d.employeeno and
		    			a.shiftgroupid=c.shiftgroupid and
		    			d.date='$startdate' order by b.department, d.timein, a.name";
			$starter=false;


		}


}
if ($starter==true){


include('includes/header.php');

print <<<EOF

<div>
<h2>Daily Time Tracker Report by Employee</h2>
<div class="txtResult">
	$txtResult
</div>
<br/>
<table style="border: dotted 1px #d9d9d9;">
<form name='main' action="$phpself" method='POST' target='_blank'>

<td class='rightcol'>Department:</td>

	<td class='leftcol' >$selectdepartment</td>
</tr><tr>
	<td class='rightcol'>Date:</td>
	<td class='leftcol' ><input type='text' name='startdate' value='$startdate' size='10' onclick="showCalendarControl(this)" label='Click to select date' $readonly></td>
	
</tr>


<tr>
	<td colspan='2' class='rightcol'>
		<input type='submit' name='submit' value='Cancel'>&nbsp;
		<input type='submit' name='submit' value='Print'>
		</td>
</tr>
</form>
</table>



</div>
EOF;
}elseif ($starter==false){
				$date=$startdate;
				list ($y, $m, $d) = split ("-", $date);
				$date=date ("l, d/m/Y", mktime (0,0,0,$m,$d,$y));
				echo $date;

print <<<EOF
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml" xml:lang="en" lang="en">
<head>
<title>TimeTrack - Biometric Time & Attendance system</title>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<meta name="author" content="Burhani Infosys Ltd" />
<meta name="keywords" content="" />
<meta name="description" content="" />
<link href="favicon.ico" rel="shortcut icon" type="image/x-icon" />


<link href="css/site/print.css" media="screen" rel="stylesheet" type="text/css" />
<link href="css/site/CalendarControl.css" rel="stylesheet" type="text/css" />

<script src="js/sorttable.js"></script>

</head>
<body>

<div>
<h2>Daily Attendance Report by Department</h2>
</div>
<br/>

EOF;
	//echo $sql;
	$query = $db_object->query($sql);


	if (DB::isError($query)) {
		 echo "<table class='sortable' style='border: dotted 1px #d9d9d9;' width='95%'>";
		 echo "<thead>";
		 echo "<tr>";
		 echo "<td>";
		 echo "Error - <i>".$query ->getMessage()."</i> with $sql<br>";
		 echo "</td>";
		 echo "</tr>";
		 echo "</thead>";
		 echo "</table>";
	}elseif ($query->numRows()==0){
		echo "<table class='sortable' style='border: dotted 1px #d9d9d9;' width='95%'>";
		echo "<thead>";
		echo "<tr>";
		echo "<td>";
		echo "There are no data in the range provided or the employee is not in your department";
		echo "</td>";
		echo "</tr>";
		echo "</thead>";
		echo "</table>";
	}else {
		$prevdept='';
		list ($y, $m, $d) = split ("-", $startdate);
		$startdate=date ("d/m/Y", mktime (0,0,0,$m,$d,$y));
		list ($y, $m, $d) = split ("-", $enddate);
		$enddate=date ("d/m/Y", mktime (0,0,0,$m,$d,$y));

		$prevemp='';
		$totalwrkhrs=0;
		$totalcalchrs=0;
		$totalnighthrs=0;

		

				
				echo "<table class='sortable' style='border: dotted 1px #d9d9d9;' width='95%'>";
				echo "<thead>";
				echo "<tr>";
				echo "<td class='innerTDL' width='10%'>";
				echo "<u>Employee No</u>";
				echo "</td>";
				echo "<td class='innerTDL' width='20%'>";
				echo "<u>Employee Name</u>";
				echo "</td>";
				echo "<td class='innerTDL' width='10%'>";
				echo "<u>Shift Group</u>";
				echo "</td>";
				echo "<td class='innerTDL' width='10%'>";
				echo "<u>Department</u>";
				echo "</td>";
				echo "<td class='innerTDL' width='18%'>";
				echo "<u>Time In</u>";
				echo "</td>";
				echo "<td class='innerTDL' width='18%'>";
				echo "<u>Time Out</u>";
				echo "</td>";
				echo "<td class='innerTDL' width='8%'>";
				echo "<u>Calc. Hours</u>";
				echo "</td>";
				echo "<td class='innerTDL' width='8%'>";
				echo "<u>Work Hours</u>";
				echo "</td>";
				echo "<td class='innerTDL' width='8%'>";
				echo "<u>Night Hrs (incl)</u>";
				echo "</td>";
				echo "<td class='innerTDL' width='20%'>";
				echo "<u>Remarks</u>";
				echo "</td>";
				echo "</tr>";
				echo "</thead>";
				echo "<tbody>";
		while ($info=$query->fetchRow()){


			$employeeno=$info['employeeno'];
			$name=$info['name'];
			$department=$info['department'];
			$shiftgroup=$info['shiftgroup'];
			$totalwrkhrs=$totalwrkhrs+$info['wrkhrs'];
			$totalnighthrs=$totalnighthrs+$info['nighthours'];
			$totalcalchrs=$totalcalchrs+$info['calchrs'];

				echo "<tr>";
				echo "<td class='innerTDL'>";
				echo $employeeno;
				echo "</td>";
				echo "<td class='innerTDL'>";
				echo $name;
				echo "</td>";
				echo "<td class='innerTDL'>";
				echo $shiftgroup;
				echo "</td>";
				echo "<td class='innerTDL'>";
				echo $department;
				echo "</td>";
				echo "<td class='innerTDL'>";
				echo $info['timein'];
				echo "</td>";
				echo "<td class='innerTDL'>";
				echo $info['timeout'];
				echo "</td>";
				echo "<td class='innerTDR'>";
				echo $info['wrkhrs'];
				echo "</td>";
				echo "<td class='innerTDR'>";
				echo $info['calchrs'];
				echo "</td>";
				echo "<td class='innerTDR'>";
				echo $info['nighthours'];
				echo "</td>";
				echo "<td class='innerTDL'>";
				echo $info['remarks'];
				echo "</td>";
				echo "</tr>";
				$prevemp=$employeeno;
		}
			echo "<tr>";
echo "<td class='innerTDL' width='10%'>";
			echo " ";
			echo "</td>";			echo "<td class='innerTDL' width='20%'>";
			echo " ";
			echo "</td>";
echo "<td class='innerTDL' width='10%'>";
			echo " ";
			echo "</td>";
echo "<td class='innerTDL' width='10%'>";
			echo " ";			echo "<td class='innerTDL' width='18%'>";
			echo " ";
			echo "</td>";
			echo "<td class='innerTDR' width='18%'>";
			echo " <strong>Total</strong>";
			echo "</td>";
			echo "<td class='innerTDR' width='8%'>";
			echo "<strong>$totalwrkhrs</strong>";
			echo "</td>";
			echo "<td class='innerTDR' width='8%'>";
			echo "<strong>$totalcalchrs</strong>";
			echo "</td>";
			echo "<td class='innerTDR' width='8%'>";
			echo "<strong>$totalnighthrs</strong>";
			echo "</td>";
			echo "<td class='innerTDL' width='20%'>";
			echo " ";
			echo "</td>";
			echo "</tr>";

		echo "</tbody>";
		echo "<tfoot>";
		echo "</tfoot>";
		echo "</table>";
	}


}
include('includes/footer.php');
?>

