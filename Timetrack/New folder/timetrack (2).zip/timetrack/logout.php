<?php
// kill session variables
require_once('includes/db_connect.php');
$_SESSION = array(); // reset session array
session_destroy();   // destroy session.
header("Location: index.php");
exit;
?>