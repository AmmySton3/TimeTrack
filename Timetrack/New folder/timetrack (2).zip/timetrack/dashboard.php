<?php
require_once('includes/db_connect.php');


$name=$_SESSION['name'];
$empno=$_SESSION['empno'];
$role=$_SESSION['role'];
$today=date('Y-m-d');

if ($_SESSION['last_login']=='0000-00-00'){
	$lastlogin="This is your first time to login to the system; <a href='reset_password.php'>click here to reset your password</a>";
}else{
	$lastlogin="You last logged in on ".formatDate($_SESSION['last_login']);
}

print <<<EOF

<div style="align:centre; vertical-align:middle;">
<h2>Welcome, $name</h2>
<div class="txtResult">
	$lastlogin
</div>


<div>
	Please use any of the menu above to continue with navigation
</div>
</div>

EOF;




?>