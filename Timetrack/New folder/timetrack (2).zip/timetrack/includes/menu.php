<?php
require_once($_SERVER["DOCUMENT_ROOT"].'/includes/db_connect.php');



function showRightMenu($privilege){
global $query;
$gifspath="http://wiomsa.net/gifs";

if ($privilege=="Public"){
$backstyle="background: #f2f6f5;";
}elseif ($privilege=="Secretariat Administrator"){
$backstyle="background: #f9dfcc;";
}elseif ($privilege=="Country Cordinator"){
$backstyle="background: #d9f5c5;";
}elseif ($privilege=="Member"){
$backstyle="background: #eef4f4;";
}


$cordinator="http://wiomsa.net/cordinator";
$secretariat="http://wiomsa.net/secretariat";
$member="http://wiomsa.net/member";
$public="http://wiomsa.net";

$totalyears=count($query);

print <<<EOF
<TD vAlign=top align=left width=200>
  					   <TABLE cellSpacing=0 cellPadding=0 width=200 border=0 style="$backstyle">
 						<TBODY>
						   <TR>
                               <TD width=9><IMG height=9 src="$gifspath/main_l_t.gif" width=9></TD>
                               <TD width=182 background="$gifspath/main_bg_t.gif"><IMG height=1 src="$gifspath/1pix.gif" width=1></TD>
                               <TD width=9><IMG height=9 src="$gifspath/main_r_t.gif" width=9></TD>
                           </TR>
                        </TBODY>
                       </TABLE>
                       <TABLE cellSpacing=0 cellPadding=0 width=200 border=0 style="$backstyle">
                         <TBODY>
							<TR>
							<TD width=2 bgColor=#e6e6e6><IMG height=1 src="$gifspath/1pix.gif" width=1></TD>
							<TD align=middle width=196>
							<TABLE cellSpacing=0 cellPadding=0 width=186 border=0 style="$backstyle">
								<TBODY>
									<TR>
										<TD>


EOF;
if ($privilege=="Public"){
echo "<strong><center>Membership Application Area</center></strong>";
}elseif ($privilege=="Secretariat Administrator"){
echo "<strong>Secretariat Area</strong>";
}elseif ($privilege=="Country Cordinator"){
echo "<strong>Country Cordinator Area</strong>";
}elseif ($privilege=="Member"){
echo "<strong>Members Only Area</strong>";
}


if ($privilege=="Secretariat Administrator"){
print <<<EOF


									<div class="navigationFirstLevelContainer">
									<img align=absMiddle border=0 height=11 hspace=2 id=imgord name=imgord src="/gifs/nosubs.gif" width=11>
									<a class="subNavigate" href="$secretariat/index.html" title="Home">Home</a></div>
<!--
									<div class="navigationFirstLevelContainer">
									<img align=absMiddle border=0 height=11 hspace=2 id=imgord name=imgord src="/gifs/nosubs.gif" width=11>
									<a class="subNavigate" href="$secretariat/letterfromwiomsa.html" title="Letter from Dr. Muthiga">Letter from Dr. Muthiga</a></div>
-->
									<div class="navigationFirstLevelContainer">
									<img align=absMiddle border=0 height=11 hspace=2 id=imgord name=imgord src="/gifs/pos.gif" width=11>
									<a class="subNavigate"  title="WIOMSA Members">
									Membership Management</a> <BR>

									<span >
										<img border=0 height=1 src="/gifs/spacer.gif" width=20>
											<a class="subNavigate" href="$secretariat/process_subscription.html">
									     		Membership Requests</a>
									     <BR>
									     <img border=0 height=1 src="/gifs/spacer.gif" width=20>
										 											<a class="subNavigate" href="$secretariat/add_member.html">
										 									     		Add New Member</a>
									     <BR>

									     <img border=0 height=1 src="/gifs/spacer.gif" width=20>
										 											<a class="subNavigate" href="$secretariat/add_corporate.html">
										 									     		Add Corporate Member</a>
										<br>
									     <img border=0 height=1 src="/gifs/spacer.gif" width=20>
										 											<a class="subNavigate" href="$secretariat/search_members.html">
										 										 		Search Members</a>
									     <BR>
										<img border=0 height=1 src="/gifs/spacer.gif" width=20>
										<a class="subNavigate" href="$secretariat/receive_fees.html">
											 		Receive Fees</a>


                						</span>

									</div>
									<div class="navigationFirstLevelContainer">
									<img align=absMiddle border=0 height=11 hspace=2 id=imgord name=imgord src="/gifs/pos.gif" width=11>
									<a class="subNavigate"  title="WIOMSA Members">
									Members Communication</a> <BR>

									<span>
									<img border=0 height=1 src="/gifs/spacer.gif" width=20>
										 											<a class="subNavigate" href="$secretariat/search_members.html" title="Search for WIOMSA Members">
										 										 		Search Members</a>
									     <BR>


									<img border=0 height=1 src="/gifs/spacer.gif" width=20>
											<a class="subNavigate" href="$secretariat/email_members.html" title="Email to Members">
													Email Members</a>
									<BR>
									<img border=0 height=1 src="/gifs/spacer.gif" width=20>
											<a class="subNavigate" href="$secretariat/email_groups.html" title="Email Groups">
													Email Groups</a>
									<BR>
									 </span>


									</div>
									<div class="navigationFirstLevelContainer">
									<img align=absMiddle border=0 height=11 hspace=2 id=imgord name=imgord src="/gifs/pos.gif" width=11>
									<a class="subNavigate" title="Country Cordinator Management">
									Country Cordinators</a> <BR>

									<span >
										<img border=0 height=1 src="/gifs/spacer.gif" width=20>
											<a class="subNavigate" href="$secretariat/receive_from_cc.html">
											 		Received from CC</a>
											<BR>
										<img border=0 height=1 src="/gifs/spacer.gif" width=20>
											<a class="subNavigate" href="$secretariat/show_transactions.html">
													Transactions by CC</a>
											<BR>

                						</span>

									</div>

									<div class="navigationFirstLevelContainer">
									<img align=absMiddle border=0 height=11 hspace=2 id=imgord name=imgord src="/gifs/pos.gif" width=11>
									<a class="subNavigate"  title="Administration">
									Administration</a> <BR>

									<span >
										<img border=0 height=1 src="/gifs/spacer.gif" width=20>
											<a class="subNavigate" href="$secretariat/set_grace_period.html">
									     		New Member Grace Period</a>
									     <BR>
									     <img border=0 height=1 src="/gifs/spacer.gif" width=20>
										 	<a class="subNavigate" href="$secretariat/set_membership_fees.html">
										 			Membership Fees</a>
									     <BR>
										<img border=0 height=1 src="/gifs/spacer.gif" width=20>
										 	<a class="subNavigate" href="$secretariat/add_staff.html">
										 			Add WIOMSA Staff</a>
									     <BR>
										<img border=0 height=1 src="/gifs/spacer.gif" width=20>
										 	<a class="subNavigate" href="$secretariat/view_staff.html">
										 			View Staff Profiles</a>
									     <BR>
										<img border=0 height=1 src="/gifs/spacer.gif" width=20>
										 	<a class="subNavigate" href="$secretariat/view_staff.html">
										 			Edit Staff Profiles</a>
									     <BR>
										<img border=0 height=1 src="/gifs/spacer.gif" width=20>
										 	<a class="subNavigate" href="$secretariat/add_cordinator.html">
										 			Add Cordinator</a>
									     <BR>
										<img border=0 height=1 src="/gifs/spacer.gif" width=20>
										 	<a class="subNavigate" href="$secretariat/view_cordinator.html">
										 			View Cordinator Profiles</a>
									     <BR>
										<img border=0 height=1 src="/gifs/spacer.gif" width=20>
										 	<a class="subNavigate" href="$secretariat/view_cordinator.html">
										 			Edit Cordinator Profiles</a>
									     <BR>
									     <!--
									     <img border=0 height=1 src="/gifs/spacer.gif" width=20>
										 	<a class="subNavigate" href="$secretariat/set_currency.html">
										 			Setup Currency</a>
									     <BR>
										-->
                						</span>

									</div>

									<div class="navigationFirstLevelContainer">
									<img align=absMiddle border=0 height=11 hspace=2 id=imgord name=imgord src="/gifs/pos.gif" width=11>
									<a class="subNavigate"  title="Report Generation">
									Report Generation</a> <BR>

									<span >
										<img border=0 height=1 src="/gifs/spacer.gif" width=20>
											<a class="subNavigate" href="$secretariat/show_fees_status.html">
									     		Membership Fee Paid<br>
									     		<img border=0 height=1 src="/gifs/spacer.gif" width=22>
									     		Status
									     		</a>
									     <BR>
									     <img border=0 height=1 src="/gifs/spacer.gif" width=20>
										 	<a class="subNavigate" href="$secretariat/show_usage.html">Membership Usage<br>
										 			<img border=0 height=1 src="/gifs/spacer.gif" width=25>Statistics</a>
									     <BR>
										<img border=0 height=1 src="/gifs/spacer.gif" width=20>
										 	<a class="subNavigate" href="$secretariat/show_pub_added.html">Publications Added<br>
										 			<img border=0 height=1 src="/gifs/spacer.gif" width=25>by Period</a>
									     <BR>
                						</span>

									</div>
									<div class="navigationFirstLevelContainer">
									<img align=absMiddle border=0 height=11 hspace=2 id=imgord name=imgord src="/gifs/pos.gif" width=11>
									<a class="subNavigate" title="Add Publications">
									Publications Management</a> <BR>

									<span >
									<img border=0 height=1 src="/gifs/spacer.gif" width=20>
										 <a class="subNavigate" href="$secretariat/approve_publications.html">
										 	Approve Publications</a>
									 <BR>
									<img border=0 height=1 src="/gifs/spacer.gif" width=20>
										 <a class="subNavigate" href="$secretariat/add_publications.html">
										 	Add Publications</a>
									 <BR>
									<span >
									<img border=0 height=1 src="/gifs/spacer.gif" width=30>
										 <a class="subNavigate"  title="Peer Reviewed Articles">Peer Reviewed Articles</a>
									 <BR>
									<img border=0 height=1 src="/gifs/spacer.gif" width=30>
										 <a class="subNavigate"  title="Thesis">Thesis</a>
									 <BR>
									<img border=0 height=1 src="/gifs/spacer.gif" width=30>
										 <a class="subNavigate"  title="Abstracts">Abstracts</a>
									 <BR>
									 <!--
									<img border=0 height=1 src="/gifs/spacer.gif" width=30>
										 <a class="subNavigate"  title="Curriculum Vitae">Curriculum Vitae</a>
									 <BR>
									-->
									<img border=0 height=1 src="/gifs/spacer.gif" width=20>
											<a class="subNavigate" href="$secretariat/search_peer_reviews.html">
													Search  for Peer Articles</a>
									<BR>
									<img border=0 height=1 src="/gifs/spacer.gif" width=20>
											<a class="subNavigate" href="$secretariat/search_thesis.html">
													Search for Thesis</a>
									<BR>
									<img border=0 height=1 src="/gifs/spacer.gif" width=20>
											<a class="subNavigate" href="$secretariat/search_abstracts.html">
													Search for Abstracts</a>
									<BR>

									 </span>


									</div>
									<div class="navigationFirstLevelContainer">
									<img align=absMiddle border=0 height=11 hspace=2 id=imgord name=imgord src="/gifs/pos.gif" width=11>
									<a class="subNavigate" title="WIOMSA Members">
									WIOMSA Journals</a> <BR>

									<span >
									<img border=0 height=1 src="/gifs/spacer.gif" width=20>
										 <a class="subNavigate" href="$secretariat/add_journal.html">
										 	Add Journal</a>
									 <BR>

									<img border=0 height=1 src="/gifs/spacer.gif" width=20>
										 <a class="subNavigate" href="$secretariat/show_journals.html?issue=latest">
										 	Latest Issue </a>
									 <BR>
									 <img border=0 height=1 src="/gifs/spacer.gif" width=20>
									 		<a class="subNavigate" href="$secretariat/show_journals.html?issue=previous">
									 							Previous Issues</a>
									<BR>

									<img border=0 height=1 src="/gifs/spacer.gif" width=20>
											<a class="subNavigate" href="$secretariat/search_journals.html">
												Search Archive</a>
									<BR>

									</span>


									</div>
									<div class="navigationFirstLevelContainer">
									<img align=absMiddle border=0 height=11 hspace=2 id=imgord name=imgord src="/gifs/pos.gif" width=11>
									<a class="subNavigate" title="WIOMSA Members">
									Administrator Profile</a> <BR>

									<span >
									<img border=0 height=1 src="/gifs/spacer.gif" width=20>
										 <a class="subNavigate" href="$secretariat/view_profile.html">
										 	View my Profile</a>
									 <BR>
									<img border=0 height=1 src="/gifs/spacer.gif" width=20>
										 <a class="subNavigate" href="$secretariat/update_profile.html">
										 	Update my Profile</a>
									 <BR>


									<img border=0 height=1 src="/gifs/spacer.gif" width=20>
											<a class="subNavigate" href="$secretariat/change_password.html">
													Change Password</a>
									<BR>

									<img border=0 height=1 src="/gifs/spacer.gif" width=20>
											<a class="subNavigate" href="$secretariat/member_history.html">
													History</a>
									<BR>
									 </span>


									</div>
									<div class="navigationFirstLevelContainer">
									<img align=absMiddle border=0 height=11 hspace=2 id=imgord name=imgord src="/gifs/nosubs.gif" width=11>
									<a class="subNavigate" href="$secretariat/faq.html" title="Membership FAQs">Online Help</a></div>

									<div class="navigationFirstLevelContainer">
									<img align=absMiddle border=0 height=11 hspace=2 id=imgord name=imgord src="/gifs/nosubs.gif" width=11>
									<a class="subNavigate" href="$public/logout.html" title="Logout from Members Area">Logout</a></div>
EOF;
}elseif ($privilege=="Member"){
print <<<EOF


									<div class="navigationFirstLevelContainer">
									<img align=absMiddle border=0 height=11 hspace=2 id=imgord name=imgord src="/gifs/nosubs.gif" width=11>
									<a class="subNavigate" href="$member/index.html" title="Home">Home</a></div>
									<div class="navigationFirstLevelContainer">
									<img align=absMiddle border=0 height=11 hspace=2 id=imgord name=imgord src="/gifs/nosubs.gif" width=11>
									<a class="subNavigate" href="$member/letterfromwiomsa.html" title="Letter to Members from Dr. Muthiga">Note from WIOMSA<br>
									<img align=absMiddle border=0 height=11 hspace=2 id=imgord name=imgord src="/gifs/spacer.gif" width=15>President</a></div>

									<div class="navigationFirstLevelContainer">
									<img align=absMiddle border=0 height=11 hspace=2 id=imgord name=imgord src="/gifs/pos.gif" width=11>
									<a class="subNavigate"  title="WIOMSA Members">
									WIOMSA Members</a> <BR>

									<span>
									<img border=0 height=1 src="/gifs/spacer.gif" width=20>
										 											<a class="subNavigate" href="$member/search_members.html">
										 										 		Search Members</a>
									     <BR>


									<img border=0 height=1 src="/gifs/spacer.gif" width=20>
											<a class="subNavigate" href="$member/email_members.html">
													Email Members</a>
									<BR>

									 </span>


									</div>
									<div class="navigationFirstLevelContainer">
									<img align=absMiddle border=0 height=11 hspace=2 id=imgord name=imgord src="/gifs/pos.gif" width=11>
									<a class="subNavigate" title="Publications">
									Publications</a> <BR>

									<span >
									<img border=0 height=1 src="/gifs/spacer.gif" width=20>
										 <a class="subNavigate" href="$member/add_publications.html">
										 	Add Publications</a>
									 <BR>
									<span >
									<img border=0 height=1 src="/gifs/spacer.gif" width=30>
										 <a class="subNavigate"  title="Peer Reviewed Articles">Peer Reviewed Articles</a>
									 <BR>
									<img border=0 height=1 src="/gifs/spacer.gif" width=30>
										 <a class="subNavigate"  title="Thesis">Thesis</a>
									 <BR>
									<img border=0 height=1 src="/gifs/spacer.gif" width=30>
										 <a class="subNavigate"  title="Abstracts">Abstracts</a>
									 <BR>
									 <!--
									<img border=0 height=1 src="/gifs/spacer.gif" width=30>
										 <a class="subNavigate"  title="Curriculum Vitae">Curriculum Vitae</a>
									 <BR>
									 -->

									<img border=0 height=1 src="/gifs/spacer.gif" width=20>
											<a class="subNavigate" href="$member/search_peer_reviews.html">
													Search  for Peer Articles</a>
									<BR>
									<img border=0 height=1 src="/gifs/spacer.gif" width=20>
											<a class="subNavigate" href="$member/search_thesis.html">
													Search for Thesis</a>
									<BR>
									<img border=0 height=1 src="/gifs/spacer.gif" width=20>
											<a class="subNavigate" href="$member/search_abstracts.html">
													Search for Abstracts</a>
									<BR>

									 </span>


									</div>
									<div class="navigationFirstLevelContainer">
									<img align=absMiddle border=0 height=11 hspace=2 id=imgord name=imgord src="/gifs/pos.gif" width=11>
									<a class="subNavigate" title="WIOMSA Members">
									WIOMSA Journals</a> <BR>

									<span >

									<img border=0 height=1 src="/gifs/spacer.gif" width=20>
										 <a class="subNavigate" href="$member/show_journals.html?issue=latest">
										 	Latest Issue </a>
									 <BR>
									 <img border=0 height=1 src="/gifs/spacer.gif" width=20>
									 		<a class="subNavigate" href="$member/show_journals.html?issue=previous">
									 							Previous Issues</a>
									<BR>

									<img border=0 height=1 src="/gifs/spacer.gif" width=20>
											<a class="subNavigate" href="$member/search_journals.html">
												Search Archive</a>

									<BR>
									</span>


									</div>
									<div class="navigationFirstLevelContainer">
									<img align=absMiddle border=0 height=11 hspace=2 id=imgord name=imgord src="/gifs/pos.gif" width=11>
										<a class="subNavigate" href="http://www.wiomsa.org/?id=698" title="Apply for MASMA grant">
									Apply for MARG grant</a> <BR>
									<span >
										<img border=0 height=1 src="/gifs/spacer.gif" width=20>
												 <a class="subNavigate" href="http://www.wiomsa.org/?id=698">
														 	Download Application Form</a>
									 <BR>
									 </span>
									 </div>
									<div class="navigationFirstLevelContainer">
									<img align=absMiddle border=0 height=11 hspace=2 id=imgord name=imgord src="/gifs/pos.gif" width=11>
										<a class="subNavigate" href="http://www.wiomsa.org/?id=700" title="Apply for MASMA grant">
									Apply for MASMA grant</a> <BR>
									<span >
										<img border=0 height=1 src="/gifs/spacer.gif" width=20>
												 <a class="subNavigate" href="http://www.wiomsa.org/?id=704">
														 	Download Application Form</a>
									 <BR>
									 </span>
									 </div>
									<div class="navigationFirstLevelContainer">
									<img align=absMiddle border=0 height=11 hspace=2 id=imgord name=imgord src="/gifs/pos.gif" width=11>
									<a class="subNavigate" title="Membership">
									My Membership</a> <BR>

									<span >
									<img border=0 height=1 src="/gifs/spacer.gif" width=20>
										 <a class="subNavigate" href="$member/view_profile.html">
										 	View my Profile</a>
									 <BR>
									<img border=0 height=1 src="/gifs/spacer.gif" width=20>
										 <a class="subNavigate" href="$member/update_profile.html">
										 	Update my Profile</a>
									 <BR>


									<img border=0 height=1 src="/gifs/spacer.gif" width=20>
											<a class="subNavigate" href="$member/change_password.html">
													Change Password</a>
									<BR>
									<img border=0 height=1 src="/gifs/spacer.gif" width=20>
											<a class="subNavigate" href="$member/membership_status.html">
													Membership Status</a>
									<BR>
									<img border=0 height=1 src="/gifs/spacer.gif" width=20>
											<a class="subNavigate" href="$member/member_history.html">
													My History</a>
									<BR>
									 </span>


									</div>
									<div class="navigationFirstLevelContainer">
									<img align=absMiddle border=0 height=11 hspace=2 id=imgord name=imgord src="/gifs/nosubs.gif" width=11>
									<a class="subNavigate" href="$member/faq.html" title="Membership FAQs">Online Help</a></div>
									<div class="navigationFirstLevelContainer">
									<img align=absMiddle border=0 height=11 hspace=2 id=imgord name=imgord src="/gifs/nosubs.gif" width=11>
									<a class="subNavigate" href="$public/logout.html" title="Logout from Members Area">Logout</a></div>
EOF;
}if ($privilege=="Country Cordinator"){
print <<<EOF


									<div class="navigationFirstLevelContainer">
									<img align=absMiddle border=0 height=11 hspace=2 id=imgord name=imgord src="/gifs/nosubs.gif" width=11>
									<a class="subNavigate" href="$cordinator/index.html" title="Home">Home</a></div>
									<div class="navigationFirstLevelContainer">
									<img align=absMiddle border=0 height=11 hspace=2 id=imgord name=imgord src="/gifs/nosubs.gif" width=11>
									<a class="subNavigate" href="$cordinator/letterfromwiomsa.html" title="Letter from Dr. Muthiga">Note from WIOMSA President</a></div>

									<div class="navigationFirstLevelContainer">
									<img align=absMiddle border=0 height=11 hspace=2 id=imgord name=imgord src="/gifs/pos.gif" width=11>
									<a class="subNavigate"  title="WIOMSA Members">
									Membership Management</a> <BR>

									<span >
										<img border=0 height=1 src="/gifs/spacer.gif" width=20>
											<a class="subNavigate" href="$cordinator/add_member.html" title="Add Member">
											 		Add Member</a>
											<BR>
										<img border=0 height=1 src="/gifs/spacer.gif" width=20>
											<a class="subNavigate" href="$cordinator/receive_fees.html" title="Receive Fees from Members">
											 		Receive Fees</a>
											<BR>
										<img border=0 height=1 src="/gifs/spacer.gif" width=20>
										 	<a class="subNavigate" href="$cordinator/search_members.html" title="Search for WIOMSA Members">
										 										 		Search Members</a>
									     <BR>
										<img border=0 height=1 src="/gifs/spacer.gif" width=20>
										 		<a class="subNavigate" href="$cordinator/download_templates.html" title="Download Templates">
										 										 		Download Templates</a>
									     <BR>


                						</span>

									</div>
									<div class="navigationFirstLevelContainer">
									<img align=absMiddle border=0 height=11 hspace=2 id=imgord name=imgord src="/gifs/pos.gif" width=11>
									<a class="subNavigate"  title="WIOMSA Members">
									Members Communication</a> <BR>

									<span>
									<img border=0 height=1 src="/gifs/spacer.gif" width=20>
										 											<a class="subNavigate" href="$cordinator/search_members.html" title="Search for WIOMSA Members">
										 										 		Search Members</a>
									     <BR>


									<img border=0 height=1 src="/gifs/spacer.gif" width=20>
											<a class="subNavigate" href="$cordinator/email_members.html" title="Email to Members">
													Email Members</a>
									<BR>
									<img border=0 height=1 src="/gifs/spacer.gif" width=20>
											<a class="subNavigate" href="$cordinator/email_groups.html" title="Email Groups">
													Email Groups</a>
									<BR>
									 </span>


									</div>
									<!--
									<div class="navigationFirstLevelContainer">
									<img align=absMiddle border=0 height=11 hspace=2 id=imgord name=imgord src="/gifs/pos.gif" width=11>
									<a class="subNavigate" title="Add Publications">
									Publications</a> <BR>

									<span >
									<img border=0 height=1 src="/gifs/spacer.gif" width=20>
										 <a class="subNavigate" href="add_publications.html">
										 	Add Publications</a>
									 <BR>
									<span >
									<img border=0 height=1 src="/gifs/spacer.gif" width=30>
										 <a class="subNavigate"  title="Peer Reviewed Articles">Peer Reviewed Articles</a>
									 <BR>
									<img border=0 height=1 src="/gifs/spacer.gif" width=30>
										 <a class="subNavigate"  title="Thesis">Thesis</a>
									 <BR>
									<img border=0 height=1 src="/gifs/spacer.gif" width=30>
										 <a class="subNavigate"  title="Abstracts">Abstracts</a>
									 <BR>
									 -->
									 <!--
									<img border=0 height=1 src="/gifs/spacer.gif" width=30>
										 <a class="subNavigate"  title="Curriculum Vitae">Curriculum Vitae</a>
									 <BR>
									 -->
<!--
									<img border=0 height=1 src="/gifs/spacer.gif" width=20>
											<a class="subNavigate" href="search_peer_reviews.html">
													Search  for Peer Articles</a>
									<BR>
									<img border=0 height=1 src="/gifs/spacer.gif" width=20>
											<a class="subNavigate" href="search_thesis.html">
													Search for Thesis</a>
									<BR>
									<img border=0 height=1 src="/gifs/spacer.gif" width=20>
											<a class="subNavigate" href="search_abstracts.html">
													Search for Abstracts</a>
									<BR>
									 </span>


									</div>
									<div class="navigationFirstLevelContainer">
									<img align=absMiddle border=0 height=11 hspace=2 id=imgord name=imgord src="/gifs/pos.gif" width=11>
									<a class="subNavigate" title="WIOMSA Members">
									WIOMSA Journals</a> <BR>

									<span >

									<img border=0 height=1 src="/gifs/spacer.gif" width=20>
										 <a class="subNavigate" href="show_journals.html?issue=latest">
										 	Latest Issue </a>
									 <BR>
									 <img border=0 height=1 src="/gifs/spacer.gif" width=20>
									 		<a class="subNavigate" href="show_journals.html?issue=previous">
									 							Previous Issues</a>
									<BR>

									<img border=0 height=1 src="/gifs/spacer.gif" width=20>
											<a class="subNavigate" href="search_journals.html">
												Search Archive</a>
									<BR>

									</span>
									</div>
									<div class="navigationFirstLevelContainer">
									<img align=absMiddle border=0 height=11 hspace=2 id=imgord name=imgord src="/gifs/pos.gif" width=11>
										<a class="subNavigate" href="http://www.wiomsa.org/?id=698" title="Apply for MASMA grant">
									Apply for MARG grant</a> <BR>
									<span >
										<img border=0 height=1 src="/gifs/spacer.gif" width=20>
												 <a class="subNavigate" href="http://www.wiomsa.org/?id=698">
														 	Download Application Form</a>
									 <BR>
									 </span>
									 </div>
									<div class="navigationFirstLevelContainer">
									<img align=absMiddle border=0 height=11 hspace=2 id=imgord name=imgord src="/gifs/pos.gif" width=11>
										<a class="subNavigate" href="http://www.wiomsa.org/?id=700" title="Apply for MASMA grant">
									Apply for MASMA grant</a> <BR>
									<span >
										<img border=0 height=1 src="/gifs/spacer.gif" width=20>
												 <a class="subNavigate" href="http://www.wiomsa.org/?id=704">
														 	Download Application Form</a>
									 <BR>
									 </span>
									 </div>
									<div class="navigationFirstLevelContainer">
									<img align=absMiddle border=0 height=11 hspace=2 id=imgord name=imgord src="/gifs/pos.gif" width=11>
									<a class="subNavigate" title="My WIOMSA Membership">
									My Own Membership</a> <BR>

									<span >
									<img border=0 height=1 src="/gifs/spacer.gif" width=20>
										 <a class="subNavigate" href="view_profile.html">
										 	View my Profile</a>
									 <BR>
									<img border=0 height=1 src="/gifs/spacer.gif" width=20>
										 <a class="subNavigate" href="update_profile.html">
										 	Update my Profile</a>
									 <BR>


									<img border=0 height=1 src="/gifs/spacer.gif" width=20>
											<a class="subNavigate" href="change_password.html">
													Change Password</a>
									<BR>
									<img border=0 height=1 src="/gifs/spacer.gif" width=20>
											<a class="subNavigate" href="membership_status.html">
													Membership Status</a>
									<BR>
									<img border=0 height=1 src="/gifs/spacer.gif" width=20>
											<a class="subNavigate" href="member_history.html">
													My History</a>
									<BR>
									 </span>


									</div>
										-->
									<div class="navigationFirstLevelContainer">
									<img align=absMiddle border=0 height=11 hspace=2 id=imgord name=imgord src="/gifs/nosubs.gif" width=11>
									<a class="subNavigate" href="$cordinator/faq.html" title="Membership FAQs">Online Help</a></div>
									<div class="navigationFirstLevelContainer">
									<img align=absMiddle border=0 height=11 hspace=2 id=imgord name=imgord src="/gifs/nosubs.gif" width=11>
									<a class="subNavigate" href="$public/logout.html" title="Logout from Members Area">Logout</a></div>
EOF;
}if ($privilege=="Public"){
print <<<EOF


									<div class="navigationFirstLevelContainer">
									<img align=absMiddle border=0 height=11 hspace=2 id=imgord name=imgord src="gifs/nosubs.gif" width=11>
									<a class="subNavigate" href="$public/index.html" title="About WIOMSA Membership">About WIOMSA Membership</a></div>
									<span>
									<img border=0 height=1 src="/gifs/spacer.gif" width=20>
										 <a class="subNavigate" href="$public/about_wiomsa.html">
										 	Individual Membership</a>
									 <BR>
									<img border=0 height=1 src="/gifs/spacer.gif" width=20>
										 <a class="subNavigate" href="$public/about_wiomsa.html?#institutional">
										 	Institutional Membership</a>
									 <BR>
									<img border=0 height=1 src="/gifs/spacer.gif" width=30>
										 <a class="subNavigate" href="$public/about_corporate.html">
										 	Corporate Membership</a>
									 <BR>

									 <div class="navigationFirstLevelContainer">
									 	<img align=absMiddle border=0 height=11 hspace=2 id=imgord name=imgord src="/gifs/nosubs.gif" width=11>
									 	<a class="subNavigate" href="$public/letterfromwiomsa.html" title="Letter from Dr. Muthiga">Note from WIOMSA
									 	<br><img align=absMiddle border=0 height=11 hspace=2 id=imgord name=imgord src="/gifs/spacer.gif" width=15>President
									 	</a></div>

									<div class="navigationFirstLevelContainer">
									<img align=absMiddle border=0 height=11 hspace=2 id=imgord name=imgord src="/gifs/pos.gif" width=11>
									<a class="subNavigate" title="WIOMSA Members">
									Join WIOMSA</a> <BR>

									<span>
									<img border=0 height=1 src="/gifs/spacer.gif" width=20>
										 <a class="subNavigate" title="Members Application Area">
										 	Individual Membership</a>
									 <BR>
									 <span>
									 	<img border=0 height=1 src="/gifs/spacer.gif" width=30>
									 	 <a class="subNavigate" href="$public/join_wiomsa.html" title="Join WIOMSA Membership">
									 		Apply Online</a>
									 <BR>
									 	<img border=0 height=1 src="/gifs/spacer.gif" width=30>
											<a class="subNavigate" href="$public/data/wiomsa_application_form.doc" title="Download Paper Version">
										Download Form</a>
									<BR>
									</span>
									<span>
									<img border=0 height=1 src="/gifs/spacer.gif" width=20>
										 <a class="subNavigate" title="Members Application Area">
										 	Institutional Membership</a>
									 <BR>
									 <span>
									 	<img border=0 height=1 src="/gifs/spacer.gif" width=30>
									 	 <a class="subNavigate" href="$public/join_wiomsa.html?changeMembership=Institutional" title="Join WIOMSA Membership">
									 		Apply Online</a>
									 <BR>
									 	<img border=0 height=1 src="/gifs/spacer.gif" width=30>
											<a class="subNavigate" href="$public/data/wiomsa_application_form.doc" title="Download Paper Version">
										Download Form</a>
									<BR>
									</span>
									<span>
									<img border=0 height=1 src="/gifs/spacer.gif" width=20>
										 <a class="subNavigate" title="Corporate Membership Application">
										 	Corporates Application Area</a>
									 <BR>
									 <span>
									 	<img border=0 height=1 src="/gifs/spacer.gif" width=30>
									 	 <a class="subNavigate" href="$public/join_corporate.html" title="Corporate Membership Application Form">
									 		Apply Online</a>
									 <BR>
									 	<img border=0 height=1 src="/gifs/spacer.gif" width=30>
											<a class="subNavigate" href="$public/data/corporate_application_form.doc" title="Download Paper Version">
										Download Form</a>
									<BR>
									</span>


									</div>


									<div class="navigationFirstLevelContainer">
									<img align=absMiddle border=0 height=11 hspace=2 id=imgord name=imgord src="gifs/nosubs.gif" width=11>
									<a class="subNavigate" href="$public/faq.html" title="Membership FAQs">Membership FAQs</a></div>
									<div class="navigationFirstLevelContainer">
									<img align=absMiddle border=0 height=11 hspace=2 id=imgord name=imgord src="gifs/nosubs.gif" width=11>
									<a class="subNavigate" href="$public/login.html" title="Login to Members Area">Login</a></div>
EOF;
}

print <<<EOF

										</TD>
									</TR>
								</TBODY>
							</TABLE>
							</TD>

							<TD width=2 bgColor=#e6e6e6><IMG height=1 src="$gifspath/1pix.gif" width=1>
							</TD>
							</TR>
						</TBODY>
					</TABLE>
					<TABLE cellSpacing=0 cellPadding=0 width=200 border=0>
						<TBODY>
							<TR>
								<TD width=13><IMG height=13 src="$gifspath/main_l_b.gif" width=13></TD>
								<TD width=174 background=$gifspath/main_bg_b.gif><IMG height=1 src="$gifspath/1pix.gif" width=1></TD>
								<TD width=13><IMG height=13 src="$gifspath/main_r_b.gif" width=13></TD>
							</TR>
						</TBODY>
					</TABLE>

					<BR><IMG height=4 src="$gifspath/1pix.gif">

EOF;
}
?>