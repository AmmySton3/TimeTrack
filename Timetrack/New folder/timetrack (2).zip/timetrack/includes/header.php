<?php
error_reporting(E_ERROR);
require_once('db_connect.php');
$phpself=$_SERVER['PHP_SELF'];
if (isset($_SESSION['empno'])){
	$userrole=$_SESSION['role'];
}else{
	$userrole='';
}


print <<<EOF
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml" xml:lang="en" lang="en">
<head>
<title>TimeTrack - Biometric Time & Attendance system</title>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<meta name="author" content="Burhani Infosys Ltd" />
<meta name="keywords" content="" />
<meta name="description" content="" />
<link href="favicon.ico" rel="shortcut icon" type="image/x-icon" />


<link href="css/dropdown/dropdown.css" media="screen" rel="stylesheet" type="text/css" />
<link href="css/site/skin.css" media="screen" rel="stylesheet" type="text/css" />
<link href="css/site/CalendarControl.css" rel="stylesheet" type="text/css" />



<script type="text/javascript" src="js/jquery.js"></script>
<script src="js/CalendarControl.js"></script>
<script src="js/sorttable.js"></script>

<link rel="stylesheet" type="text/css" href="css/jquery.autocomplete.css" />

<script type='text/javascript' src='js/jquery.bgiframe.min.js'></script>
<script type='text/javascript' src='js/jquery.ajaxQueue.js'></script>
<script type='text/javascript' src='js/jquery.autocomplete.js'></script>
<script type='text/javascript' src='js/thickbox-compressed.js'></script>


<script type="text/javascript">
$().ready(function() {


	function formatItem(row) {
			return row[0] + " (EMP ID:" + row[1] + ")";
	}
	function formatResult(row) {
		return row[0].replace(/(<.+?>)/gi, '');
	}

	$("#name").autocomplete("./employees.php", {
		width: 300,
		selectFirst: false,
		formatItem: formatItem,
		formatResult: formatResult


	});


	$("#name").result(function(event, data, formatted) {
		 $("input[@name=name]").val(data[0]);
	     $("input[@name=employeeno]").val(data[1]);
	  });






	$("#clear").click(function() {
		$(":input").unautocomplete();
	});
});

</script>


</head>
<body>

<h1>TimeTrack - Biometric Time & Attendance system</h1>

EOF;
if ($userrole=='ADMIN'){

print <<<EOF
<ul id="nav" class="dropdown dropdown-horizontal">
	<li><a href="./">Home</a></li>
	<li><span class="dir">Setup</span>
		<ul>
			<li><a href="./setup_employees.php">Employees</a></li>
			<li class="divider">
			<a href="./setup_shiftgroups.php">Shift Groups</a></li>
			<li><a href="./setup_shifts.php">Shifts</a></li>
			<li class="divider">
			<a href="./setup_department.php">Departments</a></li>
			<li class="divider">
			<a href="./setup_holidays.php">Public Holidays</a></li>

		</ul>
	<li><span class="dir">Logs</span>
		<ul>
			<li class="divider"><a href="./add_log.php">Upload Log file</a></li>
		</ul>
	</li>
	<li><span class="dir">Exceptions</span>
		<ul>
			<li class="divider"><a href="./report_exception.php">Exception Report</a></li>
			<li class="divider"><a href="./manual_tracker.php">Manual Time Tracker entry</a></li>
		</ul>
	</li>


	<li><span class="dir">Reports</span>
		<ul>
			<li class="divider"><a href="./report_attendance.php">Attendance Report</a></li>
			<li class="divider"><a href="./report_bydate.php">Daily Attendance by Department</a></li>
			<li class="divider"><a href="./report_bydate_range.php">Time Tracker by Date Range</a></li>
			<li class="divider"><a href="./report_bydepartment.php">Time Tracker by Department</a></li>
			<li><a href="./report_byweek.php">Time Tracker by Week (Summary)</a></li>
			<li><a href="./report_byweek_all_employees.php">Time Tracker by Week (Detailed)</a></li>
			<li><a href="./report_bymonth.php">Time Tracker by Month</a></li>
			<li><a href="./report_byemployee.php">Time Tracker by Employee</a></li>
		</ul>
	</li>
	<li><span class="dir">Integration</span>
		<ul>
			<li class="divider"><a href="./report_bydepartment.php">Norming Payroll (Accpac)</a></li>
			<li><a href="./report_byweek.php">Sage VIP Payroll (Accpac)</a></li>
			<li><a href="./report_bymonth.php">Paymaster (CATS)</a></li>
		</ul>
	</li>	
	<li><span class="dir">My Account</span>
			<ul>
				<li><a href="./reset_password.php">Reset Password</a></li>

			</ul>
	</li>
	<li><a href="./logout.php">Logout</a></li>

</ul>

EOF;
}elseif ($userrole=='LOGS'){

print <<<EOF
<ul id="nav" class="dropdown dropdown-horizontal">
	<li><a href="./">Home</a></li>

	<li><a href="./" class="dir">Logs</a>
		<ul>
			<li class="divider"><a href="./add_log.php">Upload Log file</a></li>
		</ul>
	</li>

	<li><span class="dir">My Account</span>
			<ul>
				<li><a href="./reset_password.php">Reset Password</a></li>

			</ul>
	</li>
	<li><a href="./logout.php">Logout</a></li>

</ul>
EOF;
}elseif ($userrole=='REPORT'){
print <<<EOF

<ul id="nav" class="dropdown dropdown-horizontal">
	<li><a href="./">Home</a></li>
	<li><span class="dir">Exceptions</span>
		<ul>
			<li class="divider"><a href="./report_exception.php">Exception Report</a></li>
			<li class="divider"><a href="./manual_tracker.php">Manual Time Tracker entry</a></li>
		
		</ul>
	</li>


	<li><span class="dir">Reports</span>
		<ul>
			<li class="divider"><a href="./report_attendance.php">Attendance Report</a></li>
			<li class="divider"><a href="./report_bydate.php">Daily Attendance by Department</a></li>
			<li class="divider"><a href="./report_bydate_range.php">Time Tracker by Date Range</a></li>
			<li class="divider"><a href="./report_bydepartment.php">Time Tracker by Department</a></li>
			<li><a href="./report_byweek.php">Time Tracker by Week (Summary)</a></li>
			<li><a href="./report_byweek_all_employees.php">Time Tracker by Week (Detailed)</a></li>
			<li><a href="./report_bymonth.php">Time Tracker by Month</a></li>
			<li><a href="./report_byemployee.php">Time Tracker by Employee</a></li>
		</ul>
	</li>
	<li><span class="dir">My Account</span>
			<ul>
				<li><a href="./reset_password.php">Reset Password</a></li>

			</ul>
	</li>
	<li><a href="./logout.php">Logout</a></li>

</ul>

EOF;
}elseif ($userrole=='STAFF'){
print <<<EOF

<ul id="nav" class="dropdown dropdown-horizontal">
	<li><a href="./">Home</a></li>
	<li><span class="dir">Reports</span>
		<ul>
			<li><a href="./report_byemployee.php">Time Tracker by Employee</a></li>
		</ul>
	</li>
	<li><span class="dir">My Account</span>
			<ul>
				<li><a href="./reset_password.php">Reset Password</a></li>

			</ul>
	</li>
	<li><a href="./logout.php">Logout</a></li>

</ul>
EOF;
}
print <<<EOF

<br/>
EOF;
function formatDate($datestring){
	if ($datestring!=''){
		list ($y, $m, $d) = split ("-", $datestring);
		$datestring=date ("d/m/Y", mktime (0,0,0,$m,$d,$y));
	}
	return $datestring;
}
function unformatDate($datestring){
	if ($datestring!=''){
		list ($d, $m, $y) = split ("/", $datestring);
		$datestring=date ("Y-m-d", mktime (0,0,0,$m,$d,$y));
	}
	return $datestring;
}
?>