<?php

//require the PEAR::DB classes.

//require_once($_SERVER["DOCUMENT_ROOT"]."/filetrack/pear/DB.php");

//require_once($_SERVER["DOCUMENT_ROOT"]."/filetrack/pear/Crypt/HCEMD5.php");
error_reporting(E_ERROR);
require_once("DB.php");
//require_once("Crypt/HCEMD5.php");


// Use DB Pear interface
$dbtype = "mysql";
$user = "root";
$pass = "burhani53";
$server = "localhost";
$dbase = "timetrack";
/**/

//persistent needs to be false, or will break functionality
$persistent = TRUE;

$dsn = "$dbtype://$user:$pass@$server/$dbase";


$db_object = DB::connect($dsn, TRUE);
if(DB::isError($db_object)) {
	
	die($db_object->getMessage());
}

$db_object->setFetchMode(DB_FETCHMODE_ASSOC);


global $db_object;

//include 'check_login.php';
session_start();



?>