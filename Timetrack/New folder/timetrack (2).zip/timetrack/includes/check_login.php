<?php

/* check login script, included in db_connect.php. */

session_start();

if (isset($_SESSION['username']) and isset($_SESSION['password'])) {

	// remember, $_SESSION['password'] will be encrypted.

	if(!get_magic_quotes_gpc()) {
		$_SESSION['username'] = addslashes($_SESSION['username']);
	}
	// addslashes to session username before using in a query.
	$query = $db_object->query("SELECT password as passwd, memberid as uid, role as privilege FROM user_login WHERE username = '".$_SESSION['username']."'");

	if(DB::isError($query)) {
		die($query->getMessage());
	}
	if ($query->numRows() == 0) {
		$logged_in = 0;
		$privilege = "other";
		$uid = "";
		//unset($_SESSION['username']);
		//unset($_SESSION['password']);
		// kill incorrect session variables.
	}
	$info = $query->fetchRow();

	// now we have encrypted pass from DB in
	//$info['loginPass'], stripslashes() just incase:

	$info['passwd'] = stripslashes($info['passwd']);
	$_SESSION['password'] = stripslashes($_SESSION['password']);

	//compare:

	if($_SESSION['password'] == $info['passwd']) {
		// valid password for username
		$logged_in = 1; // they have correct info
					// in session variables.
		$privilege = $info['privilege'];
		$uid = $info['uid'];

	} else {
		$logged_in = 0;
		$privilege = "other";
		$uid = "";
		//unset($_SESSION['username']);
		//unset($_SESSION['password']);
		// kill incorrect session variables.
	}
// clean up
	unset($info['passwd']);
	$_SESSION['username'] = stripslashes($_SESSION['username']);
}else{
	$logged_in = 0;
	$privilege ="Public";
	$uid = "";
}
global $logged_in;
global $privilege;
global $uid;

?>