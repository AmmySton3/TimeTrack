<?php
include('includes/header.php');

if (isset($_SESSION['empno'])){
	$name=$_SESSION['name'];
	$empno=$_SESSION['empno'];
	$role=$_SESSION['role'];
}else{
	echo "<div class='txtResult'>You are not logged in</div>";
	exit;
}

if ($role=='STAFF'){
	echo "<div class='txtResult'>You are not authorized to use this menu</div>";
	exit;
}

if ($role=='REPORT'){
	 $sql="select deptid from departments where superid='$empno'";
	 $query = $db_object->query($sql);
	 if (DB::isError($query)) {
		 $dept='0';
	 }elseif ($query->numRows()==0){
		$dept='0';
		
	}else {
		$start='';
		while ($info=$query->fetchRow()){
			$dept.=$start." ".$info['deptid'];
			$start=',';
		}
	} 
}else{
	 $sql="select deptid from departments";
	 $query = $db_object->query($sql);
	 if (DB::isError($query)) {
		 $dept='';
	 }elseif ($query->numRows()==0){
		$dept='';
		
	}else {
		$start='';
		while ($info=$query->fetchRow()){
			$dept.=$start." ".$info['deptid'];
			$start=',';
		}
	} 
}		
$phpself=$_SERVER['PHP_SELF'];
$readonly='';

if (isset($_POST['submit']) and $_POST['submit']=='Save') {
	$date=$_POST['date'];
	$employeeno=$_POST['employeeno'];
	$calchrs=$_POST['calchrs'];
	$nighthours=$_POST['nighthours'];
	$reason=$_POST['reason'];
	$remarks=$_POST['remarks'];
	$today=date('Y-m-d');
	if ($date==''  or ($calchrs=='' & $nighthours='') or   $employeeno==''){
			$starter=true;
			$txtResult="The Employee No/Date/Work Hours cannot be empty";
	}else{
		list ($d, $m, $y) = split ("/", $date);
		$date=date ("Y-m-d", mktime (0,0,0,$m,$d,$y));
		
		$sql="select employeeno from employees where employeeno='$employeeno' and deptid in ($dept)";
		 $query = $db_object->query($sql);
		if ($query->numRows()==0){
			$txtResult='The Employee does not belong under your department';
		}else{
			$txtResult='The Manual Time Tracker has been inserted successfully!';
			$sql="insert into mtimetrack (employeeno, date, timein, timeout, calchrs, nighthours, reason, remarks, createdby, createdon) 
						values ('$employeeno',
								'$date',
								'0000-00-00 00:00:00',
								'0000-00-00 00:00:00',
								'$calchrs',
								'$nighthours',
								'$reason',
								'$remarks',
								'$empno',
								'$today')";
			$query = $db_object->query($sql);
			if (DB::isError($query)) {
				$txtResult="The Tracker could not be added due to error - <br><i> ". $query ->getMessage()."</i>";
			}
		}
	}
print <<<EOF

<div>
<h2>Update Tracker</h2>
<div class="txtResult">
	$txtResult
</div>
EOF;
	
}else{
$date=date('d/m/Y');


print <<<EOF

<div>
<h2>Add Manual Time Tracker Entry</h2>
<div class="txtResult">
	$txtResult
</div>
<table style="border: dotted 1px #d9d9d9; width:50%;text-align:left;">
<form name='main' action="$phpself" method='POST'>
<tr>
<td class='rightcol'>Employee:</td>

<td class='leftcol' colspan="3"><input type='text' id='name' size='35'>
<input type='hidden' name='employeeno' value='' >
</td>	
</tr>
<tr>
	<td class='rightcol'>Date: </td>
	<td class='leftcol'>
	<input type='text' name='date' value='$date' size='10' readonly onclick="showCalendarControl(this)" label='Click to select date' readonly>
	</td>
</tr>
<tr>
	<td class='rightcol'>Type:</td>
	<td class='leftcol'><select name='reason'>
		<option value='Annual Leave'>Annual Leave</option>
		<option value='Sick Leave'>Sick Leave</option>
		<option value='Other Leave'>Other Leave</option>
		<option value='Out of Office Duty'>Out of Office Duty</option>
<option value='Training'>Training</option>
<option value='Special Duty'>Special Duty</option>
<option value='Forgot to Log'>Forgot to Log</option>
<option value='Adjust Overtime'>Adjust Overtime</option>
<option value='Adjust Night Hours'>Adjust Night Hours</option>


		</select>
	</td>
</tr>
<tr>
	<td class='rightcol'>Remarks:</td>
	<td class='leftcol'><input type='text' name='remarks'>
		
	</td>
</tr>
<tr><td colspan='2'><br/></td>
</tr>
<tr>
	<td class='rightcol'>Work Hours:</td>
	<td class='leftcol'><input type='text' name='calchrs' value='$calchrs' size='5'></td>
</tr>
<tr>
	<td class='rightcol'>Night Hours (incl):</td>
	<td class='leftcol'><input type='text' name='nighthours' value='$nighthours' size='5'></td>
</tr>
<tr>
	<td colspan='2' class='rightcol'>
		<input type='submit' name='submit' value="Save">
		</td>
</tr>
</form>
</table>


</div>
EOF;
}
include('includes/footer.php');
?>

