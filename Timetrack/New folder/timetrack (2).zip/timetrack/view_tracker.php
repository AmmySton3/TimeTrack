<?php

include('includes/db_connect.php');
include('function.inc');

$phpself=$_SERVER['PHP_SELF'];
$readonly='';
$startdate='';
$enddate='';
$employeeno='';
$mylogonly=false;

if (isset($_SESSION['empno'])){
	$name=$_SESSION['name'];
	$empno=$_SESSION['empno'];
	$role=$_SESSION['role'];
}else{
	echo "<div class='txtResult'>You are not logged in</div>";
	exit;
}

if ($role=='STAFF' or $role=='LOGS'){
	$mylogonly=true;
}

if (isset($_GET['employeeno'])) {

		$employeeno=$_GET['employeeno'];
		$startdate=$_GET['startdate'];
		$enddate=$_GET['enddate'];

		    $sql="select d.employeeno, a.name, b.department, c.shiftgroup,d.date, d.timein, d.timeout, d.wrkhrs, d.calchrs, d.nighthours, d.remarks, d.overtimehours, d.doublehours
		    		from employees a, departments b, shiftgroups c, (select e.date, e.employeeno, e.timein, e.timeout, e.wrkhrs, e.calchrs, e.nighthours, e.remarks,e.overtimehours, e.doublehours from timetrack e union
						select f.date, f.employeeno, f.timein, f.timeout, f.calchrs wrkhrs, f.calchrs, f.nighthours, f.reason remarks, f.overtimehours, f.doublehours from mtimetrack f)
					d
		    		where  a.employeeno='$employeeno' and
		    				a.deptid=b.deptid and
		    			a.employeeno=d.employeeno and
		    			a.shiftgroupid=c.shiftgroupid and
		    			d.date>='$startdate' and d.date<='$enddate' order by d.date";
			$starter=false;
			



print <<<EOF
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml" xml:lang="en" lang="en">
<head>
<title>TimeTrack - Biometric Time & Attendance system</title>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<meta name="author" content="Burhani Infosys Ltd" />
<meta name="keywords" content="" />
<meta name="description" content="" />
<link href="favicon.ico" rel="shortcut icon" type="image/x-icon" />


<link href="css/site/print.css" media="screen" rel="stylesheet" type="text/css" />
<link href="css/site/CalendarControl.css" rel="stylesheet" type="text/css" />

<script src="js/sorttable.js"></script>

</head>
<body>

<div>
<h2>Time Tracker Report by Employee</h2>
</div>
<br/>

EOF;
	//echo $sql;
	$query = $db_object->query($sql);


	if (DB::isError($query)) {
		 echo "<table class='sortable' style='border: dotted 1px #d9d9d9;' width='95%'>";
		 echo "<thead>";
		 echo "<tr>";
		 echo "<td>";
		 echo "Error - <i>".$query ->getMessage()."with $sql;</i><br>";
		 echo "</td>";
		 echo "</tr>";
		 echo "</thead>";
		 echo "</table>";
	}elseif ($query->numRows()==0){
		echo "<table class='sortable' style='border: dotted 1px #d9d9d9;' width='95%'>";
		echo "<thead>";
		echo "<tr>";
		echo "<td>";
		echo "There are no data in the system in the range provided";
		echo "</td>";
		echo "</tr>";
		echo "</thead>";
		echo "</table>";
	}else {
		$prevdept='';
		list ($y, $m, $d) = split ("-", $startdate);
		$startdate=date ("d/m/Y", mktime (0,0,0,$m,$d,$y));
		list ($y, $m, $d) = split ("-", $enddate);
		$enddate=date ("d/m/Y", mktime (0,0,0,$m,$d,$y));

		$prevemp='';
		$totalwrkhrs=0;
		$totalcalchrs=0;
		$totalnighthrs=0;
		$totalovertime=0;
		$totaldouble=0;
	
		while ($info=$query->fetchRow()){


			$employeeno=$info['employeeno'];
			$name=$info['name'];
			$department=$info['department'];
			$shiftgroup=$info['shiftgroup'];
			$totalwrkhrs=$totalwrkhrs+$info['wrkhrs'];
			$totalcalchrs=$totalcalchrs+$info['calchrs'];
			$totalnighthrs=$totalnighthrs+$info['nighthours'];
			$totalovertime=$totalovertime+$info['overtimehours'];
			$totaldouble=$totaldouble+$info['doublehours'];
			
			if ($prevemp!=$employeeno){

				echo "<table style='border: dotted 1px #d9d9d9;' width='95%'>";
				echo "<tr><td class='leftcol'><strong>Employee: $name ($employeeno)</strong> </td>";
				echo "<td class='rightcol'><strong>Start Date: $startdate - End Date: $enddate </strong> </td>";
				echo "</tr>";
				echo "<tr><td class='leftcol'>Shift Group: $shiftgroup</td>";
				echo "<td class='rightcol'>Department: $department  </td>";
				echo "</tr></table>";
				echo "<table class='sortable' style='border: dotted 1px #d9d9d9;' width='95%'>";
				echo "<thead>";
				echo "<tr>";
				echo "<td class='innerTDL' width='20%'>";
				echo "<u>Date</u>";
				echo "</td>";
				echo "<td class='innerTDL' width='18%'>";
				echo "<u>Time In</u>";
				echo "</td>";
				echo "<td class='innerTDL' width='18%'>";
				echo "<u>Time Out</u>";
				echo "</td>";
				echo "<td class='innerTDL' width='8%'>";
				echo "<u>Calc. Hours</u>";
				echo "</td>";
				echo "<td class='innerTDL' width='8%'>";
				echo "<u>Work Hours</u>";
				echo "</td>";
				//echo "<td class='innerTDL' width='8%'>";
				//echo "<u>Night Hrs (incl)</u>";
				//echo "</td>";
				echo "<td class='innerTDL' width='8%'>";
				echo "<u>Overtime Hours</u>";
				echo "</td>";
				echo "<td class='innerTDL' width='8%'>";
				echo "<u>Double Hours</u>";
				echo "</td>";
				echo "<td class='innerTDL' width='20%'>";
				echo "<u>Remarks</u>";
				echo "</td>";
				echo "</tr>";
				echo "</thead>";
				echo "<tbody>";
			}
				echo "<tr>";
				echo "<td class='innerTDL'>";
				$date=$info['date'];
				list ($y, $m, $d) = split ("-", $date);
				$date=date ("l, d/m/Y", mktime (0,0,0,$m,$d,$y));
				echo $date;
				echo "</td>";
				echo "<td class='innerTDL'>";
				echo $info['timein'];
				echo "</td>";
				echo "<td class='innerTDL'>";
				echo $info['timeout'];
				echo "</td>";
				echo "<td class='innerTDR'>";
				echo $info['wrkhrs'];
				echo "</td>";
				echo "<td class='innerTDR'>";
				echo $info['calchrs'];
				echo "</td>";
				//echo "<td class='innerTDR'>";
				//echo $info['nighthours'];
				//echo "</td>";
				echo "<td class='innerTDR'>";
				echo $info['overtimehours'];
				echo "</td>";
				echo "<td class='innerTDR'>";
				echo $info['doublehours'];
				echo "</td>";
				echo "<td class='innerTDL'>";
				echo $info['remarks'];
				echo "</td>";
				echo "</tr>";
				$prevemp=$employeeno;
		}
			echo "<tr>";
			echo "<td class='innerTDL' width='20%'>";
			echo " ";
			echo "</td>";
			echo "<td class='innerTDL' width='18%'>";
			echo " ";
			echo "</td>";
			echo "<td class='innerTDR' width='18%'>";
			echo " <strong>Total</strong>";
			echo "</td>";
			echo "<td class='innerTDR' width='8%'>";
			echo "<strong>$totalwrkhrs</strong>";
			echo "</td>";
			echo "<td class='innerTDR' width='8%'>";
			echo "<strong>$totalcalchrs</strong>";
			echo "</td>";
			//echo "<td class='innerTDR' width='8%'>";
			//echo "<strong>$totalnighthrs</strong>";
			//echo "</td>";
			echo "<td class='innerTDR' width='8%'>";
			echo "<strong>$totalovertime</strong>";
			echo "</td>";
			
			echo "<td class='innerTDR' width='8%'>";
			echo "<strong>$totaldouble</strong>";
			echo "</td>";
			
			echo "<td class='innerTDL' width='20%'>";
			echo " ";
			echo "</td>";
			echo "</tr>";

		echo "</tbody>";
		echo "<tfoot>";
		echo "</tfoot>";
		echo "</table>";
	}


}
include('includes/footer.php');
?>

