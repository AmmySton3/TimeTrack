<?php
require_once('includes/db_connect.php');

$sql="select name, employeeno from employees order by name";
$query = $db_object->query($sql);
if (DB::isError($query)) {
	die($query ->getMessage());
}
$q='';
$data =$db_object->getAll($sql);
$q = strtolower($_GET["q"]);
if (!$q) return;

while ($info=$query->fetchRow()){
	$key=$info['name'].$info['employeeno'];
	$value=$info['name']."|".$info['employeeno']."\n";
	if (strpos(strtolower($key), $q) !== false) {
		echo $value;
	}
}

?>