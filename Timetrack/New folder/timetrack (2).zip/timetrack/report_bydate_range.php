<?php
include('includes/db_connect.php');
include('function.inc');
$phpself=$_SERVER['PHP_SELF'];
$readonly='';
$reportweek='';
$deptid='';
$weeks='';

if (isset($_SESSION['empno'])){
	$name=$_SESSION['name'];
	$empno=$_SESSION['empno'];
	$role=$_SESSION['role'];
}else{
	echo "<div class='txtResult'>You are not logged in</div>";
	exit;
}

if ($role=='STAFF' or $role=='LOGS'){
	echo "<div class='txtResult'>You are not authorized to use this menu</div>";
	exit;
}

if ($role=='REPORT'){
	 $sql="select deptid from departments where superid='$empno'";
	 $query = $db_object->query($sql);
	 if (DB::isError($query)) {
		 $dept='0';
	 }elseif ($query->numRows()==0){
		$dept='0';
		
	}else {
		$start='';
		while ($info=$query->fetchRow()){
			$dept.=$start." ".$info['deptid'];
			$start=',';
		}
	} 
}else{
	 $sql="select deptid from departments";
	 $query = $db_object->query($sql);
	 if (DB::isError($query)) {
		 $dept='';
	 }elseif ($query->numRows()==0){
		$dept='';
		
	}else {
		$start='';
		while ($info=$query->fetchRow()){
			$dept.=$start." ".$info['deptid'];
			$start=',';
		}
	} 
}
if (!isset($_POST['submit']) or $_POST['submit']=='Cancel'){
	$txtResult='';

	$starter=true;
}
elseif (isset($_POST['submit']) and ($_POST['submit']=='Print')) {

		$deptid = $_POST['deptid'];
		$start_date = $_POST['startdate'];
		$end_date = $_POST['enddate'];
		
		if ($start_date == '' or $end_date == ''){
			$starter=true;
			$txtResult="The Date cannot be empty";
		}else{
			list ($sd, $sm, $sy) = split ("/", $start_date);
			$startdate=date ("Y-m-d", mktime (0,0,0,$sm,$sd,$sy));
			
			list ($ed, $em, $ey) = split ("/", $end_date);
			$enddate=date ("Y-m-d", mktime (0,0,0,$em,$ed,$ey));
		    $sql="select d.employeeno, a.name, b.department, c.shiftgroup,d.date, d.timein, d.timeout, d.wrkhrs, d.calchrs, d.nighthours, d.remarks, d.overtimehours, d.doublehours
		    		from employees a, departments b, shiftgroups c, (select e.date, e.employeeno, e.timein, e.timeout, e.wrkhrs, e.calchrs, e.nighthours, e.remarks,e.overtimehours, e.doublehours from timetrack e where e.status='A' union
						select f.date, f.employeeno, f.timein, f.timeout, f.calchrs wrkhrs, f.calchrs, f.nighthours, f.reason remarks, f.overtimehours, f.doublehours from mtimetrack f)
					d
		    		where a.deptid=b.deptid and
		    			a.employeeno=d.employeeno and
		    			a.shiftgroupid=c.shiftgroupid and
		    			d.date>='$startdate' and d.date<='$enddate' order by b.department, d.employeeno,d.date";
			//echo $sql;
			$starter=false;
		}		
}

if ($starter==true){

//retrieve departments and populate selection
$selectdepartment =  "<select name='deptid'>";

$sql="SELECT * FROM departments";

$query = $db_object->query($sql);
if (DB::isError($query)) {
	$selectdepartment="Error -<i>".$query ->getMessage()."</i>";
}
if ($query->numRows()==0){
	$selectdepartment = 'Not defined';

}else {
	$selectdepartment=$selectdepartment."<option value='ALL'";
	$selectdepartment=$selectdepartment.">All Departments</option>";
	while ($info = $query->fetchRow()){
		$selectdepartment = $selectdepartment."<option value='".$info['deptid']."'";
		$selectdepartment = $selectdepartment.">".$info['department']." </option>";
	}
}
$selectdepartment=$selectdepartment."</select>";

$year = date('Y');
$thisweek = (int)date('W');
$x=$thisweek;
$startweek= $thisweek-20;
$endweek= $thisweek+4;
$weeks="<select name='reportweek'>";
for ($j=$startweek; $j<=$endweek; $j++){
	$week_number=$j;
	$y=$year;
	if($week_number<1){
		$week_number=$j+52;
		$y=$year-1;
	}
	if($week_number<10){$week_number='0'.$week_number;}
	$weeks.= "<option value='$week_number-$y'";
	if ($j==$x){
		$weeks.=" selected ";
	}
	$weeks.=">".date('D d M Y', strtotime($y."W".$week_number."1" . "0 week"))." - ".
		date('D d M Y', strtotime($y."W".$week_number."7" . "0 week"))."</option>";
}
$weeks.="</select>";


include('includes/header.php');
?>

<div>
<h2>Time Tracker Report by Date Range</h2>
<div class="txtResult">
	<?php echo $txtResult; ?>
</div>
<br/>
<table style="border: dotted 1px #d9d9d9;">
<form name='main' action="<?php echo $phpself; ?>" method='POST'>
<tr>
<td class='rightcol'>Department:</td>

	<td class='leftcol'><?php echo $selectdepartment; ?></td>
</tr>
<tr>
	<td colspan='2'></td>
</tr>
<tr>
	<td class='rightcol'>Start Date:</td>
	<td class='leftcol' ><input type='text' name='startdate' value='' size='12' onclick="showCalendarControl(this)" label='Click to select start date' readonly></td>
</tr>
<tr>
	<td colspan='2'></td>
</tr>
<tr>
	<td class='rightcol'>End Date:</td>
	<td class='leftcol' ><input type='text' name='enddate' value='' size='12' onclick="showCalendarControl(this)" label='Click to select end date' readonly></td>
</tr>
<tr>
	<td colspan='2'></td>
</tr>
<tr>
	<td colspan='2' class='rightcol'>
		<input type='submit' name='submit' value='Cancel'>&nbsp;
		<input type='submit' name='submit' value='Print'>
		</td>
</tr>
</form>
</table>
</div>
<?php
}elseif ($starter==false){
?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml" xml:lang="en" lang="en">
<head>
<title>TimeTrack - Biometric Time & Attendance system</title>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<meta name="author" content="Burhani Infosys Ltd" />
<meta name="keywords" content="" />
<meta name="description" content="" />
<link href="favicon.ico" rel="shortcut icon" type="image/x-icon" />
<link href="css/site/print.css" media="screen" rel="stylesheet" type="text/css" />
<link href="css/site/CalendarControl.css" rel="stylesheet" type="text/css" />
<script src="js/sorttable.js"></script>
</head>
<body>
<div>
<h2>Time Tracker Report by Date Range</h2>
<div>
	<p><strong><label style='color:blue;'>Start Date:</label><?php echo $startdate; ?> <label style='color:blue;'>- End Date:</label> <?php echo $enddate; ?> </strong></p>
</div>
</div>
<br/>
<?php
	//echo $sql;
	$query = $db_object->query($sql);
	if (DB::isError($query)) {
		 echo "<table class='sortable' style='border: dotted 1px #d9d9d9;' width='95%'>";
		 echo "<thead>";
		 echo "<tr>";
		 echo "<td>";
		 echo "Error - <i>".$query ->getMessage()."with $sql;</i><br>";
		 echo "</td>";
		 echo "</tr>";
		 echo "</thead>";
		 echo "</table>";
	}elseif ($query->numRows()==0){
		echo "<table class='sortable' style='border: dotted 1px #d9d9d9;' width='95%'>";
		echo "<thead>";
		echo "<tr>";
		echo "<td>";
		echo "There are no data in the system in the range provided";
		echo "</td>";
		echo "</tr>";
		echo "</thead>";
		echo "</table>";
	}else {
		$prevdept='';
		list ($y, $m, $d) = split ("-", $startdate);
		$startdate=date ("d/m/Y", mktime (0,0,0,$m,$d,$y));
		list ($y, $m, $d) = split ("-", $enddate);
		$enddate=date ("d/m/Y", mktime (0,0,0,$m,$d,$y));

		$prevemp='';
		$totalwrkhrs=0;
		$totalcalchrs=0;
		$totalnighthrs=0;
		$totalovertime=0;
		$totaldouble=0;
		$totaldays = 0;
		while($info=$query->fetchRow()){
			$employeeno=$info['employeeno'];
			$name=$info['name'];
			$department=$info['department'];
			$shiftgroup=$info['shiftgroup'];
			if($prevemp != $employeeno){
				if($prevemp == ''){}else{
					echo "<tr>";
					echo "<td class='innerTDL' width='20%'>";
					echo "";
					echo "</td>";
					echo "<td class='innerTDL' width='18%'>";
					echo " ";
					echo "</td>";
					echo "<td class='innerTDR' width='18%'>";
					echo " <strong>Total</strong>";
					echo "</td>";
					echo "<td class='innerTDR' width='8%'>";
					echo "<strong>$totalwrkhrs</strong>";
					echo "</td>";
					echo "<td class='innerTDR' width='8%'>";
					echo "<strong>$totalcalchrs</strong>";
					echo "</td>";
					//echo "<td class='innerTDR' width='8%'>";
					//echo "<strong>$totalnighthrs</strong>";
					//echo "</td>";
					echo "<td class='innerTDR' width='8%'>";
					echo "<strong>$totalovertime</strong>";
					echo "</td>";
					
					echo "<td class='innerTDR' width='8%'>";
					echo "<strong>$totaldouble</strong>";
					echo "</td>";
					
					echo "<td class='innerTDL' width='20%'>";
					echo "";
					echo "</td>";
					echo "<td class='innerTDL' width='20%'>";
					echo "<strong>$totaldays</strong>";
					echo "</td>";
					echo "</tr>";
					echo "</tbody>";
					echo "</table>";
					$totalwrkhrs=0;
					$totalcalchrs=0;
					$totalnighthrs=0;
					$totalovertime=0;
					$totaldouble=0;	
					$totaldays=0;
				}
				echo "<table style='border: dotted 1px #d9d9d9;' width='95%'>";
				echo "<tr><td class='leftcol'><strong>Employee: $name ($employeeno)</strong> </td>";
				echo "<td class='rightcol'></td>";
				echo "</tr>";
				echo "<tr><td class='leftcol'>Shift Group: $shiftgroup</td>";
				echo "<td class='rightcol'>Department: $department  </td>";
				echo "</tr></table>";
				echo "<table class='sortable' style='border: dotted 1px #d9d9d9;' width='95%'>";
				echo "<thead>";
				echo "<tr>";
				echo "<td class='innerTDL' width='20%'>";
				echo "<u>Date</u>";
				echo "</td>";
				echo "<td class='innerTDL' width='18%'>";
				echo "<u>Time In</u>";
				echo "</td>";
				echo "<td class='innerTDL' width='18%'>";
				echo "<u>Time Out</u>";
				echo "</td>";
				echo "<td class='innerTDL' width='8%'>";
				echo "<u>Calc. Hours</u>";
				echo "</td>";
				echo "<td class='innerTDL' width='8%'>";
				echo "<u>Work Hours</u>";
				echo "</td>";
				//echo "<td class='innerTDL' width='8%'>";
				//echo "<u>Night Hrs (incl)</u>";
				//echo "</td>";
				echo "<td class='innerTDL' width='8%'>";
				echo "<u>Overtime Hours</u>";
				echo "</td>";
				echo "<td class='innerTDL' width='8%'>";
				echo "<u>Double Hours</u>";
				echo "</td>";
				echo "<td class='innerTDL' width='20%'>";
				echo "<u>Remarks</u>";
				echo "</td>";
				echo "<td class='innerTDL' width='20%'>";
				echo "<u>Days</u>";
				echo "</td>";
				echo "</tr>";
				echo "</thead>";
				echo "<tbody>";
			}
				echo "<tr>";
				echo "<td class='innerTDL'>";
				$date=$info['date'];
				list ($y, $m, $d) = split ("-", $date);
				$date=date ("l, d/m/Y", mktime (0,0,0,$m,$d,$y));
				echo $date;
				echo "</td>";
				echo "<td class='innerTDL'>";
				echo $info['timein'];
				echo "</td>";
				echo "<td class='innerTDL'>";
				echo $info['timeout'];
				echo "</td>";
				echo "<td class='innerTDR'>";
				echo $info['wrkhrs'];
				echo "</td>";
				echo "<td class='innerTDR'>";
				echo $info['calchrs'];
				echo "</td>";
				//echo "<td class='innerTDR'>";
				//echo $info['nighthours'];
				//echo "</td>";
				echo "<td class='innerTDR'>";
				echo $info['overtimehours'];
				echo "</td>";
				echo "<td class='innerTDR'>";
				echo $info['doublehours'];
				echo "</td>";
				echo "<td class='innerTDL'>";
				echo $info['remarks'];
				echo "</td>";
				echo "</tr>";
				$totalwrkhrs = $totalwrkhrs+$info['wrkhrs'];
				$totalcalchrs = $totalcalchrs+$info['calchrs'];
				$totalnighthrs = $totalnighthrs+$info['nighthours'];
				$totalovertime = $totalovertime+$info['overtimehours'];
				$totaldouble = $totaldouble+$info['doublehours'];
				$totaldays = $totaldays + 1;
				$prevemp = $employeeno;
		}
	}
}
include('includes/footer.php');
?>

