<?php
include('includes/header.php');

$phpself=$_SERVER['PHP_SELF'];
$readonly='';

if (isset($_SESSION['empno'])){
	$name=$_SESSION['name'];
	$empno=$_SESSION['empno'];
	$role=$_SESSION['role'];
}else{
	echo "<div class='txtResult'>You are not logged in</div>";
	exit;
}

if ($role!='ADMIN'){
	echo "<div class='txtResult'>You are not authorized to use this menu</div>";
	exit;
}

if (!isset($_POST['submit']) or $_POST['submit']=='Cancel'){
	$postbutton='Add';
	$code='';
	$description='';
	$txtResult='';
	$name='';
	$employeeno='';
}
elseif (isset($_POST['submit']) and $_POST['submit']=='Edit'){
	$code=$_POST['listofvalues'];
	$sql="SELECT a.*, b.name FROM departments a left outer join employees b on a.superid=b.employeeno where a.deptid='$code' LIMIT 1";
	$query = $db_object->query($sql);
	if (DB::isError($query)) {
		$txtResult="The action was not successfull due to error -  <br><i> ".$query ->getMessage()."</i>";
	}
	if ($query->numRows()==0){
		$postbutton = 'Add';
		$code='';
		$description='';
		$name='';
		$employeeno='';
		$txtResult='Please select an item from the list!';
	} else {
		$readonly='readonly';
		$info = $query->fetchRow();
		$postbutton='Save';
		$description=$info['department'];
		$code=$info['deptid'];
		$employeeno=$info['superid'];
		$name=$info['name'];

		$txtResult='Please make the necessary changes!';
	}
}
elseif (isset($_POST['submit']) and $_POST['submit']=='Delete') {
	$code=$_POST['listofvalues'];
	if ($code=='') {
		$txtResult='Please select an item from the list';
	} else {
		$txtResult='The item has been deleted successfully!';
		$sql="DELETE FROM departments where deptid='$code'";
		$query = $db_object->query($sql);
		if (DB::isError($query)) {
			$txtResult="The item could not be deleted due to error - <br><i> ". $query ->getMessage()."</i>";
		}

	}
	$postbutton='Add';
	$code='';
	$description='';
	$name='';
	$employeeno='';

}
elseif (isset($_POST['submit']) and $_POST['submit']=='Save') {
	if ($_POST['code']=='' or $_POST['description']=='' or $_POST['employeeno']==''){
		$txtResult='The code or description or supervisor cannot be empty!';
	}else{
		$code=$_POST['code'];
		$description=$_POST['description'];
		$superid=$_POST['employeeno'];
		$sql="UPDATE departments set department='$description', superid='$superid' where deptid='$code'";
		$query = $db_object->query($sql);
		$txtResult='Changes have been saved successfully!';
		if (DB::isError($query)) {
			$txtResult="Changes could not be saved due to error - <br><i> ". $query ->getMessage()."</i>";
		}
	}
	$postbutton='Add';
	$code='';
	$description='';
	$name='';
	$employeeno='';

}
elseif (isset($_POST['submit']) and $_POST['submit']=='Add') {
	if ($_POST['description']=='' or $_POST['employeeno']==''){
		$txtResult='The description or supervisor cannot be empty!';
	}else{
		if (!get_magic_quotes_gpc()) {
			$description=addslashes($_POST['description']);

		}else{
			$description=$_POST['description'];

		}
		$superid=$_POST['employeeno'];
		$txtResult='The item has been added successfully!';
		$sql="INSERT into departments (department, superid) values ('$description','$superid')";
		$query = $db_object->query($sql);
		if (DB::isError($query)) {
			$txtResult="The item could not be added due to error - <br><i> ". $query ->getMessage()."</i>";
		}
	}
	$postbutton='Add';
	$code='';
	$description='';
	$employeeno='';
	$name='';
}

//retrieve List of Values
$sql="SELECT *  FROM departments order by department asc";

$query = $db_object->query($sql);
if (DB::isError($query)) {
	$listofvalues="The items could note be retrieved due error - <br><i>".$query ->getMessage()."</i>";
}
if ($query->numRows()==0){
	$listofvalues = "There are no items defined as yet!";
}else {
	$listofvalues =  "<select size='10' name='listofvalues'>";
	while ($info = $query->fetchRow()){
		$listofvalues = $listofvalues."<option value='".$info['deptid']."'>".$info['department']."</option>";
	}
	$listofvalues= $listofvalues."</select>";
}

print <<<EOF

<div>
<h2>Setup Departments</h2>
<table>
<tr>
<td style="vertical-align:top;">
<table style="border: dotted 1px #d9d9d9;">
<form name='main' action="$phpself" method='POST'>
<tr>
	<td class='rightcol'>Department:</td>
	<td class='leftcol'><input type='hidden' name='code' value='$code' size='6' $readonly>
	<input type='text' name='description' value='$description' size='40'></td>
</tr>
<tr>
	<td class='rightcol'>Supervisor</td>
	<td class='leftcol'><input type='text' id='name' value='$name' size='40'>
	<input type='hidden' name='employeeno' value='$employeeno' >
	</td>

<tr>
	<td colspan='2' class='rightcol'>
		<input type='submit' name='submit' value="Cancel">&nbsp;
		<input type='submit' name='submit' value="$postbutton">
	</td>
</tr>

</form>
</table>
<br/>
<div class="txtResult">
	$txtResult
</div>
</td>
<td style="vertical-align:top;">
<table style="border: dotted 1px #d9d9d9;">
<form name='listmain' action="$phpself" method='POST'>
<tr>
	<td class='rightcol' >
			$listofvalues
	</td>
</tr>
<tr>
	<td class='rightcol'>
		<input type='submit' name='submit' value='Edit'>&nbsp;
		<input type='submit' name='submit' value='Delete'>
	</td>
</tr>
</form>
</table>


</div>
EOF;
include('includes/footer.php');
?>

