<?php

include('includes/header.php');
include('function.inc');

$phpself=$_SERVER['PHP_SELF'];
$readonly='';
$startdate='';
$enddate='';
$employeeno='';
$mylogonly=false;

if (isset($_SESSION['empno'])){
	$name=$_SESSION['name'];
	$empno=$_SESSION['empno'];
	$role=$_SESSION['role'];
}else{
	echo "<div class='txtResult'>You are not logged in</div>";
	exit;
}

if ($role=='STAFF' or $role=='LOGS'){
	$mylogonly=true;
}
if ($role=='REPORT'){
	 $sql="select deptid from departments where superid='$empno'";
	 $query = $db_object->query($sql);
	 if (DB::isError($query)) {
		 $dept='0';
	 }elseif ($query->numRows()==0){
		$dept='0';
		
	}else {
		$start='';
		while ($info=$query->fetchRow()){
			$dept.=$start." ".$info['deptid'];
			$start=',';
		}
	} 
}else{
	 $sql="select deptid from departments";
	 $query = $db_object->query($sql);
	 if (DB::isError($query)) {
		 $dept='';
	 }elseif ($query->numRows()==0){
		$dept='';
		
	}else {
		$start='';
		while ($info=$query->fetchRow()){
			$dept.=$start." ".$info['deptid'];
			$start=',';
		}
	} 
}
   $sql="select d.date,d.employeeno, a.name, b.department, c.shiftgroup, d.timein, d.timeout, d.wrkhrs, d.calchrs, d.holidayhrs
	    		from departments b, shiftgroups c, employees a, timetrack d
		    		where
						a.deptid=b.deptid and
						a.deptid in ($dept) and 
		    			a.employeeno=d.employeeno and
		    			a.shiftgroupid=c.shiftgroupid and
		    			(d.status='E')
		    		group by b.department, d.date, a.name";
			$starter=false;


		
print <<<EOF

<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml" xml:lang="en" lang="en">
<head>
<title>TimeTrack - Biometric Time & Attendance system</title>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<meta name="author" content="Burhani Infosys Ltd" />
<meta name="keywords" content="" />
<meta name="description" content="" />
<link href="favicon.ico" rel="shortcut icon" type="image/x-icon" />


<link href="css/site/print.css" media="screen" rel="stylesheet" type="text/css" />
<link href="css/site/CalendarControl.css" rel="stylesheet" type="text/css" />

<script src="js/sorttable.js"></script>

</head>
<body>

<div>
<h2>Exception Report by Department</h2>
</div>
<br/>

EOF;
	//echo $sql;
	$query = $db_object->query($sql);


	if (DB::isError($query)) {
		 echo "<table class='sortable' style='border: dotted 1px #d9d9d9;' width='95%'>";
		 echo "<thead>";
		 echo "<tr>";
		 echo "<td>";
		 echo "Error - $sql<i>".$query ->getMessage()."</i><br>";
		 echo "</td>";
		 echo "</tr>";
		 echo "</thead>";
		 echo "</table>";
	}elseif ($query->numRows()==0){
		echo "<table class='sortable' style='border: dotted 1px #d9d9d9;' width='95%'>";
		echo "<thead>";
		echo "<tr>";
		echo "<td>";
		echo "There are no data in the system in the range provided";
		echo "</td>";
		echo "</tr>";
		echo "</thead>";
		echo "</table>";
	}else {
		$prevdept='';
		$prevemp='';
		$totalwrkhrs=0;
		$totalcalchrs=0;
		while ($info=$query->fetchRow()){


			$employeeno=$info['employeeno'];
			$name=$info['name'];
			$department=$info['department'];
			$shiftgroup=$info['shiftgroup'];
			$timein=$info['timein'];
			$timeout=$info['timeout'];
			if ($prevdept!=$department){
				if($prevdept!=''){
					echo "</tbody>";
					echo "<tfoot>";
					echo "</tfoot>";
					echo "</table>";
					echo "<br/><br/>";
				}

				echo "<table style='border: dotted 1px #d9d9d9;' width='95%'>";
				echo "</tr>";
				echo "<tr><td class='leftcol'><h3><strong>$department</strong>  </h3></td><td class='rightcol'></td>";
				echo "";
				echo "</tr></table>";
				echo "<table class='sortable' style='border: dotted 1px #d9d9d9;' width='95%'>";
				echo "<thead>";
				echo "<tr>";
				echo "<td class='innerTDL' width='15%'>";
				echo "<u>Date</u>";
				echo "</td>";
				echo "<td class='innerTDL' width='30%'>";
				echo "<u>Employee</u>";
				echo "</td>";
				echo "<td class='innerTDL' width='15%'>";
				echo "<u>Time In</u>";
				echo "</td>";
				echo "<td class='innerTDL' width='15%'>";
				echo "<u>Time Out</u>";
				echo "</td>";
				echo "<td class='innerTDL' width='25%'>";
				echo "<u>Action</u>";
				echo "</td>";
				echo "</tr>";
				echo "</thead>";
				echo "<tbody>";
			}
				echo "<tr>";
				echo "<td class='innerTDL'>";
				$date=$info['date'];
				$tdate=$info['date'];
				list ($y, $m, $d) = split ("-", $date);
				$date=date ("l, d/m/Y", mktime (0,0,0,$m,$d,$y));
				$timein=$info['timein'];
				list ($di, $ti) = split (" ", $timein);
				$timeout=$info['timeout'];
				list ($do, $to) = split (" ", $timeout);
				
				echo $date;
				echo "</td>";
				echo "<td class='innerTDL'>";
				echo "$name ($employeeno)";
				echo "</td>";
				echo "<td class='innerTDL'>";
				if ($ti=='00:00:00'){
					echo "<span style='color:red;'>";
				}else{
					echo "<span>";
				}echo $ti;
				echo "</span>";
				echo "</td>";
				echo "<td class='innerTDL'>";
				if ($to=='00:00:00'){
					echo "<span style='color:red;'>";
				}else{
					echo "<span>";
				}
				echo $to;
				$s=date('Y-m-d', mktime (0,0,0,$m,($d-5),$y));
				$e=date('Y-m-d', mktime (0,0,0,$m,($d+5),$y));
				echo "</span>";
				echo "</td>";
				echo "<td class='innerTDC'>";
				echo "<a title='View Tracker' target='_blank' href='view_tracker.php?employeeno=$employeeno&startdate=$s&enddate=$e'><img src='gifs/preview.png' width='16px'>&nbsp;View</a>&nbsp;";
				echo "<a title='Update' href='update_tracker.php?employeeno=$employeeno&date=$tdate'><img src='gifs/approve.gif' width='16px'>&nbsp;Update</a>&nbsp;";
				echo "<a title='Delete' href='delete_tracker.php?employeeno=$employeeno&date=$tdate'><img src='gifs/cancel.gif' width='16px'>&nbsp;Delete</a>";
				echo "</td>";
				echo "</tr>";
				$prevdept=$department;
		}

		echo "</tbody>";
		echo "<tfoot>";
		echo "</tfoot>";
		echo "</table>";
	}



include('includes/footer.php');
?>

