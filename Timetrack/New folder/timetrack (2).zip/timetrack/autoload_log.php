<?php
include('includes/header.php');


$phpself=$_SERVER['PHP_SELF'];
$readonly='';
$txtResult='';
$remarks='';


function convertTime($t){
	list($h, $m, $s)=split(':',$t);
	return $h*60*60 + $m*60 + $s;
}
	
		$destination="C:\\xampp\\htdocs\\timetrack\\sagem\\transactions.csv";
		$row = 0;
		$v=0;
		$i=0;
		$today=date('Y-m-d H:i:s');
		if (($handle = fopen("$destination", "r")) !== FALSE) {
			while (($data = fgetcsv($handle, 1000, ",")) !== FALSE) {
				$num = count($data);
				$row++;
				$v++;
				$sql="insert into accesslogs (timelogged, identtype, employeeno, processed, uploadedby, uploadedon)
						values ((select date_format(str_to_date('$data[0]','%Y%m%d%H%i%s'), '%Y-%m-%d %H:%i:%s')),'$data[5]','$data[2]', 'N', '$empno', '$today')";
						//echo $sql."<br/>";
				$query = $db_object->query($sql);
				if (DB::isError($query)) {

				}else{
					$i++;
				}
				
			}
			fclose($handle);
		}
		$txtResult="$row in total; $i inserted into the logs";
		$yesterday=date('Y-m-d', strtotime("-1 day"));

	if ($i>=0){

			$sql="select * from accesslogs where processed='N' order by employeeno, timelogged";
			$query = $db_object->query($sql);
			if (DB::isError($query)) {
				echo "Error -<i>".$query ->getMessage()."</i>";
			}elseif ($query->numRows()>0){
				$prev_employeeno="";
				$prev_timelogged="";
				$prev_identtype="";

				while ($info=$query->fetchRow()){
					$curr_employeeno=$info['employeeno'];
					$curr_timelogged=$info['timelogged'];
					$curr_identtype=$info['identtype'];

					if ($curr_employeeno==$prev_employeeno){
						if ($curr_identtype=='In One' and $prev_identtype=='Out Two'){

						}elseif ($curr_identtype=='Out Two' and $prev_identtype=='In One'){
							$employeeno=$curr_employeeno;
							$timein=$prev_timelogged;
							$timeout=$curr_timelogged;
							$datelogged=$timein;
							
							$sql="insert into timetrack (date, employeeno, status, timein, timeout, processed) values ('$datelogged', '$employeeno', 'A', '$timein','$timeout','N')";
							$query2 = $db_object->query($sql);
							$sql="update accesslogs set processed='Y' where timelogged='$prev_timelogged' and  employeeno='$prev_employeeno' and identtype='$prev_identtype'";
							$query2 = $db_object->query($sql);
							$sql="update accesslogs set processed='Y' where timelogged='$curr_timelogged' and  employeeno='$curr_employeeno' and identtype='$curr_identtype'";
							$query2 = $db_object->query($sql);
						}elseif ($curr_identtype=='In One' and $prev_identtype=='In One'){
							$employeeno=$curr_employeeno;
							$timein=$prev_timelogged;
							$timeout='';
							$datelogged=$timein;
							$sql="insert into timetrack (date, employeeno, status, timein, timeout, processed) values ('$datelogged', '$employeeno','E', '$timein','$timeout','N')";
							$query2 = $db_object->query($sql);
							$sql="update accesslogs set processed='Y' where timelogged='$prev_timelogged' and  employeeno='$prev_employeeno' and identtype='$prev_identtype'";
							$query2 = $db_object->query($sql);
						}elseif ($curr_identtype=='Out Two' and  $prev_identtype=='Out Two'){
							$employeeno=$curr_employeeno;
							$timein='';
							$timeout=$curr_timelogged;
							$datelogged=$timeout;
							$sql="insert into timetrack (date, employeeno, status, timein, timeout, processed) values ('$datelogged', '$employeeno', 'E', '$timein','$timeout','N')";
							$query2 = $db_object->query($sql);
							$sql="update accesslogs set processed='Y' where timelogged='$curr_timelogged' and  employeeno='$curr_employeeno' and identtype='$curr_identtype'";
							$query2 = $db_object->query($sql);
						}
					}
					$prev_employeeno=$curr_employeeno;
					$prev_timelogged=$curr_timelogged;
					$prev_identtype=$curr_identtype;


				}
			}



		}
/**
		$sql7="update accesslogs set processed='D' where date(timelogged)<'$yesterday' and processed='N'";
		$query7 = $db_object->query($sql7);
		if (DB::isError($query7)) {
			echo "Error here -<i>".$query7 ->getMessage()."</i>";

		}
**/

		$sql3="select * from timetrack a, employees b where processed='N' and a.employeeno=b.employeeno";
		$query3 = $db_object->query($sql3);
		if (DB::isError($query3)) {
			echo "Error -<i>".$query3 ->getMessage()."</i>";
		}elseif ($query3->numRows()>0){
			while ($info3=$query3->fetchRow()){
				$date=$info3['date'];
				$employeeno=$info3['employeeno'];
				$timein=$info3['timein'];
				$timeout=$info3['timeout'];
				$shiftgroupid=$info3['shiftgroupid'];
				$dayofweek=date('N', $date);
				list ($di, $ti)=split(' ', $timein);
				list ($do, $to)=split(' ', $timeout);
				if ($timein!='0000-00-00 00:00:00' and $timeout!='0000-00-00 00:00:00'){
					$sql2="select a.shiftid,
								b.dayofweek,
								b.starttime,
								b.endtime,
								b.normalday,
								b.daychange,
								b.workhours,
								b.breakhours,
								time_to_sec(timediff('$ti',starttime)) startdiff,
								time_to_sec(timediff('$to',endtime)) enddiff,
								min(abs(time_to_sec(timediff('$ti',starttime)))) startdiffmin,
								min(abs(time_to_sec(timediff('$to',endtime)))) enddiffmin
							from shifts a, shiftdetail b where b.dayofweek='$dayofweek' and a.shiftgroupid='$shiftgroupid' and a.shiftid=b.shiftid
							group by a.shiftid, b.dayofweek, b.starttime, b.endtime, b.normalday, b.daychange, b.workhours, b.breakhours order by startdiffmin limit 1";
					$query2 = $db_object->query($sql2);
					if (DB::isError($query2)) {
						echo "Error -<i>".$query2 ->getMessage()."</i>";
					}elseif ($query2->numRows()>0){
						$info2=$query2->fetchRow();
						$shiftid=$info2['shiftid'];
						$starttime=$info2['starttime'];
						$endtime=$info2['endtime'];
						$startdiff=$info2['startdiff'];
						$enddiff=$info2['enddiff'];
						$startdiffmin=$info2['startdiffmin'];
						$enddiffmin=$info2['enddiffmin'];

						$latein=0;
						$earlyin=0;
						$lateout=0;
						$earlyout=0;

						if ($startdiff>0){
							if ($startdiffmin>15){
								$remark="Late In";
								$latein=1;
								$calctimein=$di." ".$ti;
							}else{
								$remark="Late In";
								$latein=1;
								$calctimein=$di." ".$starttime;
							}
						}else{
							$remark="Early In";
							$earlyin=1;
							$calctimein=$di." ".$starttime;
						}
						
						if ($enddiff>0){
							if ($enddiffmin>15){
								$remark.=", Late Out";
								$lateout=1;
								$calctimeout=$do." ".$to;
							}else{
								$remark.=", Late Out";
								$lateout=1;
								$calctimeout=$do." ".$to;
							}
						}else{
							if ($enddiffmin>15){
								$remark.=", Early Out";
								$earlyout=1;
								$calctimeout=$do." ".$to;
							}else{
								$remark.=", Early Out";
								$earlyout=1;
								$calctimeout=$do." ".$endtime;
							}
						}
						$sql4="update timetrack set shiftid='$shiftid', shifttimein='$starttime', shifttimeout='$endtime', earlyin='$earlyin', earlyout='$earlyout', latein='$latein', lateout='$lateout', remarks='$remark', calctimein='$calctimein', calctimeout='$calctimeout'
								where employeeno='$employeeno' and date='$date' and timein='$timein' and timeout='$timeout'";
						$query4 = $db_object->query($sql4);
						if (DB::isError($query4)) {
							echo "Error here $sql4-<i>".$query4 ->getMessage()."</i>";

						}
					}
				}
			}
		}

		$sql5="update timetrack set processed='Y', wrkhrs_time=timediff(timeout, timein), wrkhrs=((time_to_sec(timediff(timeout, timein))/60)/60),
			calchrs_time=timediff(calctimeout, calctimein), calchrs=((time_to_sec(timediff(calctimeout, calctimein))/60)/60),holidayhrs_time='00:00:00', holidayhrs='0.00'
					where (date not in (select date from holidays) or WEEKDAY(date)=0) and processed='N'";
		$query5 = $db_object->query($sql5);
		if (DB::isError($query5)) {
			echo "Error here $sql5-<i>".$query5 ->getMessage()."</i>";
		}else{
			echo 'dpme';
		}
		$sql6="update timetrack set processed='Y', wrkhrs_time='00:00:00', wrkhrs='0.00', holidayhrs_time=timediff(timeout, timein), holidayhrs=((time_to_sec(timediff(timeout, timein))/60)/60), earlyin='0', earlyout='0', latein='0', lateout='0', remarks='Worked on a Holiday'
					where date in (select date from holidays) and processed='N'";
		$query6 = $db_object->query($sql6);
		if (DB::isError($query6)) {
			echo "Error here $sql6-<i>".$query6 ->getMessage()."</i>";
		}
		//calculating nighthours between 8PM and 6AM
		
		//$sql7="update timetrack set nighthours=(calchrs-abs((time_to_sec(timediff(calctimein, concat(date,' 20:00:00')))/60)/60)-abs((time_to_sec(timediff(calctimeout, concat(date(calctimeout),' 06:00:00')))/60)/60)), nightstatus='C' where nightstatus<>'C' and ((time_to_sec(timediff(calctimeout, concat(date,' 20:00:00')))/60)/60)>0";
		//$query7 = $db_object->query($sql7);
		//$sql8="update timetrack set nighthours=0, nightstatus='C' where nightstatus<>'C' and ((time_to_sec(timediff(calctimeout, concat(date,' 20:00:00')))/60)/60)<=0";
		//$query8 = $db_object->query($sql8);
		$sql7="select * from timetrack where nightstatus<>'C' and status<>'E'";
		$query7 = $db_object->query($sql7);
		if (DB::isError($query7)) {
			echo "Error here $sql7-<i>".$query7 ->getMessage()."</i>";
		}elseif ($query7->numRows()>0){
			//echo 'here';
			while ($info7=$query7->fetchRow()){
				$nighthrs=0;
				$calctimein=$info7['calctimein'];
				
				$calctimeout=$info7['calctimeout'];
				$ndate=$info7['date'];
				$ndate2=$info7['date'];
				$nemployeeno=$info7['employeeno'];
				$ntimein=$info7['timein'];
				$start=$ndate.' 20:00:00';
				$starttime=new DateTime($start);
				$end=$ndate2.' 06:00:00';
				$endtime=new DateTime($end);
				$endtime->add(new DateInterval('P1D'));
				
				
				$calctimein=new DateTime($info7['calctimein']);
				$calctimeout=new DateTime($info7['calctimeout']);
				
				
				if ($calctimein<=$starttime and $calctimeout>=$starttime){
					//echo "here ";
					if ($calctimeout<=$endtime){
						$nighthrs=$calctimeout->diff($starttime)->format("%H:%i:%s");
					}else{
						$nighthrs=$endtime->diff($starttime)->format("%H:%i:%s");
					}
				}
				if ($calctimein>=$starttime and $calctimeout>=$starttime){
					//echo "there ";
					if ($calctimeout<=$endtime){
						$nighthrs=$calctimeout->diff($calctimein)->format("%H:%i:%s");
					}else{
						$nighthrs=$endtime->diff($calctimein)->format("%H:%i:%s");
					}
				}
				list ($h, $m, $s)=explode(':',$nighthrs);
				$nighthrs=round($h+($m+$s/60)/60,2);
				$sql8="update timetrack set nighthours='$nighthrs', nightstatus='C' where employeeno='$nemployeeno' and  date='$ndate' and  timein='$ntimein'";
				$query8 = $db_object->query($sql8);
		
			}	

		}

	


?>

