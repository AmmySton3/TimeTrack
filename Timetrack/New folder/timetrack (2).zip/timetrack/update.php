<?php
		include('includes/header.php');
		//error_reporting (E_ALL);
		
		$sql7="select * from timetrack where nightstatus<>'C' and status<>'E'";
		$query7 = $db_object->query($sql7);
		if (DB::isError($query7)) {
			echo "Error here $sql7-<i>".$query7 ->getMessage()."</i>";
		}elseif ($query7->numRows()>0){
			echo 'here';
			while ($info7=$query7->fetchRow()){
				$nighthrs=0;
				$calctimein=$info7['calctimein'];
				
				$calctimeout=$info7['calctimeout'];
				$ndate=$info7['date'];
				$ndate2=$info7['date'];
				$nemployeeno=$info7['employeeno'];
				$ntimein=$info7['timein'];
				$start=$ndate.' 20:00:00';
				$starttime=new DateTime($start);
				$end=$ndate2.' 06:00:00';
				$endtime=new DateTime($end);
				$endtime->add(new DateInterval('P1D'));
				
				
				$calctimein=new DateTime($info7['calctimein']);
				$calctimeout=new DateTime($info7['calctimeout']);
				
				
				if ($calctimein<=$starttime and $calctimeout>=$starttime){
					echo "here ";
					if ($calctimeout<=$endtime){
						$nighthrs=$calctimeout->diff($starttime)->format("%H:%i:%s");
					}else{
						$nighthrs=$endtime->diff($starttime)->format("%H:%i:%s");
					}
				}
				if ($calctimein>=$starttime and $calctimeout>=$starttime){
					echo "there ";
					if ($calctimeout<=$endtime){
						$nighthrs=$calctimeout->diff($calctimein)->format("%H:%i:%s");
					}else{
						$nighthrs=$endtime->diff($calctimein)->format("%H:%i:%s");
					}
				}
				list ($h, $m, $s)=explode(':',$nighthrs);
				$nighthrs=round($h+($m+$s/60)/60,2);
				$sql8="update timetrack set nighthours='$nighthrs', nightstatus='C' where employeeno='$nemployeeno' and  date='$ndate' and  timein='$ntimein'";
				$query8 = $db_object->query($sql8);
		
			}	

		}
?>